#!/usr/bin/env python3
"""stdlib admin HTTP server for strfry-86.

Spawned (detached) by plugin86.py. Enforces singleton via port-bind: if the
configured port is already taken, this process exits 0 silently, so repeated
spawns from the plugin are harmless.

Routes:
  GET  /                  -> home.html (public live activity feed)
  GET  /home              -> 302 redirect to / (legacy)
  GET  /stats             -> stats.html (totals, live delta, console)
  GET  /report            -> report.html (admin-only cached-scan results page)
  GET  /authors           -> authors.html (admin-only active-author page)
  GET  /userlist          -> userlist.html (admin member table)
  GET  /audit             -> audit.html (server-side admin action log)
  GET  /bans              -> bans.html (public ban list + admin ban UI)
  GET  /profile           -> profile.html (admin-only single-pubkey detail page)
  GET  /domain            -> domain.html (admin-only nip-05 domain roster page)
  GET  /common86.js       -> shared client JS for all pages
  GET  /favicon.ico       -> browser-tab icon for all pages
  GET  /api/live          -> text/event-stream: one shared strfry poll loop fanned
                             out as deltas (new events, kind-5 deletes) to / and /stats
  GET  /api/banned        -> public read of the ban list
  GET  /api/authors       -> public read of the last author-scan result (never scans)
  POST /api/authors/scan  -> NIP-98 authenticated: run exactly one bounded scan
  GET  /api/recipients    -> public read of the last gift-wrap recipient tally (never scans)
  POST /api/recipients    -> NIP-98 authenticated: run exactly one bounded scan
  GET  /api/subscribers   -> public read of the last DM/general relay-list search (never scans)
  POST /api/subscribers   -> NIP-98 authenticated: run exactly one bounded scan
  GET  /api/report        -> public read of the totals + whole-database-walk records (never scans)
  POST /api/report/totals -> NIP-98 authenticated: four index counts, seconds even on a large relay
  POST /api/report/walk   -> NIP-98 authenticated: the one unlimited scan in the project
  POST /api/unban         -> NIP-98 authenticated unban
  POST /api/ban           -> NIP-98 authenticated manual ban
  POST /api/reason        -> NIP-98 authenticated: bulk-edit reason on existing bans
  POST /api/profile       -> NIP-98 authenticated: everything known about one pubkey
  POST /api/profile/day   -> NIP-98 authenticated: one pubkey's events on one UTC calendar day
  POST /api/profile/new   -> NIP-98 authenticated: events newer than a given time, bounded
  POST /api/pubkeys/lookup -> NIP-98 authenticated: what's known about a domain's roster
  POST /api/names         -> NIP-98 authenticated: intake for externally-verified profile names
  GET  /api/reports       -> public read of the last kind-1984-per-p-tag tally (never scans)
  POST /api/reports       -> NIP-98 authenticated: run exactly one bounded scan
  POST /api/console       -> NIP-98 authenticated: run one CONSOLE_VERBS-allowlisted command
  POST /api/audit         -> NIP-98 authenticated: paged read of the admin-action log
  POST /api/undo          -> NIP-98 authenticated: undo one audit record by id
"""

import calendar
import errno
import gzip
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from lib86 import bech32, bip340, blacklist, namecache  # noqa: E402

CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")
# strfry.conf is NOT at a fixed path. Packages install it at /etc/strfry.conf,
# the Docker images mount it at /config/strfry.conf, and a source build often
# leaves it beside the binary — and pointing at the wrong one is silent, not
# loud: strfry reads it happily and opens whatever `db` IT names, so scans
# return counts from a database the running relay is not using. Resolution
# order is in strfry_conf_status(); the running relay's own --config argument
# is the authority, and an explicit path in config.json overrides everything.
STRFRY_CONF_CANDIDATES = (
    "/etc/strfry.conf",
    "/etc/strfry/strfry.conf",
    "/config/strfry.conf",
    "/app/strfry.conf",
    "/usr/local/etc/strfry.conf",
)
AUTHORS_CACHE_PATH = os.path.join(SCRIPT_DIR, "authors-cache.json")
RECIPIENTS_CACHE_PATH = os.path.join(SCRIPT_DIR, "recipients-cache.json")
SUBSCRIBERS_CACHE_PATH = os.path.join(SCRIPT_DIR, "subscribers-cache.json")
REPORT_CACHE_PATH = os.path.join(SCRIPT_DIR, "report-cache.json")
REPORTS_CACHE_PATH = os.path.join(SCRIPT_DIR, "reports-cache.json")
# dockurr/strfry ships the binary at /app/strfry, which is NOT on PATH for a
# detached process; the official image installs to /usr/local/bin.
STRFRY_BIN_CANDIDATES = ("/app/strfry", "/usr/local/bin/strfry", "/usr/bin/strfry", "/strfry")

# Static routes are an explicit allowlist, never a filesystem path join —
# there is no directory serving and no path derived from the request, so
# path traversal is not mitigated here, it is impossible. config.json and
# blacklist.json sit next to these files and must never be reachable.
STATIC_ROUTES = {
    "/": ("home.html", "text/html; charset=utf-8"),
    "/stats": ("stats.html", "text/html; charset=utf-8"),
    "/users": ("users.html", "text/html; charset=utf-8"),
    "/bans": ("bans.html", "text/html; charset=utf-8"),
    "/audit": ("audit.html", "text/html; charset=utf-8"),
    "/settings": ("settings.html", "text/html; charset=utf-8"),
    "/profile": ("profile.html", "text/html; charset=utf-8"),
    "/domain": ("domain.html", "text/html; charset=utf-8"),
    "/common86.js": ("common86.js", "application/javascript"),
    "/favicon.ico": ("favicon.ico", "image/x-icon"),
}

# Old links, bookmarks and the operator's muscle memory keep working;
# nothing serves two copies of a page. /home was the original landing path
# before the feed moved to /; Report and Authors became sections of Stats
# and Users respectively.
LEGACY_REDIRECTS = {
    "/home": "/",
    "/report": "/stats",
    "/authors": "/users",
    "/userlist": "/users",
}

NIP98_KIND = 27235
NIP98_MAX_SKEW = 60
NIP98_REPLAY_TTL = NIP98_MAX_SKEW * 2  # remember used auth event ids this long
NAME_CACHE_TTL = 24 * 3600

# --- bounds --------------------------------------------------------------
# Every bound in the project, in one block, so the bounded-scan rule can be
# audited by reading this block alone. Every scan is bounded by either a
# constant `limit`, a HARD wall-clock deadline, or an explicit `authors`
# list assembled from data server86 already holds — nothing else counts as
# a bound, per the hard constraint in CLAUDE.md.
#
# Two kinds of bound live here, and they are not interchangeable:
#   - HARD: guards a subprocess deadline or a process-lifetime in-memory
#     buffer. Never raise one of these without measuring what it actually
#     costs — see AUTHOR_SCAN_DEADLINE below for what that measurement
#     looks like.
#   - CONFIGURABLE (marked below, defined near CONFIG_EDITABLE_FIELDS):
#     an operator preference with no memory/subprocess consequence of its
#     own — bounded, if at all, by a HARD constant that stays fixed
#     regardless of the configured value. The value here is only the
#     factory default; get_<name>() near CONFIG_EDITABLE_FIELDS is the
#     actual accessor every call site uses.
#
# A scan backed by run_strfry_scan_streaming() never buffers more than one
# event at a time, so it has nothing left to cap except its HARD deadline —
# AUTHOR_SCAN_FULL_LIMIT, RECIPIENT_SCAN_LIMIT and SUBSCRIBER_SCAN_LIMIT
# used to impose an extra count cap on top of that anyway, which meant a
# "full" scan quietly stopped being full on a relay big enough to reach the
# count before the deadline. Removed; AUTHOR_SCAN_DEADLINE is now the only
# bound on all three, and hitting it is a "ran out of time" result, not a
# failure — see compute_authors/compute_recipients/compute_subscribers.

AUTHOR_SCAN_KINDS = (
    # The SHIPPED default — every kind EXCEPT 1059 (gift wraps: single-use
    # keys, structurally unbannable, and 88% of events on the reference
    # relay). See CLAUDE.md "Auditing the allowlist" for how this tuple is
    # checked for drift against a live relay — test.sh runs that check when
    # one is reachable. This is a floor, never the full picture on its
    # own — an operator can ADD kinds via config.json's
    # `extra_author_scan_kinds` (CONFIGURABLE, see CONFIG_EDITABLE_FIELDS)
    # but can never remove one of these; every scan/count/comparison in
    # this file that means "the allowlist" reads
    # get_effective_author_scan_kinds(), never this tuple directly, except
    # the two places that exist specifically to define or audit the
    # shipped default itself.
    0, 1, 3, 4, 5, 6, 7, 21, 42, 321, 445, 1000, 1018, 1040, 1111, 1311, 1337,
    1618, 1619, 1984, 1985, 2003, 4000, 4244, 5300, 6300, 7000, 9735, 10002,
    10050, 30000, 30023, 30078, 30166, 30383, 30800, 34236, 36787, 420001,
)
AUTHOR_SCAN_MODES = {
    # Selectable by NAME only; a request never supplies a filter, a limit,
    # or a kinds array — see the mode validation in do_POST. "full"'s
    # `kinds` is deliberately absent here — it would freeze the SHIPPED
    # default at import time, before an operator's config.json is ever
    # read. compute_authors fills it in per-call from
    # get_effective_author_scan_kinds() instead.
    "recent": {"limit": 20000},  # all kinds, newest 20k, ~3s — a UI mode, not a completeness claim
    "full": {},                  # kinds filled in per-call; every effective-allowlist event, NO count limit
}
# HARD — wall-clock deadline for every streaming deep scan (full author
# scan, recipient scan, subscriber scan). Measured on the reference relay
# (2026-08-23): AUTHOR_SCAN_KINDS matched 914,357 events and the full scan
# took ~137s — 103s of headroom, so the allowlisted event count would have
# to grow ~75% from here before this deadline binds. When it does bind, the
# scan does not fail: it returns whatever it read so far, flagged the same
# way a saturated bounded scan used to be (see `saturated`/`timed_out`
# below), just triggered by the clock instead of a count.
AUTHOR_SCAN_DEADLINE = 240
REPORT_WALK_DEADLINE = 1800     # HARD — seconds; FAILURE timeout for the one all-or-nothing scan (see compute_report_walk): a partial database walk is not a usable totals record, so this one still raises and discards on timeout, unlike AUTHOR_SCAN_DEADLINE above.
REPORT_AUTHOR_KEY_BYTES = 8     # bytes of pubkey retained per distinct non-giftwrap author during the walk
RATE_SMOOTHING_WINDOW = 10      # seconds of history the live throughput estimate (rate/eta) averages over
SCAN_TIMEOUT = 10               # HARD — seconds; every other scan subprocess
# An `authors: [...]` filter is a different shape of work than a `limit`-
# bounded scan — strfry has to check each listed author, not just stream
# and stop at a row count — and on a large database SCAN_TIMEOUT's 10s can
# be too tight for that, silently: the whole batch gets cached as "no name
# found" for NAME_CACHE_TTL, indistinguishable from an actual absent
# profile. See _resolve_profiles_locally.
NAME_RESOLVE_SCAN_TIMEOUT = 60  # HARD — seconds
PROFILE_PREVIEW_MAX = 20        # event previews retained from a profile's kind-tally read — pure in-memory slice of an already-fetched list, not its own scan bound
# --- rendering: display only — no memory or subprocess bound of its own ---
RENDER_PAGE_MAX = 500           # rows the client renders/paginates per page. Kept a separate name from the live-buffer constants below on purpose: those bound a persistent shared buffer, this bounds nothing but one response's row count, and conflating them once meant raising "the display size" silently multiplied a process-lifetime buffer three times over.
# --- allowlist audit: size and actionability are separate questions -------
GAP_NOTICE_SHARE = 0.02         # gap worth a sentence, never an alarm on its own
KIND_ALARM_SHARE = 0.005        # ONE unlisted kind this big is the actionable alarm
# --- stats console (read-only) ---------------------------------------------
CONSOLE_VERBS = ("scan", "info", "export")  # --count/read-only; all else refused
CONSOLE_STDOUT_MAX = 256 * 1024  # HARD — cap on captured console stdout (then kill the child)
CONSOLE_STDERR_MAX = 64 * 1024   # HARD — cap on captured console stderr
# The HTTP response's own tail slice — distinct from the two caps above.
# CONSOLE_STDOUT_MAX/CONSOLE_STDERR_MAX bound what run_console_command ever
# holds in memory; these bound what actually goes out over the wire to the
# console pane, same tail-favoring shape, just sized for a browser pane
# instead of a memory budget. Every response names its own total/shown byte
# counts so a slice here is never silent the way it used to be.
CONSOLE_RESPONSE_STDOUT_MAX = 32 * 1024
CONSOLE_RESPONSE_STDERR_MAX = 8 * 1024
# --- memory ceilings -------------------------------------------------------
# Soft: refuse NEW heavy jobs when current RSS is already this high (leave
# headroom for the job itself). CACHE_LIST_MAX is the safety valve on
# author/recipient row lists that otherwise grow with every distinct pubkey a
# scan has ever seen — client search still runs over the retained head
# (highest signal first); the omitted tail is named on the result. This one
# got MORE load-bearing once AUTHOR_SCAN_FULL_LIMIT/RECIPIENT_SCAN_LIMIT
# were removed above: it is now the only thing standing between an
# uncapped author/recipient scan and an unbounded retained row list, so it
# stays HARD.
#
# There is deliberately NO RLIMIT_AS hard cap. It limits ADDRESS SPACE, not
# RSS, and every strfry subprocess inherits it — strfry opens its LMDB with
# mmap over the configured dbParams.mapsize, which reserves address space far
# larger than the database, so any modest RLIMIT_AS makes every single scan
# die with `mdb_env_open: Out of memory`. Lowering the hard limit also can't
# be undone by a child, so there is no per-spawn escape hatch either. Growth
# this project actually controls is bounded where it happens: CONSOLE_STDOUT_MAX,
# STREAM_STDERR_MAX, CACHE_LIST_MAX, POST_BODY_MAX, and the soft gate below.
MEMORY_SOFT_BYTES = 400 * 1024 * 1024   # HARD — refuse new scan jobs above this RSS
CACHE_LIST_MAX = 50000          # HARD — max author/recipient rows retained after a scan
STREAM_STDERR_MAX = 64 * 1024   # HARD — stderr retained from a streaming scan
POST_BODY_MAX = 2 * 1024 * 1024 # HARD — NIP-98 POST bodies (settings raw is the largest)
GZIP_MIN_BYTES = 1024           # below this, gzip's own framing overhead isn't worth it
GZIP_LEVEL = 6                  # zlib level 6: ~9% smaller than level 1 for ~2x the CPU
# --- live layer: one shared strfry poll fanned out over SSE (all HARD) -----
# Every constant below bounds a process-lifetime buffer held ONCE and shared
# by every connected SSE client, not a per-request or per-client cost —
# raising any of these multiplies persistent server RSS, not just one
# response. (This is exactly the distinction RENDER_PAGE_MAX above was split
# out of: that one bounds a single response, these bound the server for as
# long as it runs.)
LIVE_POLL_INTERVAL = 3          # seconds between `since`-bounded polls of new events
# One row here (id/pubkey hex strings, up to LIVE_CONTENT_MAX=280 bytes of
# content, a handful of small fields) is on the order of ~1KB as a Python
# dict. At LIVE_BUFFER_MAX=500 + LIVE_EPHEMERAL_MAX=100 rows, the two rings
# together hold on the order of ~600KB, once, for the life of the process —
# not per client, not per poll tick.
LIVE_BUFFER_MAX = 500           # durable-kind ring size AND the poll's own scan limit= (never fetch more per tick than the ring retains)
# Two rings, two caps: NIP-16 ephemeral kinds (20000–29999) must not share a
# slot budget with durable notes. The default / filter is "kinds with content";
# ephemeral auth/presence usually has none, so a single shared ring looked
# like content "disappearing" while it was only being shoved out by spam.
LIVE_EPHEMERAL_MAX = 100        # kinds 20000–29999 only; inspectable, not starvation
LIVE_FEED_SEED = 50             # newest durable events loaded at startup so / is never blank
# Overfetch ceiling when seeding: newest-N of ALL kinds can be almost all
# ephemeral under auth spam; scan farther, then partition into the two pools.
LIVE_FEED_SEED_SCAN_MAX = 2000  # hard cap on the seed scan's limit=
LIVE_CONTENT_MAX = 280          # content bytes retained per ring row (preview, not full body)
# --- decision log: the only channel that can see a REJECT ------------------
DECISION_TAIL_MAX = 500         # HARD — newest decision records read back per poll; a transient list, same size as LIVE_BUFFER_MAX by convention only, not aliased to it (a decision record and a live-feed row are different shapes and can drift independently)
DECISION_READ_BYTES = 1 << 20   # HARD — bytes read from the tail of each log segment

_strfry_bin_path = None
_strfry_bin_checked = False

_relay_cwd_pid = None
_relay_cwd_path = None
_relay_conf_path = None

# The author list is never recomputed on a timer or because it went stale
# — only POST /api/authors/scan (an explicit admin button press) starts a
# scan, which then runs in a background thread so the request never blocks.
#
# ONE global lock is shared by every asynchronous scan in the project
# (author list, gift-wrap recipients, DM/general-relay-list subscribers,
# report totals, report walk) — see _start_scan_job / _run_scan_job below.
# Running two of these concurrently would contend the same LMDB and the
# same disk, which is slower than running them in series and destroys the
# throughput measurement every progress estimate depends on. _active_scan
# names whichever job currently holds it, or None; _JOB_REGISTRY maps a
# job name to the job-status dict a blocked POST should echo back.
_scan_lock = threading.Lock()
_active_scan = {"name": None}
_JOB_REGISTRY = {}  # populated once every job dict below has been created

_authors_job = {
    "status": "idle", "mode": None, "started_at": None,
    "progress": None, "total": None, "rate": None, "eta": None,
    # Mid-scan top authors for the Users table. Lives on the job, never on
    # the persisted cache — a failed run must not look like a result (rule 6).
    "partial_authors": None,
}
# _authors_cache is initialized after _load_cache_or()/_empty_authors_result() are defined below.

CONTACT_APPEAL_CHECK_INTERVAL = 1.0
_contact_appeal_cache = ""
_contact_appeal_mtime = None
_contact_appeal_last_checked = None


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def _process_rss_bytes():
    """Current resident set size in bytes, or None if unreadable.

    Prefers /proc (Linux). Falls back to `ps` (macOS and most Unix). Used only
    as a soft gate before launching a heavy job — never on the event path."""
    try:
        with open("/proc/self/status", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    try:
        out = subprocess.check_output(
            ["ps", "-o", "rss=", "-p", str(os.getpid())],
            text=True, timeout=1,
        ).strip()
        return int(out) * 1024
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _cap_list_rows(rows, max_rows=CACHE_LIST_MAX):
    """Keep the head of an already-ranked list; return (rows, total, omitted).

    Callers sort highest-signal first (event count, reporters, …). The tail
    is dropped so a full author/recipient scan cannot pin hundreds of MB of
    single-event keys for the life of the process."""
    total = len(rows)
    if total <= max_rows:
        return rows, total, 0
    return rows[:max_rows], total, total - max_rows


def load_config():
    with open(CONFIG_PATH, "r") as f:
        cfg = json.load(f)
    admin = cfg["admin_pubkey_hex"]
    # Store lowercase only — plugin86 and ban enforcement match event
    # pubkeys (always lowercase hex). Mixed-case config would desync the two.
    if not is_hex64(admin):
        raise ValueError("admin_pubkey_hex missing or not 64 hex characters")
    return {
        "admin_pubkey_hex": admin.lower(),
        "port": int(cfg.get("port", 8686)),
        "bind": cfg.get("bind", "0.0.0.0"),
    }


def get_contact_appeal():
    """Return the current contact_appeal string, re-reading config.json when
    its mtime changes (checked at most once per second). Never raises —
    a hand-edited or briefly-invalid config.json just keeps the last good
    value."""
    global _contact_appeal_cache, _contact_appeal_mtime, _contact_appeal_last_checked
    now = time.monotonic()
    if _contact_appeal_last_checked is not None and (now - _contact_appeal_last_checked) < CONTACT_APPEAL_CHECK_INTERVAL:
        return _contact_appeal_cache
    _contact_appeal_last_checked = now
    try:
        mtime = os.stat(CONFIG_PATH).st_mtime
    except OSError:
        return _contact_appeal_cache
    if mtime == _contact_appeal_mtime:
        return _contact_appeal_cache
    _contact_appeal_mtime = mtime
    try:
        with open(CONFIG_PATH, "r") as f:
            cfg = json.load(f)
        value = cfg.get("contact_appeal")
        _contact_appeal_cache = value if isinstance(value, str) else ""
    except (OSError, ValueError):
        pass
    return _contact_appeal_cache


def compute_event_id(pubkey, created_at, kind, tags, content):
    data = [0, pubkey, created_at, kind, tags, content]
    serialized = json.dumps(data, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def is_hex64(s):
    """True if `s` is exactly 64 hex characters (any case). Callers that
    store or compare pubkeys must use .lower() / as_hex64() so mixed-case
    input cannot create a ban that never matches an event."""
    if not isinstance(s, str) or len(s) != 64:
        return False
    try:
        int(s, 16)
    except ValueError:
        return False
    return True


def as_hex64(s):
    """Return lowercase 64-hex if valid, else None."""
    if not is_hex64(s):
        return None
    return s.lower()


def get_tag(tags, name):
    for tag in tags:
        if isinstance(tag, list) and len(tag) >= 2 and tag[0] == name:
            return tag[1]
    return None


def event_expiration(tags):
    """The NIP-40 `expiration` timestamp of an event, or None when it
    carries no well-formed one. The tag holds a unix timestamp (as a
    string) past which the event is expired; a relay may stop serving it
    and delete it, but strfry keeps it on disk until a delete actually
    runs, so an expired event is live storage a full walk still sees. A
    non-integer value is treated as absent rather than as an error: a
    malformed tag is not a promise about lifetime."""
    raw = get_tag(tags, "expiration")
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def get_strfry_bin():
    """Discover the strfry binary path once per process lifetime and cache
    it for every subsequent scan: prefer PATH via shutil.which, else the
    first existing+executable fallback candidate. Returns None if nothing
    is found."""
    global _strfry_bin_path, _strfry_bin_checked
    if _strfry_bin_checked:
        return _strfry_bin_path
    _strfry_bin_checked = True
    found = shutil.which("strfry")
    if not found:
        for candidate in STRFRY_BIN_CANDIDATES:
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                found = candidate
                break
    _strfry_bin_path = found
    return found


def require_strfry_bin():
    """Return the discovered strfry binary path or raise, so callers report
    a clear cause instead of a bare 'file not found' from subprocess."""
    bin_path = get_strfry_bin()
    if bin_path is None:
        raise RuntimeError(
            "strfry binary not found (tried PATH and " + ", ".join(STRFRY_BIN_CANDIDATES) + ")"
        )
    return bin_path


def _relay_conf_from_args(args):
    """Pull the --config value out of a relay process's argv, in either the
    `--config X` or `--config=X` form."""
    for i, arg in enumerate(args):
        if arg == "--config" and i + 1 < len(args):
            return args[i + 1]
        if arg.startswith("--config="):
            return arg.split("=", 1)[1]
    return None


def locate_relay_process():
    """Find the RUNNING strfry relay via /proc and return its cwd and its
    --config path. This process is the authority on both questions: whatever
    config the relay was started with is by definition the active one, and
    whatever directory it was started from is where its relative `db` path
    resolves. Cached until the located pid disappears; falls back to the
    binary's parent directory when /proc is unavailable or the relay has not
    started yet."""
    global _relay_cwd_pid, _relay_cwd_path, _relay_conf_path
    if _relay_cwd_pid is not None and os.path.isdir(f"/proc/{_relay_cwd_pid}"):
        return _relay_cwd_path, _relay_conf_path

    strfry_bin = require_strfry_bin()
    bin_name = os.path.basename(strfry_bin)
    try:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            try:
                with open(f"/proc/{entry}/cmdline", "rb") as f:
                    args = [a.decode("utf-8", "replace") for a in f.read().split(b"\x00") if a]
            except OSError:
                continue
            if not args or os.path.basename(args[0]) != bin_name or "relay" not in args[1:]:
                continue
            try:
                cwd = os.readlink(f"/proc/{entry}/cwd")
            except OSError:
                continue
            conf = _relay_conf_from_args(args)
            if conf and not os.path.isabs(conf):
                conf = os.path.normpath(os.path.join(cwd, conf))
            _relay_cwd_pid = entry
            _relay_cwd_path = cwd
            _relay_conf_path = conf
            return cwd, conf
    except OSError:
        pass

    _relay_cwd_pid = None
    _relay_cwd_path = os.path.dirname(strfry_bin)
    _relay_conf_path = None
    return _relay_cwd_path, None


def get_relay_cwd():
    """The working directory `strfry scan` must run from.

    strfry.conf commonly points `db` at a path relative to wherever the relay
    process itself was launched (e.g. dockurr/strfry runs `./strfry` from
    `/app` with `db = "./strfry-db/"`). server86 is spawned by plugin86 with
    cwd=SCRIPT_DIR, which is NOT that directory, so a scan subprocess with no
    cwd override resolves the relative db path against the wrong directory and
    strfry exits 1 with `mdb_env_open: No such file or directory`."""
    return locate_relay_process()[0]


def strfry_conf_status():
    """Where strfry.conf is, and how that was decided.

    Returns {path, source, exists, candidates, detected, error}. `source` is
    one of 'config.json' (an explicit strfry_conf_path override), 'relay
    process' (read from the running relay's own --config argument), 'default
    location' (the first candidate that exists), or None when nothing was
    found. Pointing at the wrong file is the failure this exists to prevent:
    strfry will happily read any valid config and open whatever database THAT
    one names, so a scan can return a confident count from a database the
    running relay has never written to."""
    override = None
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh).get("strfry_conf_path")
        if isinstance(raw, str) and raw.strip():
            override = raw.strip()
    except (OSError, ValueError):
        pass

    try:
        detected = locate_relay_process()[1]
    except RuntimeError:
        detected = None

    status = {
        "candidates": list(STRFRY_CONF_CANDIDATES),
        "detected": detected,
        "override": override,
        "error": None,
    }

    if override:
        status.update({"path": override, "source": "config.json",
                       "exists": os.path.isfile(override)})
        if not status["exists"]:
            status["error"] = f"{override} does not exist"
        elif detected and os.path.realpath(detected) != os.path.realpath(override):
            # Not an error — an operator may deliberately point here — but it
            # is exactly the situation that produces figures from the wrong
            # database, so it is never left unsaid.
            status["error"] = f"relay is using {detected}, not this file"
        return status

    if detected and os.path.isfile(detected):
        status.update({"path": detected, "source": "relay process", "exists": True})
        return status

    for candidate in STRFRY_CONF_CANDIDATES:
        if os.path.isfile(candidate):
            status.update({"path": candidate, "source": "default location", "exists": True})
            if detected:
                status["error"] = f"relay is using {detected}, not this file"
            return status

    status.update({"path": detected, "source": None, "exists": False})
    status["error"] = "no strfry.conf found"
    return status


def get_strfry_conf_path():
    status = strfry_conf_status()
    return status["path"] if status.get("exists") else None


def require_strfry_conf():
    """Return the active strfry.conf path or raise naming what was tried, so a
    scan failure says "I could not find your config" rather than handing back
    strfry's own error about a file the operator never chose."""
    status = strfry_conf_status()
    if not status.get("exists"):
        raise RuntimeError(status.get("error") or "strfry.conf not found")
    return status["path"]


STDERR_TAIL_CHARS = 300


def stderr_tail(stderr_bytes):
    """Return the last ~300 chars of a failed scan's stderr. strfry's loguru
    output puts a startup banner first and the actual error (tao::json parse
    or LMDB env open) as the LAST line, so the head of stderr is useless for
    diagnosis — always take the tail."""
    text = stderr_bytes.decode("utf-8", errors="replace").strip()
    return text[-STDERR_TAIL_CHARS:]


def _run_strfry(filter_obj, timeout):
    """Run `strfry scan <filter>` and return raw stdout bytes.

    The filter is passed as exactly ONE argv element of compact JSON with
    shell=False — never a single command string, never .split(), never
    quoted or backslash-escaped (escaped quotes reach strfry verbatim and it
    exits 1). Raises on any failure (missing binary, timeout, non-zero exit)
    so callers can report the cause instead of silently returning nothing.

    `strfry scan --count` also exists (undocumented in strfry's public
    README, which shows only body-printing `strfry scan '<filter>'`; confirm
    against the deployed strfry's source before relying on its exact
    behavior) but nothing here calls it: the command-block UI only shows
    `--count` as copyable text for the operator to run themselves, per the
    "no scan without an explicit admin request" rule — server86 never
    invokes it as a subprocess."""
    strfry_bin = require_strfry_bin()
    filter_json = json.dumps(filter_obj, separators=(",", ":"))
    argv = [strfry_bin, "--config", require_strfry_conf(), "scan", filter_json]
    result = subprocess.run(argv, cwd=get_relay_cwd(), capture_output=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError(f"strfry scan exited {result.returncode}: {stderr_tail(result.stderr)}")
    return result.stdout


def run_strfry_scan(filter_obj, timeout=SCAN_TIMEOUT):
    """Run `strfry scan <filter>` and return a list of parsed event dicts.
    Used only for small, already-bounded scans (an explicit `authors` list)
    where holding the full result in memory is fine."""
    events = []
    for line in _run_strfry(filter_obj, timeout).decode("utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    return events


# --- live layer: one shared strfry poll loop fanned out over SSE -----------
# A single background thread polls `strfry scan {"since": ...}` on an
# interval and keeps a small ring buffer plus running deltas that every
# connected / and /stats tab reads from the SAME state — N open tabs
# cost ONE poll loop, never N (WHY.md §6). This is a delta layer only: a
# freshly connected client renders nothing until the next tick finds
# something new (rule 9's progressive fill, never a history replay), and a
# poll failure just retries on the next tick from the same cursor rather
# than trying to patch through the gap it missed. The numeric delta (+N
# events, -M deletes) is always relative to the freshest report totals/walk
# `scanned_at` — the moment an admin presses either report button, that
# scan's own count becomes the new baseline and the delta resets to zero,
# which is what "figures = last cache PLUS live deltas since" means in
# practice. Kind-5 events increment `deletes` but are also counted once in
# `new_events`, matching stats.html's own "+N events, -M deletes" wording.

_live_lock = threading.Lock()
_live_since = int(time.time())      # poll cursor: only events at/after this are new
_live_seen_at_since = set()         # ids already counted AT exactly _live_since (dedup)
_live_delta_baseline_at = None      # scanned_at this delta count is relative to
_live_new_events = 0
_live_deletes = 0
_live_recent_durable = []           # non-ephemeral kinds; cap LIVE_BUFFER_MAX
_live_recent_ephemeral = []         # kinds 20000–29999; cap LIVE_EPHEMERAL_MAX
_live_error = None
_live_subscribers = []              # list of queue.Queue, one per open SSE connection


def _live_current_baseline_at():
    """The freshest totals/walk scanned_at, or None before either has ever
    run — the anchor the live delta counts forward from."""
    with _scan_lock:
        totals_at = _report_cache["totals"].get("scanned_at")
        walk_at = _report_cache["walk"].get("scanned_at")
    candidates = [t for t in (totals_at, walk_at) if t is not None]
    return max(candidates) if candidates else None


def _live_broadcast(msg):
    with _live_lock:
        subs = list(_live_subscribers)
    for q in subs:
        try:
            q.put_nowait(msg)
        except queue.Full:
            with _live_lock:
                if q in _live_subscribers:
                    _live_subscribers.remove(q)


DECISION_LOG_PATH = os.path.join(SCRIPT_DIR, "decisions.jsonl")
DECISION_LOG_PREV_PATH = DECISION_LOG_PATH + ".1"


def _read_log_segment_tail(path):
    """Return the decoded tail of one decision-log segment, at most
    DECISION_READ_BYTES. Seeking to the end and reading backwards keeps the
    cost independent of how long the relay has been up; the first line of
    the result may be a fragment, so the caller drops it."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return "", False
    truncated = size > DECISION_READ_BYTES
    try:
        with open(path, "rb") as fh:
            if truncated:
                fh.seek(size - DECISION_READ_BYTES)
            raw = fh.read()
    except OSError:
        return "", False
    return raw.decode("utf-8", "replace"), truncated


def read_decisions(limit=DECISION_TAIL_MAX):
    """Newest-LAST list of plugin86's accept/reject records.

    This is the only place in the project where a REJECT is observable: a
    blocked event is never written to the database, so no `strfry scan` —
    which is everything else server86 has — can report one. Reading is
    bounded on both axes (bytes per segment, records returned) and never
    fails loudly: a missing log just means the relay has not decided
    anything since plugin86 last started, which is a normal state, not an
    error to render."""
    records = []
    for path in (DECISION_LOG_PREV_PATH, DECISION_LOG_PATH):
        text, truncated = _read_log_segment_tail(path)
        if not text:
            continue
        lines = text.split("\n")
        if truncated and lines:
            lines = lines[1:]        # first line is a fragment of a record
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if isinstance(rec, dict) and isinstance(rec.get("id"), str):
                records.append(rec)
    return records[-limit:]


_blocked_tally_lock = threading.Lock()
_blocked_tally_cache = {"key": None, "value": None}


def _decision_log_key():
    """Cheap fingerprint of the log's on-disk state, so the tally is recomputed
    when plugin86 has written since the last one and not otherwise."""
    key = []
    for path in (DECISION_LOG_PREV_PATH, DECISION_LOG_PATH):
        try:
            st = os.stat(path)
            key.append((int(st.st_mtime_ns), st.st_size))
        except OSError:
            key.append(None)
    return tuple(key)


def get_blocked_tally():
    """Per-pubkey count of events plugin86 REJECTED, over whatever of the
    decision log is still on disk.

    This is a FLOOR over a WINDOW, never a lifetime total, and there is no
    version of it that isn't: the log keeps two rotating segments and each is
    read from its tail up to DECISION_READ_BYTES, so a pubkey blocked ten
    thousand times last month and twice today counts as two. Callers render it
    with `≥` and name the window — the same rule the saturated gift-wrap
    column already follows. Recomputed only when the log has changed.

    Returns {"counts", "last_at", "window_start", "records", "truncated"}."""
    key = _decision_log_key()
    with _blocked_tally_lock:
        if _blocked_tally_cache["key"] == key and _blocked_tally_cache["value"] is not None:
            return _blocked_tally_cache["value"]

    counts, last_at = {}, {}
    window_start, records, truncated = None, 0, False
    for path in (DECISION_LOG_PREV_PATH, DECISION_LOG_PATH):
        text, was_truncated = _read_log_segment_tail(path)
        truncated = truncated or was_truncated
        if not text:
            continue
        lines = text.split("\n")
        if was_truncated and lines:
            lines = lines[1:]        # first line is a fragment of a record
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if not isinstance(rec, dict):
                continue
            records += 1
            at = rec.get("at")
            if isinstance(at, int) and (window_start is None or at < window_start):
                window_start = at
            if rec.get("action") != "reject":
                continue
            pubkey = rec.get("pubkey")
            if not is_hex64(pubkey):
                continue
            counts[pubkey] = counts.get(pubkey, 0) + 1
            if isinstance(at, int) and at > last_at.get(pubkey, 0):
                last_at[pubkey] = at

    value = {
        "counts": counts, "last_at": last_at, "window_start": window_start,
        "records": records, "truncated": truncated,
        # `present` separates "nothing was blocked" from "nothing judged
        # anything" — rule 9: an unmeasured cell renders `—`, never 0.
        "present": records > 0,
    }
    with _blocked_tally_lock:
        _blocked_tally_cache["key"] = key
        _blocked_tally_cache["value"] = value
    return value


def blocked_window_meta(tally):
    """The provenance block every page renders beside a blocked count."""
    return {
        "present": tally["present"],
        "window_start": tally["window_start"],
        "records": tally["records"],
        "truncated": tally["truncated"],
    }


def _feed_row_from_decision(rec):
    pubkey = rec.get("pubkey")
    content = rec.get("content")
    if isinstance(content, str):
        content = content[:LIVE_CONTENT_MAX]
    else:
        content = ""
    return {
        "id": rec.get("id"),
        "kind": rec.get("kind"),
        "created_at": rec.get("created_at") or rec.get("at"),
        "pubkey": pubkey if is_hex64(pubkey) else None,
        "name": None,
        "nip05": None,
        "content": content,
        "result": "blocked" if rec.get("action") == "reject" else "accepted",
        "msg": rec.get("msg") or "",
    }


def _feed_row_from_scan_event(ev):
    """One strfry-scan event as a public feed row. Author and content are
    intentional (CLAUDE.md `/` — a relay's accepted events are already
    public); `result` is always null because a scan cannot see a REJECT
    and must never claim "accepted" for an event nothing judged (rule 9)."""
    if not isinstance(ev, dict):
        return None
    eid, kind, created_at = ev.get("id"), ev.get("kind"), ev.get("created_at")
    if not isinstance(eid, str) or not isinstance(kind, int) or not isinstance(created_at, int):
        return None
    pubkey = ev.get("pubkey")
    if not is_hex64(pubkey):
        pubkey = None
    content = ev.get("content")
    if isinstance(content, str):
        content = content[:LIVE_CONTENT_MAX]
    else:
        content = ""
    return {
        "id": eid,
        "kind": kind,
        "created_at": created_at,
        "pubkey": pubkey,
        "name": None,
        "nip05": None,
        "content": content,
        "result": None,
        "msg": "",
    }


def _live_rings_snapshot():
    """Copy both rings under the lock. Callers merge / pad outside the lock."""
    with _live_lock:
        return list(_live_recent_durable), list(_live_recent_ephemeral)


def _merge_live_rings(durable, ephemeral):
    """Oldest-first merge of the two pools for the SSE `events` list."""
    rows = [_ring_row_as_feed(ev) for ev in durable]
    rows.extend(_ring_row_as_feed(ev) for ev in ephemeral)
    rows.sort(key=lambda r: r.get("created_at") or 0)
    return rows


def _dual_cap_feed_rows(rows):
    """Keep durable and ephemeral tails under separate caps, then re-merge.

    Applied to decision-log rows so auth spam in kinds 20000–29999 cannot
    shove durable judged events out of the visible feed either."""
    durable, ephemeral = [], []
    for r in rows:
        if is_ephemeral_kind(r.get("kind")):
            ephemeral.append(r)
        else:
            durable.append(r)
    durable = durable[-LIVE_BUFFER_MAX:]
    ephemeral = ephemeral[-LIVE_EPHEMERAL_MAX:]
    merged = durable + ephemeral
    merged.sort(key=lambda r: r.get("created_at") or 0)
    return merged


def _live_append_row_unlocked(row):
    """Route one row into the durable or ephemeral ring and trim that ring.
    Caller holds `_live_lock`."""
    if is_ephemeral_kind(row.get("kind")):
        _live_recent_ephemeral.append(row)
        del _live_recent_ephemeral[:-LIVE_EPHEMERAL_MAX]
    else:
        _live_recent_durable.append(row)
        del _live_recent_durable[:-LIVE_BUFFER_MAX]


def _live_feed_state():
    """Feed rows plus the accept/blocked tally they were counted from.

    Prefers the decision log, because it is the only source that contains
    blocked events at all. Falls back to the scan-fed rings — durable and
    ephemeral pools with separate caps, seeded at startup — when no
    decision log exists yet. In that fallback every `result` is null, never
    "accepted": a scan cannot distinguish an accept from an unjudged event,
    and rule 9 says an unknown renders as unknown.

    Both paths dual-cap so NIP-16 ephemeral traffic cannot starve durable
    content out of the buffer the default "kinds with content" filter reads."""
    decisions = read_decisions()
    durable_ring, ephemeral_ring = _live_rings_snapshot()
    ring_merged = _merge_live_rings(durable_ring, ephemeral_ring)

    if decisions:
        rows = _dual_cap_feed_rows(
            [_feed_row_from_decision(r) for r in decisions]
        )
        # Pad a short decision log from the durable seed first (what the
        # content filter will actually show), then ephemeral.
        durable_count = sum(1 for r in rows if not is_ephemeral_kind(r.get("kind")))
        if durable_count < LIVE_FEED_SEED:
            seen = {r.get("id") for r in rows if r.get("id")}
            for ev in durable_ring:
                eid = ev.get("id")
                if not eid or eid in seen:
                    continue
                rows.append(_ring_row_as_feed(ev))
                seen.add(eid)
                durable_count += 1
                if durable_count >= LIVE_FEED_SEED:
                    break
            rows.sort(key=lambda r: r.get("created_at") or 0)
        accepted = sum(1 for r in rows if r["result"] == "accepted")
        blocked = sum(1 for r in rows if r["result"] == "blocked")
        _join_feed_row_names(rows)
        return rows, accepted, blocked, True

    _join_feed_row_names(ring_merged)
    return ring_merged, None, None, False


def _join_feed_row_names(rows):
    """Fill in name/nip05 on feed rows from names.json, one batched
    namecache lookup per poll tick rather than one per row — this runs
    every LIVE_POLL_INTERVAL (3s) over up to ~600 rows, so per-row lookups
    would add up fast even though each one is cheap on its own."""
    pubkeys = [r["pubkey"] for r in rows if r.get("pubkey")]
    cached = _cached_names_only(pubkeys)
    for r in rows:
        hit = cached.get(r.get("pubkey"))
        if hit:
            r["name"] = hit.get("name")
            r["nip05"] = hit.get("nip05")
    return rows


def _ring_row_as_feed(ev):
    """Normalise a ring-buffer entry to the feed row shape. Seed/poll rows
    already carry the full public fields; a minimal legacy row (id/kind/
    created_at only) is tolerated so mid-test reloads cannot throw."""
    if not isinstance(ev, dict):
        return {
            "id": None, "kind": None, "created_at": None,
            "pubkey": None, "name": None, "nip05": None,
            "content": "", "result": None, "msg": "",
        }
    content = ev.get("content")
    return {
        "id": ev.get("id"),
        "kind": ev.get("kind"),
        "created_at": ev.get("created_at"),
        "pubkey": ev.get("pubkey") if is_hex64(ev.get("pubkey")) else None,
        "name": None,
        "nip05": None,
        "content": content if isinstance(content, str) else "",
        # Never invent "accepted" — only the decision log sets result.
        "result": ev.get("result") if ev.get("result") in ("accepted", "blocked") else None,
        "msg": ev.get("msg") or "",
    }


def _live_state_snapshot():
    rows, accepted, blocked, judged = _live_feed_state()
    with _live_lock:
        return {
            "new_events": _live_new_events, "deletes": _live_deletes,
            "baseline_at": _live_delta_baseline_at, "events": rows,
            "accepted": accepted, "blocked": blocked, "judged": judged,
            "error": _live_error, "at": int(time.time()),
        }


def _live_seed_scan_limit():
    """How far the startup seed scan reaches when hunting durable events
    under an ephemeral-heavy head. Bounded so a pathological DB cannot
    stream unbounded bodies into server86 at boot."""
    return min(LIVE_FEED_SEED_SCAN_MAX, max(LIVE_FEED_SEED * 40, LIVE_FEED_SEED))


def _live_seed_recent():
    """Load recent events into the durable and ephemeral rings at startup.

    Durable gets the newest LIVE_FEED_SEED non-ephemeral events so the
    default content filter has something to show immediately. Ephemeral
    gets its own tail (LIVE_EPHEMERAL_MAX) from the same scan. Overfetches
    under LIVE_FEED_SEED_SCAN_MAX because a plain limit=50 under auth spam
    is often fifty ephemeral rows and zero notes.

    History, not a delta: advances the poll cursor so seed rows are not
    re-counted into new_events / deletes."""
    global _live_since, _live_seen_at_since, _live_error
    scan_limit = _live_seed_scan_limit()
    try:
        events = run_strfry_scan({"limit": scan_limit}, timeout=SCAN_TIMEOUT)
    except Exception as e:
        log(f"server86: live feed seed failed: {type(e).__name__}: {e}")
        with _live_lock:
            if _live_error is None:
                _live_error = f"seed: {type(e).__name__}: {e}"[:300]
        return

    durable, ephemeral = [], []
    for ev in events:
        row = _feed_row_from_scan_event(ev)
        if row is None:
            continue
        if is_ephemeral_kind(row["kind"]):
            ephemeral.append(row)
        else:
            durable.append(row)
    durable.sort(key=lambda r: r.get("created_at") or 0)
    ephemeral.sort(key=lambda r: r.get("created_at") or 0)
    durable = durable[-LIVE_FEED_SEED:]
    ephemeral = ephemeral[-LIVE_EPHEMERAL_MAX:]
    if not durable and not ephemeral:
        return

    all_seeded = durable + ephemeral
    newest = max(r["created_at"] for r in all_seeded)
    with _live_lock:
        # Mutate in place (not rebind) so we don't need a global declaration
        # for the ring lists — only the cursor scalars are reassigned.
        _live_recent_durable[:] = durable
        _live_recent_ephemeral[:] = ephemeral
        if newest >= _live_since:
            _live_since = newest
            _live_seen_at_since = {
                r["id"] for r in all_seeded
                if r.get("created_at") == newest and isinstance(r.get("id"), str)
            }


def _live_poll_tick():
    """One poll cycle: re-anchor the delta baseline if a report scan just
    completed, then read events newer than the cursor and fold them into
    the durable / ephemeral rings and the session counters. Always
    broadcasts, even with zero new events, so the SSE stream is the heartbeat."""
    global _live_since, _live_seen_at_since, _live_delta_baseline_at
    global _live_new_events, _live_deletes, _live_error

    baseline_at = _live_current_baseline_at()
    with _live_lock:
        if baseline_at != _live_delta_baseline_at:
            _live_delta_baseline_at = baseline_at
            _live_new_events = 0
            _live_deletes = 0
            if baseline_at is not None and baseline_at > _live_since:
                _live_since = baseline_at
                _live_seen_at_since = set()

    try:
        events = run_strfry_scan({"since": _live_since, "limit": LIVE_BUFFER_MAX}, timeout=SCAN_TIMEOUT)
    except Exception as e:
        with _live_lock:
            _live_error = f"{type(e).__name__}: {e}"[:300]
        _live_broadcast(_live_state_snapshot())
        return

    events.sort(key=lambda ev: ev.get("created_at") or 0)
    folded = 0
    with _live_lock:
        _live_error = None
        new_high_water = _live_since
        for ev in events:
            row = _feed_row_from_scan_event(ev)
            if row is None:
                continue
            eid, kind, created_at = row["id"], row["kind"], row["created_at"]
            if created_at < _live_since:
                continue
            if created_at == _live_since and eid in _live_seen_at_since:
                continue
            _live_append_row_unlocked(row)
            _live_new_events += 1
            folded += 1
            if kind == 5:
                _live_deletes += 1
            if created_at > new_high_water:
                new_high_water = created_at
                _live_seen_at_since = {eid}
            elif created_at == new_high_water:
                _live_seen_at_since.add(eid)
        _live_since = new_high_water

    _record_rate_sample(folded)
    _live_broadcast(_live_state_snapshot())


def _live_poll_loop():
    while True:
        try:
            _live_poll_tick()
        except Exception as e:
            log(f"server86: live poll tick failed: {type(e).__name__}: {e}")
        time.sleep(LIVE_POLL_INTERVAL)


def clamp_giftwrap_retention_days(days):
    """Coerce a client-supplied day count into [MIN, MAX]. None → default."""
    if days is None or days == "":
        return GIFTWRAP_RETENTION_DEFAULT
    try:
        n = int(days)
    except (TypeError, ValueError):
        return GIFTWRAP_RETENTION_DEFAULT
    return max(GIFTWRAP_RETENTION_MIN, min(GIFTWRAP_RETENTION_MAX, n))


def giftwrap_retention_filter(now=None, days=None):
    """Filter object for the automatic kind-1059 age purge. Pure function so
    tests can pin `now` and `days` without a live config or clock."""
    days = clamp_giftwrap_retention_days(days if days is not None else get_giftwrap_retention_days())
    if now is None:
        now = int(time.time())
    return {"kinds": [1059], "until": int(now) - int(days) * 86400}


def estimate_giftwrap_retention(days, now=None):
    """How many kind-1059 events a purge at `days` would delete, plus a
    proportional storage estimate. Event count is exact (index --count);
    bytes are estimated as delete_count/total × db_bytes — gift wraps are
    not uniform in size, so this is a planning figure, not a promise."""
    days = clamp_giftwrap_retention_days(days)
    filt = giftwrap_retention_filter(now=now, days=days)
    delete_count = run_strfry_count(filt)
    totals = (get_report_status().get("totals") or {})
    total_events = totals.get("total_events")
    if total_events is None:
        total_events = run_strfry_count({})
    giftwrap_events = totals.get("giftwrap_events")
    if giftwrap_events is None:
        giftwrap_events = run_strfry_count({"kinds": [1059]})
    db_bytes, _ = _strfry_db_bytes()
    event_share = (delete_count / total_events) if total_events else None
    giftwrap_share = (delete_count / giftwrap_events) if giftwrap_events else None
    bytes_est = int(db_bytes * event_share) if db_bytes is not None and event_share is not None else None
    return {
        "days": days,
        "until": filt["until"],
        "delete_events": delete_count,
        "total_events": total_events,
        "giftwrap_events": giftwrap_events,
        "event_share": event_share,
        "giftwrap_share": giftwrap_share,
        "bytes_estimate": bytes_est,
        "db_bytes": db_bytes,
        "estimate_note": "storage is proportional to event count, not measured free space",
    }


def run_giftwrap_retention_purge(days=None):
    """Delete kind-1059 events older than the retention window. `days`
    overrides the saved setting (Purge now on Settings); the hourly loop
    leaves it None and uses config. Blanket form — no subscriber exemption.
    Failures are returned (and logged) so a stuck delete never kills the
    server process. Synchronous; the Settings button uses the async job
    wrapper below so the UI can poll progress."""
    days = clamp_giftwrap_retention_days(days if days is not None else get_giftwrap_retention_days())
    try:
        strfry_bin = require_strfry_bin()
        conf = require_strfry_conf()
    except RuntimeError as e:
        log(f"server86: giftwrap retention skipped: {e}")
        return False, str(e), None
    filt = giftwrap_retention_filter(days=days)
    filter_json = json.dumps(filt, separators=(",", ":"))
    argv = [strfry_bin, "--config", conf, "delete", "--filter", filter_json]
    try:
        result = subprocess.run(
            argv, cwd=get_relay_cwd(), capture_output=True,
            timeout=GIFTWRAP_RETENTION_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        log(f"server86: giftwrap retention timed out after {GIFTWRAP_RETENTION_TIMEOUT}s")
        return False, "timeout", None
    except Exception as e:
        log(f"server86: giftwrap retention failed: {type(e).__name__}: {e}")
        return False, f"{type(e).__name__}: {e}", None
    if result.returncode != 0:
        err = (result.stderr or b"").decode("utf-8", "replace")[-300:]
        log(f"server86: giftwrap retention exit {result.returncode}: {err}")
        return False, err or f"exit {result.returncode}", None
    log(f"server86: giftwrap retention ok (until={filt['until']}, days={days})")
    return True, None, filt


def ephemeral_kinds_filter():
    """Nostr filter matching every NIP-16 ephemeral kind (20000–29999).
    Kind ranges do not exist in NIP-01, so this is the full list."""
    return {"kinds": _EPHEMERAL_KINDS}


def is_ephemeral_kind(kind):
    return isinstance(kind, int) and EPHEMERAL_KIND_MIN <= kind <= EPHEMERAL_KIND_MAX


def estimate_ephemeral_storage():
    """Index count of kinds 20000–29999 plus a proportional storage estimate.
    Same shape as gift-wrap estimate: event count is exact; bytes are
    count/total × db size (planning figure, not free-space measurement)."""
    filt = ephemeral_kinds_filter()
    ephemeral_events = run_strfry_count(filt, timeout=AUTHOR_SCAN_DEADLINE)
    totals = (get_report_status().get("totals") or {})
    total_events = totals.get("total_events")
    if total_events is None:
        total_events = run_strfry_count({}, timeout=AUTHOR_SCAN_DEADLINE)
    db_bytes, _ = _strfry_db_bytes()
    event_share = (ephemeral_events / total_events) if total_events else None
    bytes_est = int(db_bytes * event_share) if db_bytes is not None and event_share is not None else None
    return {
        "ephemeral_events": ephemeral_events,
        "total_events": total_events,
        "event_share": event_share,
        "bytes_estimate": bytes_est,
        "db_bytes": db_bytes,
        "kind_min": EPHEMERAL_KIND_MIN,
        "kind_max": EPHEMERAL_KIND_MAX,
        "estimate_note": "storage is proportional to event count, not measured free space",
    }


def run_ephemeral_purge():
    """Delete every event of kind 20000–29999. Synchronous; Settings uses
    the async job wrapper. Failures are returned so a stuck delete never
    kills the server process."""
    try:
        strfry_bin = require_strfry_bin()
        conf = require_strfry_conf()
    except RuntimeError as e:
        log(f"server86: ephemeral purge skipped: {e}")
        return False, str(e), None
    filt = ephemeral_kinds_filter()
    filter_json = json.dumps(filt, separators=(",", ":"))
    argv = [strfry_bin, "--config", conf, "delete", "--filter", filter_json]
    try:
        result = subprocess.run(
            argv, cwd=get_relay_cwd(), capture_output=True,
            timeout=EPHEMERAL_PURGE_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        log(f"server86: ephemeral purge timed out after {EPHEMERAL_PURGE_TIMEOUT}s")
        return False, "timeout", None
    except Exception as e:
        log(f"server86: ephemeral purge failed: {type(e).__name__}: {e}")
        return False, f"{type(e).__name__}: {e}", None
    if result.returncode != 0:
        err = (result.stderr or b"").decode("utf-8", "replace")[-300:]
        log(f"server86: ephemeral purge exit {result.returncode}: {err}")
        return False, err or f"exit {result.returncode}", None
    log("server86: ephemeral purge ok (kinds 20000–29999)")
    return True, None, filt


# --- ephemeral purge job (Settings "Purge ephemeral kinds") -----------------
# Same shape as giftwrap-purge: count → delete under the global scan lock.
# No hourly auto loop — RelayCron is supposed to keep these short-lived;
# this is the operator cleanup when that has lagged or lifetime was high.
_ephemeral_purge_job = {
    "status": "idle", "started_at": None, "progress": None, "total": None,
    "rate": None, "eta": None, "phase": None, "error": None,
    "finished_at": None, "counted": None,
}
_JOB_REGISTRY["ephemeral-purge"] = _ephemeral_purge_job


def get_ephemeral_purge_status(include_detail=False):
    with _scan_lock:
        status = dict(_ephemeral_purge_job)
        running = _active_scan["name"]
    status["blocked_by"] = running if running not in (None, "ephemeral-purge") else None
    error = status.get("error")
    status["failed"] = bool(error) or status.get("phase") == "failed"
    if not include_detail:
        status.pop("error", None)
    return status


def _run_ephemeral_purge_job():
    error = None
    counted = None
    try:
        with _scan_lock:
            _ephemeral_purge_job["phase"] = "counting"
            _ephemeral_purge_job["progress"] = 0
            _ephemeral_purge_job["total"] = None
        filt = ephemeral_kinds_filter()
        total = run_strfry_count(filt, timeout=AUTHOR_SCAN_DEADLINE)
        with _scan_lock:
            _ephemeral_purge_job["total"] = total
            _ephemeral_purge_job["progress"] = 0
            _ephemeral_purge_job["phase"] = "deleting"
        ok, err, _used = run_ephemeral_purge()
        if not ok:
            error = err or "purge failed"
        else:
            counted = total
            with _scan_lock:
                _ephemeral_purge_job["progress"] = total
    except Exception as e:
        error = f"{type(e).__name__}: {e}"[:600]
        log(f"server86: ephemeral purge job failed: {error}")
    with _scan_lock:
        _ephemeral_purge_job["status"] = "idle"
        _ephemeral_purge_job["phase"] = "failed" if error else "done"
        _ephemeral_purge_job["error"] = error
        _ephemeral_purge_job["counted"] = counted
        _ephemeral_purge_job["finished_at"] = int(time.time())
        _ephemeral_purge_job["rate"] = None
        _ephemeral_purge_job["eta"] = None
        _active_scan["name"] = None


def start_ephemeral_purge(on_started=None):
    """Start one ephemeral-kind purge under the global job lock."""
    def run():
        _run_ephemeral_purge_job()

    return _start_scan_job(
        "ephemeral-purge", _ephemeral_purge_job, run,
        on_started=on_started,
        extra_job_fields={
            "phase": "starting", "error": None,
            "finished_at": None, "counted": None,
        },
    )


# --- gift-wrap purge job (Settings "Purge now") -----------------------------
# Async so the request is not held open for the whole delete. strfry's
# `delete` collects every matching levId then deletes in one write txn —
# there is no mid-delete event counter to stream — so progress is:
#   counting → total known → deleting (elapsed only) → idle with result.
# Shares the global scan lock: concurrent LMDB writers fight each other.
# `counted` is deliberately NOT called `deleted`: strfry's delete reports no
# count of its own, so the only number available is the one counted moments
# BEFORE the delete ran, against an age cutoff a few seconds earlier than the
# one the delete used. It is a good estimate and a bad fact, and the field
# name is where that distinction survives being passed around.
_giftwrap_purge_job = {
    "status": "idle", "started_at": None, "progress": None, "total": None,
    "rate": None, "eta": None, "days": None, "phase": None, "error": None,
    "finished_at": None, "counted": None, "counted_until": None, "until": None,
}
_JOB_REGISTRY["giftwrap-purge"] = _giftwrap_purge_job


def get_giftwrap_purge_status(include_detail=False):
    """Purge job status. `include_detail` adds the raw failure text, and is
    only ever true for an authenticated caller.

    That text is strfry's own stderr, which names the config file and the
    database directory — the same disclosure /api/metrics was deliberately
    scrubbed of. The public form keeps everything an operator needs to watch
    progress (phase, elapsed, whether it failed) and drops the one field that
    describes this machine's filesystem."""
    with _scan_lock:
        status = dict(_giftwrap_purge_job)
        running = _active_scan["name"]
    status["blocked_by"] = running if running not in (None, "giftwrap-purge") else None
    error = status.get("error")
    status["failed"] = bool(error) or status.get("phase") == "failed"
    if not include_detail:
        status.pop("error", None)
    return status


def _run_giftwrap_purge_job(days):
    """Background body for Settings Purge now. Counts first so the UI can say
    roughly how much the delete is about to remove, then runs the delete.
    Releases the global lock on every exit path.

    The count and the delete each work out their own age cutoff, seconds
    apart, so they do NOT describe the same set of events — anything that
    aged past the line in between is deleted but uncounted. Both cutoffs are
    reported (`counted_until` and `until`) and the count is never renamed
    into a deletion total."""
    error = None
    counted = None
    counted_until = None
    until = None
    try:
        with _scan_lock:
            _giftwrap_purge_job["phase"] = "counting"
            _giftwrap_purge_job["progress"] = 0
            _giftwrap_purge_job["total"] = None
        filt = giftwrap_retention_filter(days=days)
        counted_until = filt["until"]
        total = run_strfry_count(filt)
        with _scan_lock:
            _giftwrap_purge_job["total"] = total
            _giftwrap_purge_job["progress"] = 0
            _giftwrap_purge_job["phase"] = "deleting"
            _giftwrap_purge_job["counted_until"] = counted_until
        ok, err, used_filter = run_giftwrap_retention_purge(days=days)
        if not ok:
            error = err or "purge failed"
        else:
            counted = total
            # The cutoff the DELETE actually used, straight from the filter it
            # ran with — not the one the count used a moment earlier.
            until = used_filter["until"] if used_filter else None
            with _scan_lock:
                _giftwrap_purge_job["progress"] = total
    except Exception as e:
        error = f"{type(e).__name__}: {e}"[:600]
        log(f"server86: giftwrap purge job failed: {error}")
    with _scan_lock:
        _giftwrap_purge_job["status"] = "idle"
        _giftwrap_purge_job["phase"] = "failed" if error else "done"
        _giftwrap_purge_job["error"] = error
        _giftwrap_purge_job["counted"] = counted
        _giftwrap_purge_job["counted_until"] = counted_until
        _giftwrap_purge_job["until"] = until
        _giftwrap_purge_job["finished_at"] = int(time.time())
        _giftwrap_purge_job["rate"] = None
        _giftwrap_purge_job["eta"] = None
        _active_scan["name"] = None


def start_giftwrap_purge(days=None, on_started=None):
    """Start one purge under the global job lock. Returns the job status
    dict (status=running on start, or blocked_by if another job holds the
    lock). `on_started` fires only if this call launched the purge — the
    audit record hangs off it, so a refused press is never recorded as a
    deletion and an accepted one is never recorded as nothing."""
    days = clamp_giftwrap_retention_days(days if days is not None else get_giftwrap_retention_days())

    def run():
        _run_giftwrap_purge_job(days)

    status = _start_scan_job(
        "giftwrap-purge", _giftwrap_purge_job, run,
        on_started=on_started,
        extra_job_fields={
            "days": days, "phase": "starting", "error": None,
            "finished_at": None, "counted": None, "counted_until": None, "until": None,
        },
    )
    return status


def _giftwrap_retention_loop():
    # First pass waits a full interval so a restart storm cannot pile up
    # concurrent deletes against a just-starting LMDB. Goes through the
    # same job lock as Settings "Purge now", so a manual purge and the
    # hourly pass never run together.
    while True:
        time.sleep(GIFTWRAP_RETENTION_INTERVAL)
        try:
            status = start_giftwrap_purge()
            if status.get("blocked_by"):
                log(f"server86: giftwrap retention skipped — "
                    f"{status['blocked_by']} is running")
        except Exception as e:
            log(f"server86: giftwrap retention loop: {type(e).__name__}: {e}")


# --- DB compact (Settings "Compact" only — never the console) ---------------
# strfry compact writes a NEW compacted LMDB dump; it does NOT shrink the live
# data.mdb in place. Reclaiming free pages on disk means stopping the relay,
# replacing data.mdb with the compacted file, and starting again (strfry's own
# README). This job only performs the safe half: dump to
# <db>/data.mdb.compacted, report live vs compacted sizes, leave the swap to
# the operator. Shares the global scan lock — compact copies the whole LMDB.
# Not on CONSOLE_VERBS: a free command box must not host a multi-GB write that
# needs the same confirm + audit path Settings already has (WHY.md §5).
_db_compact_job = {
    "status": "idle", "started_at": None, "progress": None, "total": None,
    "rate": None, "eta": None, "phase": None, "error": None,
    "finished_at": None, "output_path": None,
    "live_bytes": None, "compacted_bytes": None, "reclaimable_bytes": None,
}
_JOB_REGISTRY["db-compact"] = _db_compact_job


def settings_compact_output_path():
    """Fixed output path for the Settings Compact button: always
    <db>/data.mdb.compacted. Returns (path, error)."""
    db_dir = _strfry_db_dir()
    if not db_dir:
        return None, "strfry db path is not configured or not found"
    return os.path.join(db_dir, COMPACT_OUTPUT_NAME), None


def _file_size_or_none(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return None


def get_db_compact_status(include_detail=False):
    """Compact job status. `include_detail` adds the raw failure text (strfry
    stderr names paths) and is only ever true for an authenticated caller.
    Public poll keeps phase/sizes/outcome and drops the path-bearing error."""
    with _scan_lock:
        status = dict(_db_compact_job)
        running = _active_scan["name"]
    status["blocked_by"] = running if running not in (None, "db-compact") else None
    error = status.get("error")
    status["failed"] = bool(error) or status.get("phase") == "failed"
    # output_path also names the host filesystem — same disclosure class as
    # the error text. Public poll keeps sizes; the path stays admin-only.
    if not include_detail:
        status.pop("error", None)
        status.pop("output_path", None)
    return status


def run_db_compact(output_path=None, progress_cb=None):
    """Run `strfry compact <output_path>`. Default path is the Settings fixed
    name under the db directory. Removes a previous file at that path first
    (strfry refuses to overwrite).

    strfry itself prints no progress. The only mid-run signal is the growing
    size of the output file, polled while the process runs. `progress_cb` is
    the same shape as scan progress (`count, total=None`): count = bytes
    written so far, total = live data.mdb size (a ceiling — the compacted
    copy is usually smaller, so the bar may not reach 100% before done; ETA
    is therefore an upper-bound estimate). Returns
    (ok, error, {output_path, live_bytes, compacted_bytes, reclaimable_bytes})."""
    if output_path is None:
        output_path, path_err = settings_compact_output_path()
        if path_err:
            return False, path_err, None
    try:
        strfry_bin = require_strfry_bin()
        conf = require_strfry_conf()
    except RuntimeError as e:
        return False, str(e), None
    db_dir = _strfry_db_dir()
    live_path = os.path.join(db_dir, "data.mdb") if db_dir else None
    live_bytes = _file_size_or_none(live_path) if live_path else None
    # Own the fixed name: a prior compact's leftover would make strfry exit
    # with "output file exists, not overwriting" and look like a hard failure.
    try:
        if os.path.exists(output_path):
            os.remove(output_path)
    except OSError as e:
        return False, f"could not clear previous compact output: {e}", None
    if progress_cb is not None:
        # Seed total = live size so the first poll already has a denominator
        # (rule 9: — until measured; live_bytes is measured).
        progress_cb(0, total=live_bytes)
    argv = [strfry_bin, "--config", conf, "compact", output_path]
    try:
        # stdout discarded: compact is silent on success. stderr kept so a
        # failure still has a reason; it is short on normal errors, so the
        # pipe will not fill during a multi-GB run.
        proc = subprocess.Popen(
            argv, cwd=get_relay_cwd(),
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        )
    except Exception as e:
        return False, f"{type(e).__name__}: {e}", None
    deadline = time.monotonic() + COMPACT_TIMEOUT
    try:
        while proc.poll() is None:
            written = _file_size_or_none(output_path) or 0
            if progress_cb is not None:
                progress_cb(written, total=live_bytes)
            if time.monotonic() >= deadline:
                proc.kill()
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
                return False, f"timeout after {COMPACT_TIMEOUT}s", None
            time.sleep(0.5)
        # Final size sample after exit, then collect stderr.
        written = _file_size_or_none(output_path) or 0
        if progress_cb is not None:
            progress_cb(written, total=live_bytes)
        _stdout, stderr = proc.communicate(timeout=5)
        if proc.returncode != 0:
            err = (stderr or b"").decode("utf-8", "replace")[-300:]
            return False, err or f"exit {proc.returncode}", None
    except Exception as e:
        try:
            proc.kill()
        except Exception:
            pass
        try:
            proc.communicate(timeout=5)
        except Exception:
            pass
        return False, f"{type(e).__name__}: {e}", None
    compacted_bytes = _file_size_or_none(output_path)
    if progress_cb is not None and compacted_bytes is not None:
        # Snap to measured final size so the UI does not freeze mid-bar when
        # the copy finished well under the live ceiling.
        progress_cb(compacted_bytes, total=compacted_bytes)
    reclaimable = None
    if live_bytes is not None and compacted_bytes is not None and live_bytes >= compacted_bytes:
        reclaimable = live_bytes - compacted_bytes
    meta = {
        "output_path": output_path,
        "live_bytes": live_bytes,
        "compacted_bytes": compacted_bytes,
        "reclaimable_bytes": reclaimable,
    }
    log(f"server86: db compact ok (live={live_bytes}, compacted={compacted_bytes})")
    return True, None, meta


def _run_db_compact_job():
    """Background body for Settings Compact. Releases the global lock on every
    exit path. Does not replace the live data.mdb — that needs a relay stop.
    Progress is the growing compact output file (bytes), total is live
    data.mdb size as a ceiling — see run_db_compact."""
    error = None
    meta = None
    progress_cb = _make_progress_cb(_db_compact_job)
    try:
        with _scan_lock:
            _db_compact_job["phase"] = "compacting"
            # Publish live size early so the first status poll can name the
            # denominator before any bytes have been written.
            db_dir = _strfry_db_dir()
            live_path = os.path.join(db_dir, "data.mdb") if db_dir else None
            live_bytes = _file_size_or_none(live_path) if live_path else None
            _db_compact_job["live_bytes"] = live_bytes
            _db_compact_job["progress"] = 0
            _db_compact_job["total"] = live_bytes
        ok, err, meta = run_db_compact(progress_cb=progress_cb)
        if not ok:
            error = err or "compact failed"
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
        log(f"server86: db compact job failed: {error}")
    finally:
        with _scan_lock:
            _db_compact_job["status"] = "idle"
            _db_compact_job["phase"] = "failed" if error else "done"
            _db_compact_job["error"] = error
            _db_compact_job["finished_at"] = int(time.time())
            # Keep the last progress/rate snapshot for a moment of readability,
            # but clear rate/eta so a finished job never still says "N min left".
            _db_compact_job["rate"] = None
            _db_compact_job["eta"] = None
            if meta:
                _db_compact_job["output_path"] = meta.get("output_path")
                _db_compact_job["live_bytes"] = meta.get("live_bytes")
                _db_compact_job["compacted_bytes"] = meta.get("compacted_bytes")
                _db_compact_job["reclaimable_bytes"] = meta.get("reclaimable_bytes")
                if meta.get("compacted_bytes") is not None:
                    _db_compact_job["progress"] = meta["compacted_bytes"]
                    _db_compact_job["total"] = meta["compacted_bytes"]
            _active_scan["name"] = None


def start_db_compact(on_started=None):
    """Start one compact under the global job lock. Same single-flight shape
    as the gift-wrap purge: on_started fires only for the call that launched."""
    def run():
        _run_db_compact_job()

    return _start_scan_job(
        "db-compact", _db_compact_job, run,
        on_started=on_started,
        extra_job_fields={
            "phase": "starting", "error": None, "finished_at": None,
            "output_path": None, "live_bytes": None,
            "compacted_bytes": None, "reclaimable_bytes": None,
            "progress": 0, "total": None, "rate": None, "eta": None,
        },
    )


def live_subscribe():
    """Register one SSE connection's queue and return (queue, initial_state).
    The initial state carries the WHOLE ring buffer (startup seed of the
    newest LIVE_FEED_SEED events, plus whatever the poll has folded in
    since) so a freshly opened tab renders immediately rather than waiting
    out LIVE_POLL_INTERVAL — or forever, on a quiet relay."""
    q = queue.Queue(maxsize=64)
    with _live_lock:
        _live_subscribers.append(q)
    return q, _live_state_snapshot()


def live_unsubscribe(q):
    with _live_lock:
        if q in _live_subscribers:
            _live_subscribers.remove(q)


def get_stats_snapshot():
    """Stats page's initial (pre-SSE) payload: cached walk/totals plus the
    live layer's CURRENT in-memory delta — an O(1) dict read, never a fresh
    scan, since the shared poll loop already keeps this up to date."""
    report = get_report_status()
    live = _live_state_snapshot()
    return {
        "totals": report.get("totals"),
        "walk": report.get("walk"),
        "baseline_at": live["baseline_at"],
        "new_events": live["new_events"],
        "deletes": live["deletes"],
        "live_error": live["error"],
        "live_at": live["at"],
    }


def get_userlist_snapshot():
    """Join authors cache + recipients cache + reports cache for the
    Userlist page. Never starts a scan. Missing fields stay null so the
    client can render — rather than inventing zeros. `giftwrap_count` is a
    FLOOR (render `≥ n`, rule per CLAUDE.md) whenever the recipients scan is
    saturated — the recipient scan now runs to completion or
    AUTHOR_SCAN_DEADLINE, whichever comes first, so saturation is the rare
    case (see AUTHOR_SCAN_DEADLINE), not the routine one WHY.md §5 used to
    describe. A saturated recipient list can still only under-count, never
    over-count, which is what makes it safe to treat as a floor either way.

    While an author scan is running, `rows` come from the job's
    `partial_authors` (top authors tallied so far) so the table can fill
    during the scan; giftwrap/report columns stay null until the final
    join. Partials never carry a `scanned_at` for this attempt."""
    authors_status = get_authors_status()
    recipients_status = get_recipients_status()
    reports_status = get_reports_status()
    partial = (
        authors_status.get("status") == "running"
        and isinstance(authors_status.get("partial_authors"), list)
    )
    if partial:
        authors = authors_status["partial_authors"]
    else:
        authors = authors_status.get("authors") or []
    recipients = recipients_status.get("recipients") or []
    recipient_counts = {r["pubkey"]: r.get("count") for r in recipients if isinstance(r, dict) and r.get("pubkey")}
    recipients_saturated = bool(recipients_status.get("saturated"))
    recipients_scanned_at = recipients_status.get("scanned_at")
    report_counts = reports_status.get("counts") or {}
    # The authors cache is a snapshot from whenever compute_authors() last
    # ran — potentially hours old. names.json keeps gaining entries between
    # scans (a resolution from any other page/action, or from a rescan that
    # skipped this pubkey as single-event). Re-join it at read time, cheap
    # and scan-free, so a name resolved after the last scan still shows up
    # here without the operator having to know to rescan.
    fresh_names = _cached_names_only([a["pubkey"] for a in authors if isinstance(a, dict) and a.get("pubkey")])
    rows = []
    for a in authors:
        if not isinstance(a, dict) or not a.get("pubkey"):
            continue
        pk = a["pubkey"]
        fresh = fresh_names.get(pk)
        # Partial rows use "count"; the finished cache uses "count" too on
        # the authors cache, mapped to event_count for the table.
        event_count = a.get("count") if a.get("count") is not None else a.get("event_count")
        rows.append({
            "pubkey": pk,
            "name": (fresh or {}).get("name") or a.get("name"),
            "nip05": (fresh or {}).get("nip05") or a.get("nip05"),
            "event_count": event_count,
            "last_seen": a.get("last_seen"),
            "giftwrap_count": None if partial else recipient_counts.get(pk),
            "reporters": a.get("reporters") if partial else report_counts.get(pk),
        })
    return {
        "rows": rows,
        "authors_partial": partial,
        "authors_scanned_at": authors_status.get("scanned_at"),
        "authors_error": authors_status.get("error"),
        "authors_modes": authors_status.get("modes"),
        "authors_kinds_stale": authors_status.get("kinds_stale", False),
        "recipients_scanned_at": recipients_scanned_at,
        "recipients_saturated": recipients_saturated,
        "recipients_error": recipients_status.get("error"),
        "reports_scanned_at": reports_status.get("scanned_at"),
        "reports_error": reports_status.get("error"),
    }


# --- stats console (Stats page) ---------------------------------------------
# CONSOLE_VERBS names the whole allowlist — never shell=True, argv is
# reconstructed from a validated command string. `scan`, `info`, and
# `export` are the only strfry subcommands that cannot mutate the database
# regardless of what flags follow them (unlike `sync`, `import`, `router`,
# `compact`, or `delete`), so the check IS the verb allowlist; there is no
# per-verb required-flag table left to maintain. Compact lives on Settings
# only (confirm + audit + fixed path). A free command box would make every
# guard elsewhere decorative (WHY.md §5).

CONSOLE_TIMEOUT = 30
COMPACT_TIMEOUT = 3600          # hard cap on one strfry compact run (Settings)
COMPACT_OUTPUT_NAME = "data.mdb.compacted"  # fixed name for Settings compact


def _strfry_db_dir():
    """Absolute path of the LMDB directory named by strfry.conf `db`, or None."""
    _, db_path = _strfry_db_bytes()
    return db_path


def validate_console_command(raw):
    """Return (argv, error). argv is a list suitable for subprocess without
    a shell; error is a human reason when refused."""
    if not isinstance(raw, str):
        return None, "command must be a string"
    text = raw.strip()
    if not text:
        return None, "empty command"
    if len(text) > 2000:
        return None, "command too long"
    # naive split on whitespace — filters are JSON and must not contain
    # unescaped spaces the operator didn't type; this is deliberate
    # vs shlex so we never expand quotes into a shell.
    parts = text.split()
    if not parts:
        return None, "empty command"
    verb = parts[0]
    if verb == "strfry":
        parts = parts[1:]
        if not parts:
            return None, "missing strfry subcommand"
        verb = parts[0]
    if verb not in CONSOLE_VERBS:
        return None, (
            f"refused: '{verb}' is not on the read-only allowlist "
            f"(allowed: {', '.join(CONSOLE_VERBS)})"
        )
    # The allowlist decision is independent of whether the conf file exists
    # on this host — validation answers "may this verb run", and the path
    # is only a preview of what would be invoked. run_console_command
    # re-resolves and refuses if nothing is found.
    conf = get_strfry_conf_path()
    if conf is None:
        status = strfry_conf_status()
        conf = (status.get("path") or status.get("override")
                or status.get("detected") or STRFRY_CONF_CANDIDATES[0])
    return ["strfry", "--config", conf] + parts, None


def _pump_stream_capped(stream, cap, on_cap):
    """Read stream into a list of chunks, stopping (and calling on_cap) once
    `cap` bytes have been retained. Returns (chunks, total_kept, hit_cap)."""
    chunks = []
    kept = 0
    hit_cap = False
    try:
        while True:
            chunk = stream.read(8192)
            if not chunk:
                break
            if kept >= cap:
                hit_cap = True
                on_cap()
                # Drain remainder so the child can exit, without retaining it.
                while stream.read(65536):
                    pass
                break
            room = cap - kept
            if len(chunk) > room:
                chunks.append(chunk[:room])
                kept += room
                hit_cap = True
                on_cap()
                while stream.read(65536):
                    pass
                break
            chunks.append(chunk)
            kept += len(chunk)
    except (OSError, ValueError):
        pass
    return chunks, kept, hit_cap


def acquire_console_slot():
    """Try to take the global job lock for a console command.

    Returns None on success (caller MUST release_console_slot). Returns a
    refusal result dict when another job holds the lock or RSS is over the
    soft cap — same shape as run_console_command errors so the handler can
    return it as-is.

    RSS is sampled OUTSIDE the lock, and only when nothing else is already
    running — same reasoning as _start_scan_job: on a host with no /proc it
    means a `ps` subprocess call, which must never happen while _scan_lock
    is held, and must not be paid on the common already-blocked path
    either. The lock is taken twice: once to cheaply rule out another job
    holding it, and — only if none does — again after sampling RSS, with
    the running-job check repeated in case one started meanwhile."""
    def _running_refusal(running):
        return _console_result(
            False,
            f"refused: {running} is running — wait for it "
            f"to finish before using the console",
            None, blocked_by=running,
        )

    with _scan_lock:
        running = _active_scan["name"]
        if running is not None:
            return _running_refusal(running)

    rss = _process_rss_bytes()
    with _scan_lock:
        running = _active_scan["name"]
        if running is not None:
            return _running_refusal(running)
        if rss is not None and rss >= MEMORY_SOFT_BYTES:
            return _console_result(
                False,
                f"refused: process RSS {rss // (1024 * 1024)}MB is at "
                f"or above the {MEMORY_SOFT_BYTES // (1024 * 1024)}MB "
                f"soft cap",
                None, blocked_by="memory",
            )
        _active_scan["name"] = "console"
    return None


def release_console_slot():
    with _scan_lock:
        if _active_scan["name"] == "console":
            _active_scan["name"] = None


def get_console_status():
    """Who (if anyone) currently holds the shared job lock, from the
    console's point of view. Same self-excluding shape as
    get_giftwrap_purge_status/get_ephemeral_purge_status/get_db_compact_status
    — those three each hide their own name so their panel doesn't report
    itself as its own blocker; this one hides "console" for the same reason.
    Cheap and unauthenticated (a lock-name read, no subprocess) specifically
    so the Stats page can poll "is anything blocking me right now" without
    re-signing and re-running a command every few seconds, and without the
    client having to separately track every job name that can hold this
    lock — POST /api/console's own 409 already names the real one; this is
    just how the panel keeps asking after that, including for jobs nothing
    on this page ever started (the hourly gift-wrap retention purge)."""
    with _scan_lock:
        running = _active_scan["name"]
    return {"blocked_by": running if running not in (None, "console") else None}


def _console_result(ok, error, argv, stdout="", stderr="", exit_code=None,
                     truncated=False, killed_for_memory=False,
                     stdout_total_bytes=None, stderr_total_bytes=None,
                     blocked_by=None):
    """Shared shape for every run_console_command/acquire_console_slot
    return path, so a caller (the UI) never has to guess which fields a
    given failure mode left out. stdout_total_bytes/stderr_total_bytes
    default to the shown length itself (nothing was cut) — pass the real
    pre-slice length when it was. blocked_by is set only when the global
    job lock refused this call outright — the same field GET /api/console
    reports on its own, so the UI reads one field name either way."""
    return {
        "ok": ok,
        "error": error,
        "argv": argv,
        "stdout": stdout,
        "stderr": stderr,
        "stdout_total_bytes": stdout_total_bytes if stdout_total_bytes is not None else len(stdout),
        "stdout_shown_bytes": len(stdout),
        "stderr_total_bytes": stderr_total_bytes if stderr_total_bytes is not None else len(stderr),
        "stderr_shown_bytes": len(stderr),
        "exit_code": exit_code,
        "truncated": truncated,
        "killed_for_memory": killed_for_memory,
        "blocked_by": blocked_by,
    }


def run_console_command(raw):
    """Run one CONSOLE_VERBS-allowlisted strfry command; return a
    JSON-serialisable result.

    Stdout/stderr are streamed with hard byte caps (CONSOLE_STDOUT_MAX /
    CONSOLE_STDERR_MAX) — hitting either kills the child, because bare
    `export` or an unbounded `scan` must never buffer the whole LMDB into
    this process. That capture is real output, not a failure: `ok` tracks
    only whether the process itself exited cleanly, `truncated` tracks
    separately whether the response is missing bytes (either because the
    capture above got killed, or because CONSOLE_RESPONSE_STDOUT_MAX/
    CONSOLE_RESPONSE_STDERR_MAX sliced an ordinary large-but-successful
    result down for the pane) — the two used to be conflated into one `ok`,
    which painted a killed-for-memory `export` the same red as a typo'd
    filter."""
    argv, err = validate_console_command(raw)
    if err:
        return _console_result(False, err, None)
    try:
        strfry_bin = require_strfry_bin()
        conf = require_strfry_conf()
        # Rebuild with the resolved binary and the actively-found conf —
        # validate may have filled a candidate path that is not present here.
        argv = [strfry_bin, "--config", conf] + argv[3:]
        proc = subprocess.Popen(
            argv, cwd=get_relay_cwd(),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        killed = {"n": False}
        pumps = {"out": ([], 0, False), "err": ([], 0, False)}

        def kill_child():
            if killed["n"]:
                return
            killed["n"] = True
            try:
                proc.kill()
            except OSError:
                pass

        def read_out():
            pumps["out"] = _pump_stream_capped(
                proc.stdout, CONSOLE_STDOUT_MAX, kill_child,
            )

        def read_err():
            pumps["err"] = _pump_stream_capped(
                proc.stderr, CONSOLE_STDERR_MAX, kill_child,
            )

        t_out = threading.Thread(target=read_out, daemon=True)
        t_err = threading.Thread(target=read_err, daemon=True)
        t_out.start()
        t_err.start()
        try:
            proc.wait(timeout=CONSOLE_TIMEOUT)
        except subprocess.TimeoutExpired:
            kill_child()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            t_out.join(timeout=2)
            t_err.join(timeout=2)
            return _console_result(
                False, f"timed out after {CONSOLE_TIMEOUT}s", argv,
            )
        t_out.join(timeout=2)
        t_err.join(timeout=2)
        out_chunks, _out_n, out_capped = pumps["out"]
        err_chunks, _err_n, err_capped = pumps["err"]
        stdout = b"".join(out_chunks).decode("utf-8", errors="replace")
        stderr = b"".join(err_chunks).decode("utf-8", errors="replace")
        killed_for_memory = out_capped or err_capped
        exit_code = proc.returncode
        # A kill for hitting the memory cap is not a command failure — it is
        # a size limit, and the bytes captured before the kill are real. Only
        # a genuine non-zero exit that ISN'T that kill counts as `failed`.
        failed = (exit_code != 0) and not killed_for_memory
        stdout_total, stderr_total = len(stdout), len(stderr)
        stdout_shown = stdout[-CONSOLE_RESPONSE_STDOUT_MAX:]
        stderr_shown = stderr[-CONSOLE_RESPONSE_STDERR_MAX:]
        # `truncated` covers both ways the pane can end up short of the full
        # capture: the memory-cap kill above, and this response's own tail
        # slice on an otherwise-successful large result. Either way the
        # shown/total byte counts travel with it so the UI states a real
        # number instead of a silent cut.
        truncated = (
            killed_for_memory
            or len(stdout_shown) < stdout_total
            or len(stderr_shown) < stderr_total
        )
        error = None
        if failed:
            error = f"exit {exit_code}"
        return _console_result(
            not failed, error, argv,
            stdout=stdout_shown, stderr=stderr_shown, exit_code=exit_code,
            truncated=truncated, killed_for_memory=killed_for_memory,
            stdout_total_bytes=stdout_total, stderr_total_bytes=stderr_total,
        )
    except Exception as e:
        return _console_result(
            False, f"{type(e).__name__}: {e}"[:600], argv,
        )


def run_strfry_count(filter_obj, timeout=SCAN_TIMEOUT):
    """Run `strfry scan --count <filter>` and return the integer count.
    `--count` walks the index without streaming bodies, so it is cheap
    even for a filter matching many events — used for /api/profile's
    lifetime total, the one number in this project that covers the whole
    database for a single pubkey. Raises on failure (missing binary,
    timeout, non-zero exit, or non-numeric output) exactly like the
    body-streaming scans; treat non-numeric output as a scan failure
    rather than parsing it loosely, per CLAUDE.md's strfry scan execution
    rules."""
    strfry_bin = require_strfry_bin()
    filter_json = json.dumps(filter_obj, separators=(",", ":"))
    argv = [strfry_bin, "--config", require_strfry_conf(), "scan", "--count", filter_json]
    result = subprocess.run(argv, cwd=get_relay_cwd(), capture_output=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError(f"strfry scan --count exited {result.returncode}: {stderr_tail(result.stderr)}")
    lines = [ln.strip() for ln in result.stdout.decode("utf-8", errors="replace").splitlines() if ln.strip()]
    if not lines:
        raise RuntimeError("strfry scan --count produced no output")
    try:
        return int(lines[-1])
    except ValueError:
        raise RuntimeError(f"strfry scan --count returned non-numeric output: {lines[-1]!r}")


def run_strfry_scan_streaming(filter_obj, on_event, timeout, on_progress=None, timeout_ok=False):
    """Run `strfry scan <filter>` and call on_event(parsed_dict) for each
    line as it arrives, never holding more than one parsed event at a time
    (used for the author/recipient/subscriber scans, any of which can be
    genuinely unbounded — too much to ever buffer as a list). If given,
    on_progress(count) is called every 500 events, not every one, so a long
    scan's background thread doesn't contend the status lock a polling GET
    also reads on every request.

    Raises on failure (missing binary or non-zero exit) always. On hitting
    the wall-clock budget: raises, same as before, UNLESS `timeout_ok=True`
    — then the partial read is not a failure, and the return value becomes
    `(count, timed_out)` instead of a bare count, so the caller can hand
    back what it read so far as a "ran out of time" result rather than
    losing it. Default is False (raise) so a caller that hasn't opted in
    keeps the old all-or-nothing behavior — see REPORT_WALK_DEADLINE for
    why that's still the right choice for compute_report_walk."""
    strfry_bin = require_strfry_bin()
    filter_json = json.dumps(filter_obj, separators=(",", ":"))
    argv = [strfry_bin, "--config", require_strfry_conf(), "scan", filter_json]
    deadline = time.monotonic() + timeout

    proc = subprocess.Popen(
        argv, cwd=get_relay_cwd(), stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    # Keep only a rolling tail of stderr so a long walk cannot retain
    # unbounded loguru noise for the life of the job.
    stderr_buf = bytearray()
    stderr_lock = threading.Lock()

    def read_stderr():
        try:
            while True:
                chunk = proc.stderr.read(4096)
                if not chunk:
                    break
                with stderr_lock:
                    stderr_buf.extend(chunk)
                    if len(stderr_buf) > STREAM_STDERR_MAX:
                        del stderr_buf[:-STREAM_STDERR_MAX]
        except (OSError, ValueError):
            pass

    stderr_thread = threading.Thread(target=read_stderr, daemon=True)
    stderr_thread.start()

    count = 0
    timed_out = False

    # The budget MUST be enforced off a timer, not only off the read loop
    # below. `for raw_line in proc.stdout` blocks inside the read, so a
    # strfry that emits nothing — its pre-output index merge on a bounded
    # multi-kind scan, or a genuine stall on LMDB contention — never reaches
    # the in-loop check and the deadline never fires. The caller holds the
    # global job lock for this whole call, so that wedges every other scan,
    # both purges, compact and the console until server86 is restarted.
    # Killing the child is what unblocks the read (it EOFs), so the timer
    # kills rather than just flagging.
    def on_deadline():
        nonlocal timed_out
        timed_out = True
        try:
            proc.kill()
        except OSError:
            pass

    watchdog = threading.Timer(max(0.0, deadline - time.monotonic()), on_deadline)
    watchdog.daemon = True
    watchdog.start()

    try:
        for raw_line in proc.stdout:
            if timed_out or time.monotonic() > deadline:
                timed_out = True
                proc.kill()
                break
            line = raw_line.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except ValueError:
                continue
            on_event(event)
            count += 1
            if on_progress is not None and count % 500 == 0:
                on_progress(count)
    finally:
        watchdog.cancel()
        try:
            proc.stdout.close()
        except (OSError, ValueError):
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        stderr_thread.join(timeout=2)

    if timed_out and not timeout_ok:
        raise RuntimeError(f"strfry scan exceeded {timeout}s budget after reading {count} events")
    if proc.returncode != 0 and not timed_out:
        with stderr_lock:
            tail = stderr_tail(bytes(stderr_buf))
        raise RuntimeError(f"strfry scan exited {proc.returncode}: {tail}")
    if timeout_ok:
        return count, timed_out
    return count


def _clean_profile_field(value):
    return value if isinstance(value, str) and value else None


def resolve_profiles(pubkeys):
    """Return ({pubkey: {"name": ..., "nip05": ...}}, error_or_None) for the
    given pubkeys.

    Two layers: a pubkey that already has a name/nip05 persisted in
    blacklist.json (written by POST /api/names — only possible for a
    currently-banned pubkey) is served from there directly, with no scan.
    Everything else falls through to _resolve_profiles_locally. `error` is
    non-None only when that scan itself failed (e.g. timed out) — never set
    just because some pubkeys had no profile to find."""
    blacklist_data = blacklist.load()
    stored = {}
    to_resolve_locally = []
    for pk in pubkeys:
        entry = blacklist_data.get(pk)
        if entry and (entry.get("name") or entry.get("nip05")):
            stored[pk] = {"name": entry.get("name"), "nip05": entry.get("nip05")}
        else:
            to_resolve_locally.append(pk)

    result, error = _resolve_profiles_locally(to_resolve_locally)
    result.update(stored)
    return result, error


def _cached_names_only(pubkeys):
    """{pubkey: {"name":, "nip05":}} for whichever of `pubkeys` some path
    has already resolved a name/nip05 for — straight from names.json
    (lib86/namecache), no scan and no network. Safe to call on every row of
    every list render: a miss (or an unresolved pubkey) is simply absent
    from the result rather than a null entry, so a caller can
    `dict.get(pk)` and only use it when there's actually something to show,
    without clobbering a value it already had from elsewhere."""
    if not pubkeys:
        return {}
    cached = namecache.get_many(pubkeys)
    return {
        pk: {"name": entry.get("name"), "nip05": entry.get("nip05")}
        for pk, entry in cached.items()
        if entry.get("name") or entry.get("nip05")
    }


def _resolve_profiles_locally(pubkeys):
    """Resolve names/nip05 from the LOCAL strfry database only, querying
    uncached (or stale local-miss) pubkeys in one batched scan bounded by
    an explicit `authors` list, given NAME_RESOLVE_SCAN_TIMEOUT rather than
    the default SCAN_TIMEOUT — an `authors: [...]` filter with up to
    NAME_RESOLVE_MAX entries is a heavier lookup than the other bounded
    scans and 10s can be too tight for it on a large database. Both fields
    come from the same kind-0 event; the nip05 string is displayed as-is,
    never verified (verification would need outbound HTTP to arbitrary
    domains). Results persist in names.json (lib86/namecache.py) rather
    than in memory only, so they survive server86 restarts — never written
    to blacklist.json, since these pubkeys aren't (necessarily) banned.

    A cached `source: "external"` entry (hit or miss) is treated as final
    and never re-attempted locally: if a purplepag.es-backed lookup found
    nothing, the profile is presumed absent everywhere, not just here.
    Only `source: "local"` full misses older than NAME_CACHE_TTL are
    eligible for another local scan attempt — the local database keeps
    changing in a way an external miss never un-misses.

    Returns ({pubkey: {"name":, "nip05":}}, error_or_None). On a scan
    failure (including a timeout), nothing for the failed batch is cached
    as a miss — caching "checked, found nothing" for pubkeys that were
    never actually checked would look identical to an absent profile for
    the next NAME_CACHE_TTL, hiding the failure instead of just delaying
    the next attempt. The caller gets `error` back to surface instead."""
    now = time.time()
    cached = namecache.get_many(pubkeys)
    to_query = {
        pk for pk in pubkeys
        if pk not in cached or (
            not cached[pk].get("name") and not cached[pk].get("nip05")
            and cached[pk].get("source") == "local"
            and now - (cached[pk].get("checked_at") or 0) >= NAME_CACHE_TTL
        )
    }

    error = None
    if to_query:
        results = {}
        try:
            events = run_strfry_scan(
                {"kinds": [0], "authors": list(to_query)}, timeout=NAME_RESOLVE_SCAN_TIMEOUT,
            )
            found = set()
            for ev in events:
                try:
                    content = json.loads(ev.get("content", "{}"))
                    name = content.get("display_name") or content.get("name")
                    nip05 = content.get("nip05")
                    pk = ev.get("pubkey")
                except Exception:
                    continue
                if pk in to_query and pk not in found:
                    results[pk] = {"name": _clean_profile_field(name), "nip05": _clean_profile_field(nip05)}
                    found.add(pk)
            for pk in to_query:
                if pk not in found:
                    results[pk] = {"name": None, "nip05": None}
        except Exception as e:
            log(f"server86: name-resolution scan failed: {e}")
            error = f"name resolution failed: {e}"
            results = {}
        if results:
            namecache.set_local(results, now, max_entries=get_name_cache_max())
            for pk, hit in results.items():
                cached[pk] = {"name": hit["name"], "nip05": hit["nip05"], "checked_at": now, "source": "local"}

    miss = {"name": None, "nip05": None}
    resolved = {pk: ({"name": cached[pk]["name"], "nip05": cached[pk]["nip05"]} if pk in cached else miss) for pk in pubkeys}
    return resolved, error


# --- generic async scan job machinery -------------------------------------
# Shared by every asynchronous scan (author list, gift-wrap recipients,
# DM/general-relay-list subscribers, report totals, report walk): validate
# auth, start ONE scan in a background thread under the single global
# _scan_lock, return 202 immediately, and let the page poll the matching
# GET until status returns to idle. One code path for all of them — not a
# fast one and a slow one that behave differently under failure.
#
# `job` and `cache` are mutated IN PLACE rather than rebound to a new dict,
# so the caller's module-level dict object — the thing readers actually
# hold a reference to — is always what gets updated.

def _save_cache_atomic(path, result):
    tmp_path = path + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(tmp_path, path)


def _load_cache_or(path, empty_result):
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return dict(empty_result)


# --- server-side audit log -------------------------------------------------
# AUDIT_LOG_MAX is CONFIGURABLE — see get_audit_log_max() near
# CONFIG_EDITABLE_FIELDS, where its default/floor/ceiling are defined
# alongside the rest of that group.
AUDIT_LOG_PATH = os.path.join(SCRIPT_DIR, "audit-log.json")


def _empty_audit_log():
    return {"records": []}


_audit_lock = threading.Lock()
_audit_log = _load_cache_or(AUDIT_LOG_PATH, _empty_audit_log())
if not isinstance(_audit_log.get("records"), list):
    _audit_log = _empty_audit_log()


def audit_append(record):
    """Append one admin-action record and persist. Caps at get_audit_log_max()."""
    if not isinstance(record, dict):
        return
    rec = dict(record)
    rec.setdefault("id", f"{int(time.time() * 1000)}-{os.urandom(3).hex()}")
    rec.setdefault("at", int(time.time()))
    rec.setdefault("undone", False)
    with _audit_lock:
        records = list(_audit_log.get("records") or [])
        records.append(rec)
        cap = get_audit_log_max()
        if len(records) > cap:
            records = records[-cap:]
        _audit_log["records"] = records
        try:
            _save_cache_atomic(AUDIT_LOG_PATH, _audit_log)
        except OSError as e:
            log(f"server86: failed to persist audit-log.json: {e}")


def get_audit_records(query=None):
    q = (query or "").strip().lower()
    with _audit_lock:
        records = list(_audit_log.get("records") or [])
    records.reverse()  # newest first
    if not q:
        return records
    out = []
    for r in records:
        blob = json.dumps(r, separators=(",", ":"), ensure_ascii=False).lower()
        if q in blob:
            out.append(r)
    return out


def audit_mark_undone(record_id):
    with _audit_lock:
        for r in _audit_log.get("records") or []:
            if r.get("id") == record_id:
                r["undone"] = True
                try:
                    _save_cache_atomic(AUDIT_LOG_PATH, _audit_log)
                except OSError as e:
                    log(f"server86: failed to persist audit-log.json: {e}")
                return dict(r)
    return None


# --- domain bans -------------------------------------------------------------
# NOT a new enforcement primitive, and deliberately so. Deciding whether an
# event's author belongs to a NIP-05 domain means fetching that domain's
# /.well-known/nostr.json — an external HTTP request, in strfry's blocking
# write path, per event. This project does not make external queries there
# and will not start.
#
# What this file records is what the operator actually did: they looked up a
# domain's roster on the Domain page and banned it. The pubkeys are what
# enforce; this is the receipt, so the Banlist can name the domain, show its
# reason, and undo the whole set in one press. A pubkey that joins the domain
# tomorrow is NOT banned by an entry here, and the page says so.

DOMAIN_BANS_PATH = os.path.join(SCRIPT_DIR, "domain-bans.json")

_domain_bans_lock = threading.Lock()
_domain_bans = _load_cache_or(DOMAIN_BANS_PATH, {"domains": {}})
if not isinstance(_domain_bans.get("domains"), dict):
    _domain_bans = {"domains": {}}


def domain_ban_record(domain, pubkeys, reason, actor):
    """Record (or extend) one domain's banned roster. Returns the stored entry."""
    now = int(time.time())
    with _domain_bans_lock:
        domains = dict(_domain_bans.get("domains") or {})
        prior = domains.get(domain) or {}
        merged = list(dict.fromkeys(list(prior.get("pubkeys") or []) + list(pubkeys)))
        entry = {
            "domain": domain,
            "banned_at": prior.get("banned_at") or now,
            "updated_at": now,
            "reason": reason or prior.get("reason") or "",
            "pubkeys": merged,
            "actor": actor or prior.get("actor"),
        }
        domains[domain] = entry
        _domain_bans["domains"] = domains
        try:
            _save_cache_atomic(DOMAIN_BANS_PATH, _domain_bans)
        except OSError as e:
            log(f"server86: failed to persist domain-bans.json: {e}")
    return entry


def domain_ban_remove(domain):
    """Drop one domain's record. Returns its pubkeys, or None if unknown."""
    with _domain_bans_lock:
        domains = dict(_domain_bans.get("domains") or {})
        entry = domains.pop(domain, None)
        if entry is None:
            return None
        _domain_bans["domains"] = domains
        try:
            _save_cache_atomic(DOMAIN_BANS_PATH, _domain_bans)
        except OSError as e:
            log(f"server86: failed to persist domain-bans.json: {e}")
    return list(entry.get("pubkeys") or [])


def get_domain_bans():
    """Domain records, newest first, each carrying how many of its pubkeys
    are STILL banned — the roster is a snapshot from ban time, and an
    individual unban since then must not be hidden by this page."""
    with _domain_bans_lock:
        domains = list((_domain_bans.get("domains") or {}).values())
    current = blacklist.load()
    out = []
    for entry in domains:
        pubkeys = list(entry.get("pubkeys") or [])
        out.append({
            "domain": entry.get("domain"),
            "banned_at": entry.get("banned_at"),
            "reason": entry.get("reason") or "",
            "pubkey_count": len(pubkeys),
            "still_banned": sum(1 for pk in pubkeys if pk in current),
        })
    out.sort(key=lambda e: e.get("banned_at") or 0, reverse=True)
    return out


# --- strfry.conf ------------------------------------------------------------
# Tokenized and parsed into a tree, never reserialised. Every edit splices
# only the value token's own offsets and leaves the entire rest of the file —
# comments, blank lines, ordering, indentation, anything this parser does not
# model — byte-identical. A config file the operator hand-tuned must survive
# a visit to the Settings page unchanged except for what they changed.
#
# This used to be a line-scan (block name and brace required on the same
# line, one regex per line). That went blind on Allman-style blocks
# (`writePolicy` then `{` on its own following line) and on a block opened
# and closed on one line (`writePolicy { plugin = "" }`) — both real shapes
# strfry.conf actually appears in. strfry-86-updater.py's own conf editor
# had the identical blindness and was fixed the same way: tokenize the whole
# file once, offsets included, and only ever splice the original text at
# those offsets. The updater cannot import this code (on a fresh install
# lib86 does not exist yet, and this module is heavier still), so this is a
# second, independent implementation of the same tokenizer/parser shape —
# `tests/` runs both across the same fixture set and asserts byte-identical
# output, so drift between the two copies fails a test instead of surfacing
# as two admin surfaces disagreeing about the same file.


class ConfParseError(Exception):
    pass


_CONF_TOKEN_RE = re.compile(
    r'"(?:[^"\\]|\\.)*"'   # quoted string (escapes not interpreted, kept raw)
    r'|[{}=]'              # structural characters
    r'|[^\s{}=#"]+'        # bareword: identifier, number, true/false, ...
)


def _tokenize_conf(text):
    """(token, start, end) triples over strfry.conf-shaped text. Whitespace
    is skipped; '#' outside a quoted string starts a comment that runs to
    end-of-line. A '#' or brace INSIDE a quoted string is not structural —
    the quoted-string alternative in _CONF_TOKEN_RE is tried first and
    consumes the whole literal, braces and all."""
    tokens = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c == "#":
            nl = text.find("\n", i)
            i = n if nl == -1 else nl
            continue
        m = _CONF_TOKEN_RE.match(text, i)
        if not m:
            raise ConfParseError(f"unrecognized character {c!r} at offset {i}")
        tokens.append((m.group(0), m.start(), m.end()))
        i = m.end()
    return tokens


def _parse_conf_tree(tokens):
    """Recursive-descent parse into a nested dict: each key maps to either
    ('block', subtree, open_end, close_start) or ('value', raw_token, start,
    end). Raises ConfParseError on anything that doesn't fit the
    key=value / key{...} grammar, including a block that never closes."""
    idx = 0

    def parse_block(top_level):
        nonlocal idx
        node = {}
        while idx < len(tokens):
            tok, start, end = tokens[idx]
            if tok == "}":
                if top_level:
                    raise ConfParseError(f"unexpected '}}' at offset {start}")
                idx += 1
                return node
            key = tok
            idx += 1
            if idx >= len(tokens):
                raise ConfParseError(f"unexpected end of file after '{key}'")
            nxt, nstart, nend = tokens[idx]
            if nxt == "{":
                open_end = nend
                idx += 1
                child = parse_block(False)
                close_start = tokens[idx - 1][1]  # the '}' just consumed
                node[key] = ("block", child, open_end, close_start)
            elif nxt == "=":
                idx += 1
                if idx >= len(tokens):
                    raise ConfParseError(f"unexpected end of file after '{key} ='")
                vtok, vstart, vend = tokens[idx]
                idx += 1
                node[key] = ("value", vtok, vstart, vend)
            else:
                raise ConfParseError(f"unexpected token {nxt!r} after '{key}'")
        if not top_level:
            raise ConfParseError("unterminated block — missing '}'")
        return node

    root = parse_block(top_level=True)
    if idx != len(tokens):
        raise ConfParseError("trailing tokens after top-level parse")
    return root


def _conf_value_type(raw):
    if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
        return "string"
    if raw in ("true", "false"):
        return "bool"
    try:
        int(raw)
        return "int"
    except ValueError:
        return "string"


def _conf_unquote(raw):
    if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
        return raw[1:-1]
    return raw


def _walk_conf_tree(node, prefix):
    fields = []
    for key, entry in node.items():
        path = ".".join(prefix + [key])
        section = ".".join(prefix) or "general"
        if entry[0] == "block":
            fields.extend(_walk_conf_tree(entry[1], prefix + [key]))
        else:
            _, vtok, vstart, vend = entry
            fields.append({
                "path": path,
                "section": section,
                "key": key,
                "value": _conf_unquote(vtok),
                "type": _conf_value_type(vtok),
                "vstart": vstart,
                "vend": vend,
            })
    return fields


def parse_strfry_conf(text):
    """Return (fields, balanced). `fields` is every scalar assignment in
    file order, each with its dotted path, section, value and type.
    `balanced` is False when the file doesn't tokenize/parse cleanly (this
    is the one structural check worth making before allowing a write) — in
    that case `fields` is empty, since a partial tree from broken input is
    not safe to offer for structured editing."""
    try:
        tree = _parse_conf_tree(_tokenize_conf(text))
    except ConfParseError:
        return [], False
    return _walk_conf_tree(tree, []), True


def apply_strfry_conf_edits(text, edits):
    """Rewrite only the value token named by each path in `edits`
    ({path: new_value}). Returns (new_text, changed_paths)."""
    fields, balanced = parse_strfry_conf(text)
    if not balanced:
        return text, []
    by_path = {f["path"]: f for f in fields}
    splices = []
    changed = []
    for path, new_value in edits.items():
        field = by_path.get(path)
        if field is None:
            continue
        if str(field["value"]) == str(new_value):
            continue
        if field["type"] == "string":
            rendered = '"' + str(new_value).replace('"', '\\"') + '"'
        elif field["type"] == "bool":
            rendered = "true" if str(new_value).lower() in ("1", "true", "yes", "on") else "false"
        else:
            try:
                rendered = str(int(str(new_value).strip()))
            except ValueError:
                continue
        splices.append((field["vstart"], field["vend"], rendered))
        changed.append(path)
    new_text = text
    for start, end, rendered in sorted(splices, key=lambda s: s[0], reverse=True):
        new_text = new_text[:start] + rendered + new_text[end:]
    return new_text, changed


def read_strfry_conf():
    status = strfry_conf_status()
    if not status.get("exists"):
        return None, status.get("error") or "strfry.conf not found"
    try:
        with open(status["path"], "r", encoding="utf-8") as fh:
            return fh.read(), None
    except OSError as e:
        return None, f"{type(e).__name__}: {e}"


def write_strfry_conf(text):
    """Write the ACTIVE strfry.conf, keeping the previous copy alongside it.
    strfry re-reads its config on its own, so nothing here restarts the relay
    — which also means a broken file takes effect without a prompt. Braces
    are checked before anything is written; that is the only structural
    claim this project is willing to make about someone else's format."""
    status = strfry_conf_status()
    if not status.get("exists"):
        return False, status.get("error") or "strfry.conf not found"
    path = status["path"]
    _, balanced = parse_strfry_conf(text)
    if not balanced:
        return False, "unbalanced braces — nothing written"
    try:
        current, _ = read_strfry_conf()
        if current is not None:
            with open(path + ".bak", "w", encoding="utf-8") as fh:
                fh.write(current)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except OSError as e:
        return False, f"{type(e).__name__}: {e}"
    return True, None


# --- settings payload -------------------------------------------------------
# Two files, one shape, so the page can render them with the same code: the
# relay's own strfry.conf, and strfry-86's config.json. Both arrive as
# structured fields AND as the raw text they were parsed from, because the
# structured view can only offer what the parser recognised and the operator
# must always be able to reach the rest.

# Gift-wrap auto-retention. Default keeps kind-1059 for 30 days; the Settings
# slider only goes as aggressive as 7 days (never shorter — a mis-click must
# not empty the DM inbox of every subscriber overnight).
GIFTWRAP_RETENTION_DEFAULT = 30
GIFTWRAP_RETENTION_MIN = 7
GIFTWRAP_RETENTION_MAX = 30
GIFTWRAP_RETENTION_INTERVAL = 3600   # seconds between purge attempts
GIFTWRAP_RETENTION_TIMEOUT = 3600   # hard cap on one strfry delete run

# NIP-16 ephemeral kinds. strfry WRITES them (so open subscriptions get the
# fan-out) and marks them expiration=1; RelayCron then deletes after
# events.ephemeralEventsLifetimeSeconds. They do touch disk — briefly when
# healthy, longer when lifetime is high or cron lags. Nostr filters have
# no kind range, so the filter is the full integer list once.
EPHEMERAL_KIND_MIN = 20000
EPHEMERAL_KIND_MAX = 29999
_EPHEMERAL_KINDS = list(range(EPHEMERAL_KIND_MIN, EPHEMERAL_KIND_MAX + 1))
EPHEMERAL_PURGE_TIMEOUT = 3600

# CONFIGURABLE defaults/bounds — see get_<name>() functions below and
# CONFIG_INT_BOUNDS. Each one used to be a plain module constant; none of
# them feed a subprocess timeout or a process-lifetime buffer (those stayed
# HARD, in the bounds block near the top of the file), so an operator
# preference here costs nothing structural to raise or lower within its
# range.
REPORT_SCAN_LIMIT_DEFAULT = 5000        # kind-1984 events read to build the reports-against tally
REPORT_SCAN_LIMIT_MIN = 500
REPORT_SCAN_LIMIT_MAX = 100000
NAME_RESOLVE_MAX_DEFAULT = 500          # pubkeys per batched kind-0 lookup
NAME_RESOLVE_MAX_MIN = 50
NAME_RESOLVE_MAX_MAX = 5000
NAME_CACHE_MAX_DEFAULT = 20000          # entries retained in names.json
NAME_CACHE_MAX_MIN = 1000
NAME_CACHE_MAX_MAX = 200000
DOMAIN_LOOKUP_MAX_DEFAULT = 1000        # pubkeys accepted in one /api/pubkeys/lookup body
DOMAIN_LOOKUP_MAX_MIN = 50
DOMAIN_LOOKUP_MAX_MAX = 20000
PROFILE_EVENT_LIMIT_DEFAULT = 500       # events read for one pubkey's kind tally
PROFILE_EVENT_LIMIT_MIN = 50
PROFILE_EVENT_LIMIT_MAX = 5000
PROFILE_REPORT_LIMIT_DEFAULT = 100      # kind-1984 events read for reports against one pubkey
PROFILE_REPORT_LIMIT_MIN = 10
PROFILE_REPORT_LIMIT_MAX = 2000
PROFILE_DAY_EVENTS_MAX_DEFAULT = 50     # events read for one pubkey's single-day view
PROFILE_DAY_EVENTS_MAX_MIN = 10
PROFILE_DAY_EVENTS_MAX_MAX = 1000
REASON_MAX_LEN_DEFAULT = 500            # characters accepted for a ban reason
REASON_MAX_LEN_MIN = 50
REASON_MAX_LEN_MAX = 5000
REASON_UNDO_MAX_DEFAULT = 50            # entries whose prior reasons are snapshotted for undo
REASON_UNDO_MAX_MIN = 5
REASON_UNDO_MAX_MAX = 500
# audit_log_max's floor is not a UX nicety like the others' — the audit log
# is the ONLY undo authority in the project (audit.html says so explicitly).
# A value set too low silently destroys undo capability for actions already
# taken, not just a view; AUDIT_LOG_MAX_MIN exists to make that mistake
# require deliberately typing a small number, not a mis-click on a slider.
AUDIT_LOG_MAX_DEFAULT = 500
AUDIT_LOG_MAX_MIN = 100
AUDIT_LOG_MAX_MAX = 20000

CONFIG_EDITABLE_FIELDS = {
    # config.json keys the Settings page may write. admin_pubkey_hex is
    # deliberately NOT here: it is the credential that authorises the very
    # request doing the writing, and a UI that can change it is a UI that can
    # lock the operator out of their own relay in one keystroke.
    "strfry_conf_path": ("string", "strfry.conf path",
                         "leave blank to detect it from the running relay; set it only when "
                         "detection picks the wrong file"),
    "relay_url": ("string", "Relay URL", "wss:// URL this relay answers on — used to find its own subscribers"),
    "public_origin": ("string", "Public origin",
                      "https://host[:port] of this admin UI as browsers see it — binds NIP-98 "
                      "auth to that host. Leave blank to use the request Host header; set it "
                      "when a reverse proxy terminates TLS so signed u tags match."),
    "contact_appeal": ("string", "Contact appeal", "shown publicly to banned pubkeys on the Banlist"),
    "giftwrap_retention_days": ("range", "Gift-wrap retention",
                                "kind-1059 older than this is deleted automatically (default 30 days, "
                                "minimum 7)"),
    "port": ("int", "Admin UI port", "port server86 binds; takes effect on next start"),
    "bind": ("string", "Admin UI bind address", "interface server86 binds; takes effect on next start"),
    "report_scan_limit": ("int", "Report scan size",
                           "kind-1984 events read to build the reports-against tally (default 5,000)"),
    "name_resolve_max": ("int", "Name lookup batch size",
                          "pubkeys per batched kind-0 name lookup (default 500) — a heavier "
                          "lookup shape than a plain scan; raising it costs more time per batch"),
    "name_cache_max": ("int", "Name cache size",
                        "resolved names/nip05s kept in names.json before the oldest are evicted "
                        "(default 20,000)"),
    "domain_lookup_max": ("int", "Domain roster lookup size",
                           "pubkeys accepted in one /domain roster lookup (default 1,000) — a "
                           "request over this is rejected outright, never truncated"),
    "profile_event_limit": ("int", "Profile event window",
                             "events read for one pubkey's kind tally on /profile (default 500)"),
    "profile_report_limit": ("int", "Profile report window",
                              "kind-1984 events read for reports against one pubkey (default 100)"),
    "profile_day_events_max": ("int", "Profile day-view window",
                                "events read for one pubkey's single-day view (default 50)"),
    "reason_max_len": ("int", "Ban reason max length",
                        "characters accepted for a ban reason; longer is rejected outright, "
                        "never truncated (default 500)"),
    "reason_undo_max": ("int", "Bulk reason-edit undo size",
                         "entries whose prior reasons are snapshotted for undo on a bulk reason "
                         "edit; a larger edit gets no undo at all (default 50)"),
    "audit_log_max": ("int", "Audit log size",
                       f"admin-action records retained — this is the ONLY undo authority in the "
                       f"project, so a value set too low destroys undo capability for actions "
                       f"already taken. Floor {AUDIT_LOG_MAX_MIN} enforced for that reason "
                       f"(default {AUDIT_LOG_MAX_DEFAULT})"),
    "extra_author_scan_kinds": ("kind_list", "Extra author-scan kinds",
                                 "comma-separated kind numbers ADDED to the shipped allowlist for the "
                                 "full author scan, database totals, and the database walk — this can "
                                 "only widen coverage, never remove a shipped kind. Adding a kind here "
                                 "does not retroactively cover the CURRENT author-scan cache; rerun a "
                                 "full scan to include it."),
}

# min/max for the CONFIGURABLE int fields above, keyed by CONFIG_EDITABLE_FIELDS
# key. Not every "int" field is here — "port" is deliberately unclamped, since
# any operator-chosen port is as valid as any other. Read by get_settings_payload
# (to show the bound on the page) and write_app_config (to enforce it on save).
CONFIG_INT_BOUNDS = {
    "report_scan_limit": (REPORT_SCAN_LIMIT_MIN, REPORT_SCAN_LIMIT_MAX),
    "name_resolve_max": (NAME_RESOLVE_MAX_MIN, NAME_RESOLVE_MAX_MAX),
    "name_cache_max": (NAME_CACHE_MAX_MIN, NAME_CACHE_MAX_MAX),
    "domain_lookup_max": (DOMAIN_LOOKUP_MAX_MIN, DOMAIN_LOOKUP_MAX_MAX),
    "profile_event_limit": (PROFILE_EVENT_LIMIT_MIN, PROFILE_EVENT_LIMIT_MAX),
    "profile_report_limit": (PROFILE_REPORT_LIMIT_MIN, PROFILE_REPORT_LIMIT_MAX),
    "profile_day_events_max": (PROFILE_DAY_EVENTS_MAX_MIN, PROFILE_DAY_EVENTS_MAX_MAX),
    "reason_max_len": (REASON_MAX_LEN_MIN, REASON_MAX_LEN_MAX),
    "reason_undo_max": (REASON_UNDO_MAX_MIN, REASON_UNDO_MAX_MAX),
    "audit_log_max": (AUDIT_LOG_MAX_MIN, AUDIT_LOG_MAX_MAX),
}


def _get_config_int(key, default, min_v=None, max_v=None):
    """Generic reader for one CONFIGURABLE int field in config.json.
    Missing/invalid -> default. Clamped to [min_v, max_v] when given — same
    shape as get_giftwrap_retention_days, generalised so ten near-identical
    fields don't need ten copies of this."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh).get(key)
    except (OSError, ValueError):
        return default
    if raw is None or raw == "":
        return default
    try:
        n = int(raw)
    except (TypeError, ValueError):
        return default
    if min_v is not None:
        n = max(min_v, n)
    if max_v is not None:
        n = min(max_v, n)
    return n

# Help text for strfry.conf fields whose blank value means "use the default"
# rather than "set this empty". Sourced from strfry's own distributed conf:
# `nips = ""` is documented as "empty string to use default".
CONF_FIELD_HELP = {
    "relay.info.nips": "leave blank for strfry's default NIP list",
    # strfry marks kinds 20000–29999 with expiration=1, writes them so open
    # subscriptions can receive them, then RelayCron deletes them after this
    # many seconds. Lower = less ephemeral disk residency; 0 is not "never
    # write" — the write is what enables live broadcast.
    "events.ephemeralEventsLifetimeSeconds":
        "seconds kind-20000–29999 stay on disk before cron deletes them "
        "(default 300; live broadcast still requires a brief write)",
}

# Two tiers of settings-page risk, keyed by conf/config field path (matching
# parse_strfry_conf()'s "path" / CONFIG_EDITABLE_FIELDS' key) or, for the
# handful of things that aren't a field at all (the raw editors, the
# gift-wrap purge and compact buttons), one of the "__..__" action ids below.
# One table so there is one place to add the next entry — the page never
# hardcodes a warning string itself, it only renders what this table hands it.
#
# tier 1 (red outline + statement + confirm-before-acting): damage that is
# hard to walk back — takes the admin UI or the relay off the network, points
# a live process at the wrong database, or deletes data on its own next tick.
# Each tier-1 text says whether the damage shows up immediately or only after
# a restart, because that's exactly the gap that turns a typo into a surprise
# hours later.
#
# tier 2 (amber statement, no confirm): a plain sentence, changed value takes
# effect without derailing anything already running.
CONF_FIELD_WARNING = {
    "relay.writePolicy.plugin": {
        "tier": 1,
        "text": (
            "Do not change this path — strfry-86 depends on writePolicy.plugin "
            "pointing at plugin86.py, and changing it disables ban enforcement and "
            "the decision log immediately, since strfry re-reads this file live "
            "with no restart needed."
        ),
    },
    "relay.writePolicy.timeoutSeconds": {
        "tier": 1,
        "text": (
            "Too low a value makes strfry treat a slow plugin86.py decision as a "
            "timeout and fail open, immediately and with no restart, since strfry "
            "re-reads this file live."
        ),
    },
    "db": {
        "tier": 1,
        "text": (
            "A wrong path points strfry at a different (or empty) database — not "
            "visible until the relay's next restart, when it starts serving that "
            "dataset instead."
        ),
    },
    "relay.bind": {
        "tier": 1,
        "text": (
            "A wrong bind address can make the relay itself unreachable — not "
            "visible until the relay's next restart."
        ),
    },
    "relay.port": {
        "tier": 1,
        "text": (
            "A wrong port can make the relay itself unreachable — not visible "
            "until the relay's next restart."
        ),
    },
    "port": {
        "tier": 1,
        "text": (
            "A wrong port makes the admin UI unreachable at its old address — "
            "not visible until the next start, when nothing answers there."
        ),
    },
    "bind": {
        "tier": 1,
        "text": (
            "A wrong bind address makes the admin UI unreachable — not visible "
            "until the next start, when nothing is listening where you expect."
        ),
    },
    "public_origin": {
        "tier": 1,
        "text": (
            "A wrong origin makes every NIP-98 request fail immediately while "
            "the login button still appears to work — every save, ban, or scan "
            "quietly 401s."
        ),
    },
    "strfry_conf_path": {
        "tier": 1,
        "text": (
            "A wrong path points every scan and delete at a different database "
            "immediately, with no error — Users, Stats, and Settings just start "
            "showing that database's data."
        ),
    },
    "giftwrap_retention_days": {
        "tier": 1,
        "text": (
            "Lowering this deletes kind-1059 gift wraps older than the new "
            "window — not visible until the next hourly retention loop runs, "
            "by which point the data is already gone."
        ),
    },
    "relay_url": {
        "tier": 2,
        "text": "Wrong value makes subscriber scans look for this relay's own subscriptions on the wrong relay.",
    },
    "events.ephemeralEventsLifetimeSeconds": {
        "tier": 2,
        "text": "Raising this keeps ephemeral (kind 20000–29999) events on disk longer before RelayCron deletes them.",
    },
    "relay.info.pubkey": {
        "tier": 2,
        "text": "Changes the relay's published NIP-11 admin identity — clients or directories that pinned the old value will see a mismatch.",
    },
    "__raw_relay__": {
        "tier": 1,
        "text": (
            "Raw edits bypass every per-field check above — a typo can silently "
            "change a field you didn't mean to touch, and nothing catches it "
            "until save or the relay's next restart."
        ),
    },
    "__raw_app__": {
        "tier": 1,
        "text": (
            "Raw edits bypass every per-field check above except the "
            "admin_pubkey_hex guard — a subtly wrong value saves without warning."
        ),
    },
    "__giftwrap_purge__": {
        "tier": 1,
        "text": "Deletes matching gift wraps immediately and permanently — there is no undo in this UI.",
    },
    "__db_compact__": {
        "tier": 1,
        "text": (
            "Writes a full copy of the database immediately, needing free disk "
            "roughly the size of the copy, and can run long on a large relay."
        ),
    },
}


def _config_raw():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def _path_writable(path):
    """True when this process can open the path for writing. Used only to
    tell the Settings page up front; the write itself still fails loud if
    permissions change between the check and the save."""
    return bool(path) and os.path.isfile(path) and os.access(path, os.W_OK)


def get_giftwrap_retention_days():
    """Days of kind-1059 history to keep. Missing/invalid config → default 30.
    Clamped to [GIFTWRAP_RETENTION_MIN, GIFTWRAP_RETENTION_MAX]."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh).get("giftwrap_retention_days")
    except (OSError, ValueError):
        return GIFTWRAP_RETENTION_DEFAULT
    if raw is None or raw == "":
        return GIFTWRAP_RETENTION_DEFAULT
    try:
        days = int(raw)
    except (TypeError, ValueError):
        return GIFTWRAP_RETENTION_DEFAULT
    return max(GIFTWRAP_RETENTION_MIN, min(GIFTWRAP_RETENTION_MAX, days))


def get_report_scan_limit():
    return _get_config_int("report_scan_limit", REPORT_SCAN_LIMIT_DEFAULT, REPORT_SCAN_LIMIT_MIN, REPORT_SCAN_LIMIT_MAX)


def get_name_resolve_max():
    return _get_config_int("name_resolve_max", NAME_RESOLVE_MAX_DEFAULT, NAME_RESOLVE_MAX_MIN, NAME_RESOLVE_MAX_MAX)


def get_name_cache_max():
    return _get_config_int("name_cache_max", NAME_CACHE_MAX_DEFAULT, NAME_CACHE_MAX_MIN, NAME_CACHE_MAX_MAX)


def get_domain_lookup_max():
    return _get_config_int("domain_lookup_max", DOMAIN_LOOKUP_MAX_DEFAULT, DOMAIN_LOOKUP_MAX_MIN, DOMAIN_LOOKUP_MAX_MAX)


def get_profile_event_limit():
    return _get_config_int("profile_event_limit", PROFILE_EVENT_LIMIT_DEFAULT, PROFILE_EVENT_LIMIT_MIN, PROFILE_EVENT_LIMIT_MAX)


def get_profile_report_limit():
    return _get_config_int("profile_report_limit", PROFILE_REPORT_LIMIT_DEFAULT, PROFILE_REPORT_LIMIT_MIN, PROFILE_REPORT_LIMIT_MAX)


def get_profile_day_events_max():
    return _get_config_int("profile_day_events_max", PROFILE_DAY_EVENTS_MAX_DEFAULT, PROFILE_DAY_EVENTS_MAX_MIN, PROFILE_DAY_EVENTS_MAX_MAX)


def get_reason_max_len():
    return _get_config_int("reason_max_len", REASON_MAX_LEN_DEFAULT, REASON_MAX_LEN_MIN, REASON_MAX_LEN_MAX)


def get_reason_undo_max():
    return _get_config_int("reason_undo_max", REASON_UNDO_MAX_DEFAULT, REASON_UNDO_MAX_MIN, REASON_UNDO_MAX_MAX)


def get_audit_log_max():
    return _get_config_int("audit_log_max", AUDIT_LOG_MAX_DEFAULT, AUDIT_LOG_MAX_MIN, AUDIT_LOG_MAX_MAX)


def get_extra_author_scan_kinds():
    """Operator-added kinds from config.json's `extra_author_scan_kinds` —
    a list of non-negative ints, missing/invalid/empty -> (). Never
    validated against NIP kind-number conventions beyond "non-negative
    integer": an operator adding a kind their own relay actually uses is
    trusted the same way REASON_MAX_LEN trusts an operator's own reason
    text."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh).get("extra_author_scan_kinds")
    except (OSError, ValueError):
        return ()
    if not isinstance(raw, list):
        return ()
    out = []
    for v in raw:
        if isinstance(v, bool):
            continue
        if isinstance(v, int) and v >= 0:
            out.append(v)
    return tuple(out)


def get_effective_author_scan_kinds():
    """The SHIPPED default UNION any operator additions — never a
    replacement, so an operator can only widen coverage, never silently
    drop a kind this project ships allowlisted. This is what every scan,
    count, and comparison that means "the allowlist" should read; direct
    reads of AUTHOR_SCAN_KINDS are reserved for the two places that define
    or audit the shipped default itself."""
    return tuple(sorted(set(AUTHOR_SCAN_KINDS) | set(get_extra_author_scan_kinds())))


# Every CONFIGURABLE int field's accessor, keyed the same as CONFIG_INT_BOUNDS
# — used by get_settings_payload so the page shows the value actually in
# effect (defaulted/clamped), not a raw, possibly-unset config.json read.
CONFIG_INT_GETTERS = {
    "report_scan_limit": get_report_scan_limit,
    "name_resolve_max": get_name_resolve_max,
    "name_cache_max": get_name_cache_max,
    "domain_lookup_max": get_domain_lookup_max,
    "profile_event_limit": get_profile_event_limit,
    "profile_report_limit": get_profile_report_limit,
    "profile_day_events_max": get_profile_day_events_max,
    "reason_max_len": get_reason_max_len,
    "reason_undo_max": get_reason_undo_max,
    "audit_log_max": get_audit_log_max,
}


def get_settings_payload():
    conf_status = strfry_conf_status()
    conf_text, conf_err = read_strfry_conf()
    conf_fields, conf_balanced = parse_strfry_conf(conf_text or "")
    for f in conf_fields:
        help_text = CONF_FIELD_HELP.get(f["path"])
        if help_text:
            f["help"] = help_text
        risk = CONF_FIELD_WARNING.get(f["path"])
        if risk:
            f["tier"] = risk["tier"]
            f["warning"] = risk["text"]
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            cfg_data = json.load(fh)
    except (OSError, ValueError):
        cfg_data = {}
    app_fields = []
    for key, (ftype, label, help_text) in CONFIG_EDITABLE_FIELDS.items():
        if key == "giftwrap_retention_days":
            value = get_giftwrap_retention_days()
        elif key in CONFIG_INT_GETTERS:
            value = CONFIG_INT_GETTERS[key]()
        elif ftype == "kind_list":
            value = ", ".join(str(k) for k in get_extra_author_scan_kinds())
        else:
            value = cfg_data.get(key, "") if cfg_data.get(key) is not None else ""
        field = {
            "path": key, "key": key, "section": "strfry-86", "label": label,
            "help": help_text, "type": ftype,
            "value": value,
        }
        risk = CONF_FIELD_WARNING.get(key)
        if risk:
            field["tier"] = risk["tier"]
            field["warning"] = risk["text"]
        if ftype == "range":
            field["min"] = GIFTWRAP_RETENTION_MIN
            field["max"] = GIFTWRAP_RETENTION_MAX
            field["step"] = 1
        elif key in CONFIG_INT_BOUNDS:
            field["min"], field["max"] = CONFIG_INT_BOUNDS[key]
        app_fields.append(field)
    conf_path = conf_status.get("path")
    return {
        "relay": {
            "path": conf_path, "fields": conf_fields,
            "raw": conf_text or "", "error": conf_err, "balanced": conf_balanced,
            "candidates": conf_status.get("candidates"),
            # Ambiguity only: mismatch between override/fallback and the
            # running relay. Happy-path source narration stays off the page.
            "warning": conf_status.get("error") if conf_status.get("exists") else None,
            "writable": (_path_writable(conf_path) if conf_status.get("exists") else None),
            "raw_warning": CONF_FIELD_WARNING["__raw_relay__"]["text"],
        },
        "app": {
            "path": CONFIG_PATH, "fields": app_fields, "raw": _config_raw(),
            "error": None, "balanced": True,
            "writable": _path_writable(CONFIG_PATH),
            "raw_warning": CONF_FIELD_WARNING["__raw_app__"]["text"],
        },
        # The admin-only copy of purge/compact status, carrying the failure
        # text the public poll endpoints withhold. The Settings page is the
        # only thing that needs it, and it already authenticates to load this.
        "purge": get_giftwrap_purge_status(include_detail=True),
        "ephemeral_purge": get_ephemeral_purge_status(include_detail=True),
        "compact": get_db_compact_status(include_detail=True),
        "giftwrap_purge_warning": CONF_FIELD_WARNING["__giftwrap_purge__"]["text"],
        "db_compact_warning": CONF_FIELD_WARNING["__db_compact__"]["text"],
    }


def write_app_config(edits=None, raw=None):
    """Write config.json — either field edits (validated against
    CONFIG_EDITABLE_FIELDS) or a raw replacement (validated as JSON that
    still carries a usable admin_pubkey_hex). Never drops a key it does not
    know about; an operator's own additions survive a field edit."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            current = json.load(fh)
        if not isinstance(current, dict):
            return False, "config.json is not an object"
    except (OSError, ValueError) as e:
        return False, f"{type(e).__name__}: {e}"

    if raw is not None:
        try:
            parsed = json.loads(raw)
        except ValueError as e:
            return False, f"not valid JSON: {e}"
        if not isinstance(parsed, dict):
            return False, "config.json must be a JSON object"
        admin_raw = parsed.get("admin_pubkey_hex")
        if not is_hex64(admin_raw):
            return False, "admin_pubkey_hex missing or not 64 hex characters — refusing to lock you out"
        parsed["admin_pubkey_hex"] = admin_raw.lower()
        new_data = parsed
    else:
        new_data = dict(current)
        for key, value in (edits or {}).items():
            spec = CONFIG_EDITABLE_FIELDS.get(key)
            if spec is None:
                continue
            if spec[0] in ("int", "range"):
                try:
                    n = int(str(value).strip())
                except ValueError:
                    return False, f"{key} must be a whole number"
                if key == "giftwrap_retention_days":
                    n = max(GIFTWRAP_RETENTION_MIN, min(GIFTWRAP_RETENTION_MAX, n))
                elif key in CONFIG_INT_BOUNDS:
                    lo, hi = CONFIG_INT_BOUNDS[key]
                    n = max(lo, min(hi, n))
                new_data[key] = n
            elif spec[0] == "kind_list":
                text = str(value).strip()
                if not text:
                    new_data[key] = []
                else:
                    kinds = []
                    for tok in text.replace(",", " ").split():
                        try:
                            k = int(tok)
                        except ValueError:
                            return False, f"{key}: {tok!r} is not a whole number"
                        if k < 0:
                            return False, f"{key}: {tok!r} must not be negative"
                        kinds.append(k)
                    new_data[key] = sorted(set(kinds))
            elif key == "strfry_conf_path" and not str(value).strip():
                new_data.pop(key, None)
            else:
                new_data[key] = str(value)
        # Keep any pre-existing admin key lowercase even if an old file had
        # mixed case; structured edits cannot change it, but we rewrite it.
        if is_hex64(new_data.get("admin_pubkey_hex")):
            new_data["admin_pubkey_hex"] = new_data["admin_pubkey_hex"].lower()

    try:
        tmp = CONFIG_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(new_data, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, CONFIG_PATH)
    except OSError as e:
        return False, f"{type(e).__name__}: {e}"
    return True, None


# --- relay metrics (the Stats page's headline figures) ----------------------
# Every figure here is either already in a cache this server keeps, or is one
# stat() away. Nothing in this function starts a scan, and nothing reaches the
# network — a page of headline numbers must never be the most expensive thing
# on the relay.

_rate_samples = []          # (monotonic seconds, events counted in that tick)


def _record_rate_sample(count):
    now = time.monotonic()
    _rate_samples.append((now, count))
    cutoff = now - 60
    while _rate_samples and _rate_samples[0][0] < cutoff:
        _rate_samples.pop(0)


def _events_per_sec():
    """Trailing average over the samples still inside the window. None until
    two polls have landed — rule 9: not yet known renders as `—`, never 0."""
    if len(_rate_samples) < 2:
        return None
    span = _rate_samples[-1][0] - _rate_samples[0][0]
    if span <= 0:
        return None
    return sum(c for _, c in _rate_samples[1:]) / span


def _strfry_db_bytes():
    """Size of the LMDB directory strfry.conf points at, resolved exactly
    the way the relay resolves it (relative to the relay's own cwd)."""
    text, err = read_strfry_conf()
    if err or not text:
        return None, None
    fields, _ = parse_strfry_conf(text)
    db_path = None
    for f in fields:
        if f["key"] == "db":
            db_path = f["value"]
            break
    if not db_path:
        return None, None
    if not os.path.isabs(db_path):
        try:
            db_path = os.path.join(get_relay_cwd(), db_path)
        except Exception:
            return None, db_path
    total = 0
    try:
        for entry in os.scandir(db_path):
            if entry.is_file():
                total += entry.stat().st_size
    except OSError:
        return None, db_path
    return total, db_path


def get_relay_metrics():
    report = get_report_status()
    totals = report.get("totals") or {}
    walk = report.get("walk") or {}
    rows, accepted, blocked, judged = _live_feed_state()
    db_bytes, db_path = _strfry_db_bytes()

    top_kind, top_kind_count = None, None
    kinds = walk.get("kinds") if isinstance(walk.get("kinds"), dict) else None
    if kinds:
        top = max(kinds.items(), key=lambda kv: kv[1])
        top_kind, top_kind_count = int(top[0]), top[1]

    judged_total = (accepted or 0) + (blocked or 0) if judged else 0
    # /api/metrics is a PUBLIC read, so it carries no filesystem paths — only
    # whether the config was resolvable at all. The paths themselves, and the
    # explanation of how one was chosen, live in the admin-only settings
    # payload where disclosing them is already the point.
    conf = strfry_conf_status()
    baseline_at = totals.get("scanned_at") or walk.get("scanned_at")
    events_total = totals.get("total_events")
    # Live-up the headline total: baseline + events seen since − kind-5
    # deletes since. Matches the stats tile, so a metrics poll alone keeps
    # the number moving even if the SSE stream is stalled.
    with _live_lock:
        if (events_total is not None
                and baseline_at is not None
                and _live_delta_baseline_at == baseline_at):
            events_total = events_total + _live_new_events - _live_deletes
    return {
        "events_per_sec": _events_per_sec(),
        "events_total": events_total,
        "db_bytes": db_bytes,
        "conf_ok": bool(conf.get("exists")),
        "conf_source": conf.get("source"),
        "accept_rate": (accepted / judged_total) if judged_total else None,
        "judged": judged_total or None,
        "blocked": blocked if judged else None,
        "top_kind": top_kind,
        "top_kind_count": top_kind_count,
        "top_kind_share": (top_kind_count / walk["events_read"])
                          if top_kind_count and walk.get("events_read") else None,
        "giftwrap_events": totals.get("giftwrap_events"),
        "giftwrap_share": totals.get("giftwrap_share"),
        "gap_events": totals.get("gap_events"),
        "gap_share": totals.get("gap_share"),
        "gap_level": totals.get("gap_level"),
        "giftwrap_retention_days": get_giftwrap_retention_days(),
        "baseline_at": baseline_at,
    }


def _make_progress_cb(job):
    """Returns a stateful progress_cb(count, total=None) closure for one
    scan run. `total` is sticky — once given (e.g. the report walk seeding
    it from its own `--count` before streaming starts), later calls that
    omit it keep the last known value. rate/eta are a trailing average over
    RATE_SMOOTHING_WINDOW seconds of (time, count) samples rather than
    since-start, so they settle quickly instead of drifting; before two
    samples exist in the window both are None and callers must render
    'estimating…' rather than a number."""
    samples = []
    state = {"total": None}

    def cb(count, total=None):
        if total is not None:
            state["total"] = total
        now = time.monotonic()
        samples.append((now, count))
        while len(samples) > 1 and now - samples[0][0] > RATE_SMOOTHING_WINDOW:
            samples.pop(0)
        rate = None
        eta = None
        if len(samples) >= 2:
            dt = samples[-1][0] - samples[0][0]
            dc = samples[-1][1] - samples[0][1]
            if dt > 0 and dc > 0:
                rate = dc / dt
                if state["total"] is not None and state["total"] > count:
                    eta = (state["total"] - count) / rate
        with _scan_lock:
            job["progress"] = count
            job["total"] = state["total"]
            job["rate"] = rate
            job["eta"] = eta

    return cb


def _run_scan_job(name, job, cache, cache_path, compute_fn):
    """Background-thread body for one async scan. `compute_fn(progress_cb)`
    returns the result dict on success. On failure the previous cache is
    preserved (mutated with an `error` attached, never `scanned_at`) and
    NEVER replaced with a partial result — a scan that hit its deadline, or
    a precondition that was never satisfiable, is a FAILED run, not a
    smaller answer. `error` is distinct from `warning`: `warning` rides
    inside a result that IS rendered; `error` replaces a result that is
    not, and a stale `scanned_at` must never be presented as this attempt's
    age. Always releases the global lock on the way out, success or
    failure — a deadline that fires without releasing the lock would
    disable every scan in the deployment until the container restarts."""
    progress_cb = _make_progress_cb(job)
    try:
        result = compute_fn(progress_cb)
    except Exception as e:
        error = f"{name} scan failed: {type(e).__name__}: {e}"[:600]
        log(f"server86: {error}")
        with _scan_lock:
            cache["error"] = error
            job["status"] = "idle"
            job["progress"] = None
            job["total"] = None
            job["rate"] = None
            job["eta"] = None
            if "partial_authors" in job:
                job["partial_authors"] = None
            _active_scan["name"] = None
        return

    try:
        _save_cache_atomic(cache_path, result)
    except OSError as e:
        log(f"server86: failed to persist {os.path.basename(cache_path)}: {e}")

    with _scan_lock:
        cache.clear()
        cache.update(result)
        job["status"] = "idle"
        job["progress"] = None
        job["total"] = None
        job["rate"] = None
        job["eta"] = None
        if "partial_authors" in job:
            job["partial_authors"] = None
        _active_scan["name"] = None


def _start_scan_job(name, job, run_target, extra_job_fields=None, on_started=None):
    """Single-flight per endpoint, AND global across every scan endpoint:

    - A POST naming the job that is already running returns the SAME 202
      shape the original POST returned, so a POST-then-GET from one client
      never observes a state its own POST couldn't have produced.
    - A POST naming a DIFFERENT job while one is running does not start a
      second subprocess and does not 409 — it returns the RUNNING job's own
      status, with `blocked_by` naming it, so the caller can tell the two
      apart from the response shape alone.

    `on_started` runs exactly once, and only for the call that actually
    launched the thread. It exists because a caller CANNOT determine that for
    itself: checking the lock before calling races with the call, so a
    destructive job that guesses either records a run that never happened or
    runs with no record at all. It is deliberately not a field on the
    returned status — the two POSTs above must stay byte-identical.

    RSS is sampled OUTSIDE the lock, and only on the path that is actually
    about to launch a job: on a host with no /proc (macOS/BSD),
    _process_rss_bytes() falls back to spawning `ps` and waiting up to a
    second for it. Doing that while holding _scan_lock would stall every
    other lock user (including the live-feed poll thread's baseline
    lookup); doing it unconditionally on every call — including the
    already-running/blocked fast paths below, which never needed an RSS
    figure at all — adds needless subprocess latency to the common case.
    So the lock is taken twice: once to cheaply resolve the already-
    running/blocked outcomes, and — only when neither applies — again
    after sampling RSS, re-checking nothing else grabbed the lock meanwhile."""
    launched = False

    def _blocked_status(running):
        # Console holds the lock as name "console" without a registry
        # entry; every other job is registered.
        reg = _JOB_REGISTRY.get(running)
        status = dict(reg) if reg is not None else {
            "status": "running", "started_at": None,
            "progress": None, "total": None, "rate": None, "eta": None,
        }
        status["blocked_by"] = running
        return status

    with _scan_lock:
        running = _active_scan["name"]
        if running == name:
            status = dict(job)
            status["blocked_by"] = None
            return status
        if running is not None:
            return _blocked_status(running)

    # Nothing was running a moment ago — sample RSS without the lock held,
    # then re-take it and re-check before actually claiming the slot.
    rss = _process_rss_bytes()
    with _scan_lock:
        running = _active_scan["name"]
        if running == name:
            status = dict(job)
            status["blocked_by"] = None
            return status
        if running is not None:
            return _blocked_status(running)
        # Soft RSS gate: do not start another multi-minute scan when the
        # process is already near the soft ceiling. Walk/author/recipient
        # peaks need headroom; a refusal is better than an OOM mid-walk.
        if rss is not None and rss >= MEMORY_SOFT_BYTES:
            status = {
                "status": "idle", "started_at": None,
                "progress": None, "total": None, "rate": None, "eta": None,
                "blocked_by": "memory",
                "error": (
                    f"refused: process RSS {rss // (1024 * 1024)}MB is at or above "
                    f"the {MEMORY_SOFT_BYTES // (1024 * 1024)}MB soft cap — "
                    f"finish or restart before starting another scan"
                ),
            }
            if extra_job_fields:
                status.update({k: v for k, v in extra_job_fields.items()
                               if k not in status})
            return status
        _active_scan["name"] = name
        job.clear()
        job.update({
            "status": "running", "started_at": int(time.time()),
            "progress": 0, "total": None, "rate": None, "eta": None,
        })
        if name == "authors":
            # Empty list (not None) so the client can start painting an empty
            # table immediately; None means "not a streaming scan".
            job["partial_authors"] = []
        if extra_job_fields:
            job.update(extra_job_fields)
        status = dict(job)
        status["blocked_by"] = None
        launched = True

    # Outside the lock: on_started writes to disk (the audit log), and every
    # status read in the project waits on this lock. Before the thread, so
    # the record exists by the time the job can do anything.
    if launched and on_started is not None:
        on_started()
    threading.Thread(target=run_target, daemon=True).start()
    return status


def _scan_status(name, job, cache):
    """GET handler body: never scans, never starts one. Merges the live
    job status over the last persisted result, so status/progress always
    reflect what's happening now and every other field reflects the last
    completed scan (or the never-scanned skeleton). `blocked_by` names
    whatever OTHER job currently holds the global lock — null while this
    job is the one running, or while nothing is running at all."""
    with _scan_lock:
        status = dict(job)
        cached = dict(cache)
        running = _active_scan["name"]
    cached.update(status)
    cached["blocked_by"] = running if running not in (None, name) else None
    return cached


def _publish_authors_partial(tally, force=False, _state=None):
    """Publish the current top-RENDER_PAGE_MAX authors onto `_authors_job` for
    the Users table to stream while the scan is still running.

    Lives only on the job dict — never the persisted authors cache and
    never stamped with scanned_at. Throttled to ~1.5s between publishes
    so a full-list tally is not fully sorted on every 500-event progress
    tick; `force=True` always publishes (stream end)."""
    if _state is None:
        _state = {"last_at": 0.0}
    now = time.monotonic()
    if not force and (now - _state["last_at"]) < 1.5:
        return
    _state["last_at"] = now
    # Rank by count only mid-scan — the reports pass has not run yet, so
    # reporters is always null here (rule 9: unknown, not 0).
    ranked = sorted(
        ((pk, e) for pk, e in tally.items() if is_hex64(pk)),
        key=lambda kv: kv[1]["count"],
        reverse=True,
    )[:RENDER_PAGE_MAX]
    partial = []
    for pk, entry in ranked:
        partial.append({
            "pubkey": pk,
            "name": None,
            "nip05": None,
            "count": entry["count"],
            "last_seen": entry["last_seen"],
            "reporters": None,
        })
    with _scan_lock:
        if _authors_job.get("status") != "running":
            return
        _authors_job["partial_authors"] = partial


def compute_authors(mode, progress_cb=None):
    """One bounded scan of AUTHOR_SCAN_MODES[mode], tallied per author and
    per kind while streaming — no list of event bodies is ever held in
    full. Depends on NIP-01 `limit` returning the newest matching events
    first, as documented; verify that against the deployed strfry version
    before relying on it.

    While streaming, the top RENDER_PAGE_MAX authors by count so far are
    published onto `_authors_job["partial_authors"]` so GET /api/authors
    and /api/userlist can fill the Users table mid-scan. Partials never
    touch the persisted cache.

    A second, independent scan tallies DISTINCT reporters per pubkey from
    recent kind-1984 reports — never itself grounds for a ban, a signal to
    look at. If it fails, `reporters` is null for every author (never a
    misleading 0) and the default sort falls back to event count alone;
    the main author list still succeeds. Neither scan touches purplepag.es
    or writes to blacklist.json — both are paid for by the same admin
    press."""
    start = time.monotonic()
    filter_obj = dict(AUTHOR_SCAN_MODES[mode])
    scan_kinds = None
    if mode == "full":
        # Filled in here, not at import time, so an operator's config.json
        # additions (get_effective_author_scan_kinds) are picked up fresh
        # on every scan, not frozen at whatever they were when server86
        # started.
        scan_kinds = get_effective_author_scan_kinds()
        filter_obj["kinds"] = list(scan_kinds)
    limit = filter_obj.get("limit")
    # "full" mode carries no limit — get the exact matching count up front
    # (cheap: index-only, per run_strfry_count's own docstring) so a
    # progress bar has a real denominator and, if AUTHOR_SCAN_DEADLINE ends
    # up binding, the result can say exactly how far short it fell.
    total_matching = None
    if limit is None:
        total_matching = run_strfry_count({"kinds": list(scan_kinds)}, timeout=AUTHOR_SCAN_DEADLINE)
    if progress_cb:
        progress_cb(0, total=limit if limit is not None else total_matching)
    tally = {}  # pubkey -> {"count": int, "last_seen": int, "kind": int_or_None}
    kind_counts = {}
    span = {"start": None, "end": None}
    partial_state = {"last_at": 0.0}

    def on_event(ev):
        if not isinstance(ev, dict):
            return
        pk = ev.get("pubkey")
        created_at = ev.get("created_at")
        kind = ev.get("kind")
        if not isinstance(pk, str) or not isinstance(created_at, int):
            return
        entry = tally.get(pk)
        if entry is None:
            tally[pk] = {"count": 1, "last_seen": created_at, "kind": kind if isinstance(kind, int) else None}
        else:
            entry["count"] += 1
            if created_at > entry["last_seen"]:
                entry["last_seen"] = created_at
                entry["kind"] = kind if isinstance(kind, int) else None
        if isinstance(kind, int):
            kind_counts[kind] = kind_counts.get(kind, 0) + 1
        if span["start"] is None or created_at < span["start"]:
            span["start"] = created_at
        if span["end"] is None or created_at > span["end"]:
            span["end"] = created_at

    def on_progress(count, total=None):
        if progress_cb:
            progress_cb(count, total=total)
        _publish_authors_partial(tally, force=False, _state=partial_state)

    events_read, timed_out = run_strfry_scan_streaming(
        filter_obj, on_event, timeout=AUTHOR_SCAN_DEADLINE, on_progress=on_progress,
        timeout_ok=True,
    )
    _publish_authors_partial(tally, force=True, _state=partial_state)
    saturated = timed_out or (limit is not None and events_read >= limit)

    singleton_kinds = {}
    for entry in tally.values():
        if entry["count"] == 1 and entry["kind"] is not None:
            singleton_kinds[entry["kind"]] = singleton_kinds.get(entry["kind"], 0) + 1

    reporters_by_pubkey = {}
    reports_ok = True
    reports_scanned = 0
    reports_saturated = False
    report_scan_limit = get_report_scan_limit()
    try:
        report_events = run_strfry_scan({"kinds": [1984], "limit": report_scan_limit}, timeout=SCAN_TIMEOUT)
        reports_scanned = len(report_events)
        reports_saturated = reports_scanned >= report_scan_limit
        for ev in report_events:
            reporter = ev.get("pubkey")
            tags = ev.get("tags")
            if not isinstance(reporter, str) or not isinstance(tags, list):
                continue
            for tag in tags:
                if isinstance(tag, list) and len(tag) >= 2 and tag[0] == "p" and isinstance(tag[1], str):
                    reporters_by_pubkey.setdefault(tag[1], set()).add(reporter)
    except Exception as e:
        log(f"server86: reports tally failed: {e}")
        reports_ok = False

    all_pubkeys = set(tally.keys())
    if reports_ok:
        all_pubkeys |= set(reporters_by_pubkey.keys())

    # No bech32/npub here at all — the client encodes it lazily, only for
    # the handful of rows it actually renders (see s86BuildIdentityCell).
    # Encoding all of these up front was pure waste once CACHE_LIST_MAX
    # will drop the tail anyway, and it bloated authors-cache.json for
    # every row that survives. Free the streaming tally as soon as the
    # compact rank rows exist.
    rows = []
    for pk in all_pubkeys:
        if not is_hex64(pk):
            continue
        entry = tally.get(pk, {"count": 0, "last_seen": None})
        reporters = len(reporters_by_pubkey.get(pk, ())) if reports_ok else None
        rows.append({
            "pubkey": pk,
            "count": entry["count"], "last_seen": entry["last_seen"],
            "reporters": reporters,
        })
    tally.clear()
    reporters_by_pubkey.clear()
    all_pubkeys.clear()
    if reports_ok:
        rows.sort(key=lambda a: (a["reporters"] or 0, a["count"]), reverse=True)
    else:
        rows.sort(key=lambda a: a["count"], reverse=True)

    rows, list_total, list_omitted = _cap_list_rows(rows)

    # Names: batched, capped at NAME_RESOLVE_MAX, taken from the top of
    # the ranking above. Single-event authors are skipped entirely — on a
    # real relay they are overwhelmingly gift-wrap-adjacent throwaway
    # keys with no kind-0 to find, and resolving them would spend the
    # whole cap on the least useful rows.
    to_resolve = [r["pubkey"] for r in rows if r["count"] != 1][:get_name_resolve_max()]
    name_resolution_error = None
    try:
        profiles, name_resolution_error = resolve_profiles(to_resolve)
    except Exception as e:
        log(f"server86: author name resolution failed: {e}")
        profiles = {}
        name_resolution_error = str(e)

    # A single-event author skipped above may still already have a name
    # resolved via some OTHER path (a previous scan, the banlist's own
    # resolution) sitting in names.json — join it in here too, cache-only,
    # no scan, so it isn't shown as unknown just because this scan didn't
    # look it up again.
    already_cached = _cached_names_only([r["pubkey"] for r in rows if r["count"] == 1])

    authors = []
    for r in rows:
        profile = profiles.get(r["pubkey"]) or already_cached.get(r["pubkey"]) or {}
        authors.append({
            "pubkey": r["pubkey"],
            "name": profile.get("name"), "nip05": profile.get("nip05"),
            "count": r["count"], "last_seen": r["last_seen"],
            "reporters": r["reporters"],
        })
    del rows

    warning = None if reports_ok else "reports tally failed — sorting by event count only"
    if timed_out:
        # Rare by design (see AUTHOR_SCAN_DEADLINE) — genuinely unbounded now
        # that "full" mode carries no count limit, so this is the one place
        # completeness can still be silently lost if it isn't said plainly.
        deadline_note = (
            f"ran out of time after {AUTHOR_SCAN_DEADLINE}s — read {events_read:,} of "
            f"{total_matching:,} matching events" if total_matching is not None
            else f"ran out of time after {AUTHOR_SCAN_DEADLINE}s — read {events_read:,} events"
        )
        warning = (warning + " — " + deadline_note) if warning else deadline_note
    if list_omitted:
        trunc_note = (
            f"author list truncated to top {CACHE_LIST_MAX:,} of "
            f"{list_total:,} (lowest-activity tail dropped to protect memory)"
        )
        warning = (warning + " — " + trunc_note) if warning else trunc_note
    if name_resolution_error:
        warning = (warning + " — " + name_resolution_error) if warning else name_resolution_error

    return {
        "scanned_at": int(time.time()),
        "duration": time.monotonic() - start,
        "mode": mode,
        "limit": limit,
        "scan_kinds": list(scan_kinds) if scan_kinds is not None else None,
        "total_matching": total_matching,
        "saturated": saturated,
        "timed_out": timed_out,
        "events_read": events_read,
        "span_start": span["start"],
        "span_end": span["end"],
        "kinds": kind_counts,
        "singleton_kinds": singleton_kinds,
        "reports_saturated": reports_saturated,
        "reports_scanned": reports_scanned,
        "reports_scan_limit": report_scan_limit,
        "list_total": list_total,
        "list_omitted": list_omitted,
        "warning": warning,
        "error": None,
        "authors": authors,
    }


def _empty_authors_result():
    return {
        "scanned_at": None, "duration": None, "mode": None, "limit": None,
        "scan_kinds": None, "total_matching": None, "saturated": False, "timed_out": False,
        "events_read": 0, "span_start": None, "span_end": None,
        "kinds": {}, "singleton_kinds": {},
        "reports_saturated": False, "reports_scanned": 0, "reports_scan_limit": None,
        "list_total": 0, "list_omitted": 0,
        "warning": None, "error": None, "authors": [],
    }


_authors_cache = _load_cache_or(AUTHORS_CACHE_PATH, _empty_authors_result())
_JOB_REGISTRY["authors"] = _authors_job

# Measured duration of the last successful run of EACH mode, ON THIS RELAY —
# kept separate from authors-cache.json (which holds only the latest scan's
# result and would lose every other mode's measurement the moment a
# different mode is run) so an empty-state press can be estimated honestly
# without inventing a number or reusing one from a different relay.
AUTHOR_MODE_DURATIONS_PATH = os.path.join(SCRIPT_DIR, "author-mode-durations.json")
_author_mode_durations = _load_cache_or(AUTHOR_MODE_DURATIONS_PATH, {})


def start_authors_scan(mode):
    """Start one bounded author scan in a background thread if none is
    already running (and no OTHER scan holds the global lock) — never
    blocks the request."""
    def run():
        _run_scan_job(
            "authors", _authors_job, _authors_cache, AUTHORS_CACHE_PATH,
            lambda progress_cb: compute_authors(mode, progress_cb=progress_cb),
        )
        with _scan_lock:
            ok = _authors_cache.get("error") is None and _authors_cache.get("mode") == mode
            duration = _authors_cache.get("duration") if ok else None
        if duration is not None:
            _author_mode_durations[mode] = duration
            try:
                _save_cache_atomic(AUTHOR_MODE_DURATIONS_PATH, _author_mode_durations)
            except OSError as e:
                log(f"server86: failed to persist author-mode-durations.json: {e}")
    return _start_scan_job("authors", _authors_job, run, extra_job_fields={"mode": mode})


def _authors_cache_kinds_stale(status):
    """True when the cached FULL-mode author scan's kind set no longer
    covers every kind in the CURRENT effective allowlist — i.e. an
    operator added a kind via config.json's extra_author_scan_kinds AFTER
    this scan ran, so the cache does not yet include events of that kind.
    'recent' mode scans every kind unconditionally and is never stale by
    this measure; a cache with no recorded scan_kinds (never run in full
    mode, or from before this field existed) is not 'stale', just not
    comparable — silence over a false claim either way."""
    if status.get("mode") != "full":
        return False
    cached_kinds = status.get("scan_kinds")
    if not cached_kinds:
        return False
    return not set(get_effective_author_scan_kinds()) <= set(cached_kinds)


def get_authors_status():
    """GET /api/authors: never scans, never starts one. `modes` names every
    selectable AUTHOR_SCAN_MODES entry with its bound and its measured
    typical duration ON THIS RELAY — null until a run of that mode has
    completed successfully at least once, never a number from elsewhere."""
    status = _scan_status("authors", _authors_job, _authors_cache)
    status["modes"] = {
        name: {"events": cfg.get("limit"), "typical_seconds": _author_mode_durations.get(name)}
        for name, cfg in AUTHOR_SCAN_MODES.items()
    }
    status["kinds_stale"] = _authors_cache_kinds_stale(status)
    return status


def authors_scan_pubkeys():
    """The set of pubkeys currently in the author-scan cache — the second
    half of /api/names' accept-bound (banned OR in this set), and never
    itself a scan."""
    with _scan_lock:
        cached = _authors_cache
    return {a["pubkey"] for a in cached.get("authors", [])}


def _authors_status_for_http(status):
    """GET /api/authors is scan-status only — the Users table gets its rows
    from GET /api/userlist, which reads this same cache in-process via
    get_userlist_snapshot()/authors_scan_pubkeys(). The full `authors` array
    (up to CACHE_LIST_MAX entries) duplicates that response wholesale, so
    drop it from the HTTP view only; `partial_authors` stays — it's
    RENDER_PAGE_MAX-bounded and users.html renders it directly mid-scan."""
    view = dict(status)
    view.pop("authors", None)
    return view


# --- gift-wrap recipient tally ---------------------------------------------
# Storage accounting, not moderation: kind 1059 (gift wraps) is the bulk of
# a DM-carrying relay's disk, and the unencrypted `p` tag says who each one
# is addressed to. GET /api/recipients is left as an unauthenticated public
# read, exactly like GET /api/authors / GET /api/banned — the "admin-only"
# framing in CLAUDE.md describes the feature (no recipient leaderboard, no
# UI on any logged-out page — there is no recipients.html at all), not a
# server-side auth requirement on a read of an already-bounded cache. Only
# the scan-triggering POST costs a NIP-98 signature.

def _empty_recipients_result():
    return {
        "scanned_at": None, "events_read": 0, "total_matching": None, "span_start": None, "span_end": None,
        "saturated": False, "timed_out": False, "list_total": 0, "list_omitted": 0,
        "warning": None, "error": None, "recipients": [],
    }


def compute_recipients(progress_cb=None):
    """One scan of EVERY kind-1059 gift-wrap event, tallying the `p` tag —
    the wrapped message's recipient, never the event's `pubkey`, which is a
    fresh single-use sender key — while streaming, so no event body is ever
    held in full and there is no count limit left to fall short of. Gift-
    wrap CONTENT is encrypted and senders are unlinkable; nothing here
    reveals who is talking to whom, and recipient counts are for
    retention/capacity decisions only, never a moderation signal.

    Bounded only by AUTHOR_SCAN_DEADLINE now — see that constant for what
    "ran out of time" means here. Kept as a FLOOR when it happens (CACHE_LIST_MAX-style):
    an incomplete tally still only under-counts, never invents a recipient,
    so it's always safe for the retention-purge estimate that reads this to
    treat it as "at least this many", the same way it always has."""
    total_matching = run_strfry_count({"kinds": [1059]}, timeout=AUTHOR_SCAN_DEADLINE)
    if progress_cb:
        progress_cb(0, total=total_matching)
    tally = {}
    span = {"start": None, "end": None}

    def on_event(ev):
        if not isinstance(ev, dict):
            return
        created_at = ev.get("created_at")
        tags = ev.get("tags")
        if not isinstance(created_at, int) or not isinstance(tags, list):
            return
        recipient = get_tag(tags, "p")
        if isinstance(recipient, str) and is_hex64(recipient):
            tally[recipient] = tally.get(recipient, 0) + 1
        if span["start"] is None or created_at < span["start"]:
            span["start"] = created_at
        if span["end"] is None or created_at > span["end"]:
            span["end"] = created_at

    events_read, timed_out = run_strfry_scan_streaming(
        {"kinds": [1059]}, on_event,
        timeout=AUTHOR_SCAN_DEADLINE, on_progress=progress_cb, timeout_ok=True,
    )
    saturated = timed_out

    rows = sorted(tally.items(), key=lambda kv: kv[1], reverse=True)
    list_total = len(rows)
    list_omitted = max(0, list_total - CACHE_LIST_MAX)
    rows = rows[:CACHE_LIST_MAX]
    tally.clear()
    to_resolve = [pk for pk, _ in rows[:get_name_resolve_max()]]
    name_resolution_error = None
    try:
        profiles, name_resolution_error = resolve_profiles(to_resolve)
    except Exception as e:
        log(f"server86: recipient name resolution failed: {e}")
        profiles = {}
        name_resolution_error = str(e)

    recipients = []
    for pk, count in rows:
        profile = profiles.get(pk) or {}
        recipients.append({
            "pubkey": pk,
            "name": profile.get("name"), "nip05": profile.get("nip05"),
            "count": count,
        })
    del rows

    warning = None
    if timed_out:
        # Rare (same AUTHOR_SCAN_DEADLINE headroom as the author scan) — but
        # when it happens, say exactly how far short of complete this is,
        # not just "SATURATED".
        warning = (
            f"ran out of time after {AUTHOR_SCAN_DEADLINE}s — read {events_read:,} of "
            f"{total_matching:,} gift-wrap events"
        )
    if list_omitted:
        trunc_note = (
            f"recipient list truncated to top {CACHE_LIST_MAX:,} of "
            f"{list_total:,} (lowest-count tail dropped to protect memory)"
        )
        warning = (warning + " — " + trunc_note) if warning else trunc_note
    if name_resolution_error:
        warning = (warning + " — " + name_resolution_error) if warning else name_resolution_error

    return {
        "scanned_at": int(time.time()),
        "events_read": events_read,
        "total_matching": total_matching,
        "span_start": span["start"],
        "span_end": span["end"],
        "saturated": saturated,
        "timed_out": timed_out,
        "list_total": list_total,
        "list_omitted": list_omitted,
        "warning": warning,
        "error": None,
        "recipients": recipients,
    }


_recipients_job = {"status": "idle", "started_at": None, "progress": None, "total": None, "rate": None, "eta": None}
_recipients_cache = _load_cache_or(RECIPIENTS_CACHE_PATH, _empty_recipients_result())
_JOB_REGISTRY["recipients"] = _recipients_job


def start_recipients_scan():
    def run():
        _run_scan_job(
            "recipients", _recipients_job, _recipients_cache,
            RECIPIENTS_CACHE_PATH, compute_recipients,
        )
    return _start_scan_job("recipients", _recipients_job, run)


def get_recipients_status():
    return _scan_status("recipients", _recipients_job, _recipients_cache)


# --- kind-1984 reports, tallied per reported pubkey -------------------------
# Userlist's "reports by others" column: one bounded scan of recent kind-1984
# events, tallied by DISTINCT reporter per p-tag (a pubkey reported five
# times by the same account is one report, not five) — the same shape as the
# reports sub-tally inside compute_authors, kept as its OWN cached scan
# rather than shared, since userlist must render this column even before an
# author scan has ever run.

def _empty_reports_result():
    return {
        "scanned_at": None, "events_read": 0, "saturated": False, "scan_limit": None,
        "warning": None, "error": None, "counts": {},
    }


def compute_reports(progress_cb=None):
    report_scan_limit = get_report_scan_limit()
    if progress_cb:
        progress_cb(0, total=report_scan_limit)
    reporters_by_pubkey = {}
    events = run_strfry_scan({"kinds": [1984], "limit": report_scan_limit}, timeout=SCAN_TIMEOUT)
    for ev in events:
        reporter = ev.get("pubkey")
        tags = ev.get("tags")
        if not isinstance(reporter, str) or not isinstance(tags, list):
            continue
        for tag in tags:
            if isinstance(tag, list) and len(tag) >= 2 and tag[0] == "p" and isinstance(tag[1], str):
                reporters_by_pubkey.setdefault(tag[1], set()).add(reporter)
    return {
        "scanned_at": int(time.time()),
        "events_read": len(events),
        "saturated": len(events) >= report_scan_limit,
        "scan_limit": report_scan_limit,
        "warning": None,
        "error": None,
        "counts": {pk: len(reporters) for pk, reporters in reporters_by_pubkey.items()},
    }


_reports_job = {"status": "idle", "started_at": None, "progress": None, "total": None, "rate": None, "eta": None}
_reports_cache = _load_cache_or(REPORTS_CACHE_PATH, _empty_reports_result())
_JOB_REGISTRY["reports"] = _reports_job


def start_reports_scan():
    def run():
        _run_scan_job("reports", _reports_job, _reports_cache, REPORTS_CACHE_PATH, compute_reports)
    return _start_scan_job("reports", _reports_job, run)


def get_reports_status():
    return _scan_status("reports", _reports_job, _reports_cache)


# --- DM / general relay-list subscriber search -----------------------------
# Who lists THIS relay in a NIP-17 DM relay list (kind 10050) or a general
# relay list (kind 10002) — the retention-purge exemption (Phase 5) reads
# this to avoid deleting the gift wraps of people who explicitly asked this
# relay to hold them. Kept separate from recipients: a subscriber published
# a signed event announcing this relay is their inbox, which is itself
# public data and discloses nothing new.

def _empty_subscribers_result():
    return {
        "scanned_at": None, "relay_url": None, "saturated": False, "timed_out": False,
        "counted": {},
        "warning": None, "error": None,
        "subscribers": [], "general_subscribers": [],
    }


def _hostname_of(value):
    """Host-only parse, tolerant of a missing scheme (a bare 'relay.example'
    is valid for both the config value and a kind-10050/10002 'relay' tag).
    Returns None on anything unparseable or empty so a missing relay_url
    and a malformed tag never accidentally compare equal via two empty
    strings. Substring matching on the raw tag was rejected deliberately —
    it would match 'relay.example.evil.com' against 'relay.example'."""
    if not isinstance(value, str):
        return None
    value = value.strip()
    if not value:
        return None
    if "://" not in value:
        value = "//" + value
    host = urlparse(value).hostname
    return host.lower() if host else None


_relay_url_cache = None
_relay_url_mtime = None
_relay_url_last_checked = None


def get_relay_url():
    """Best-effort read of config.json's `relay_url` — this relay's own
    public address, needed only so /api/subscribers can tell whether a
    kind-10050/10002 relay tag names THIS relay. strfry has no notion of
    its own address and never reads this field; it's admin-page state,
    set via POST /api/relay-url (see set_relay_url) rather than by hand-
    editing strfry.conf. Re-read on config.json mtime change, checked at
    most once per second, same shape as get_contact_appeal()."""
    global _relay_url_cache, _relay_url_mtime, _relay_url_last_checked
    now = time.monotonic()
    if _relay_url_last_checked is not None and (now - _relay_url_last_checked) < CONTACT_APPEAL_CHECK_INTERVAL:
        return _relay_url_cache
    _relay_url_last_checked = now
    try:
        mtime = os.stat(CONFIG_PATH).st_mtime
    except OSError:
        return _relay_url_cache
    if mtime == _relay_url_mtime:
        return _relay_url_cache
    _relay_url_mtime = mtime
    try:
        with open(CONFIG_PATH, "r") as f:
            cfg = json.load(f)
        value = cfg.get("relay_url")
        _relay_url_cache = value if isinstance(value, str) and value.strip() else None
    except (OSError, ValueError):
        pass
    return _relay_url_cache


def set_relay_url(value):
    """Writes (or clears, when value is falsy) config.json's `relay_url`.
    Admin-only — called from POST /api/relay-url, which sits behind the
    blanket NIP-98 check in do_POST alongside every other mutating
    endpoint. Forces the next get_relay_url() to re-read rather than wait
    out CONTACT_APPEAL_CHECK_INTERVAL, so a save takes effect immediately
    for the very next subscriber scan."""
    global _relay_url_last_checked
    with open(CONFIG_PATH, "r") as f:
        cfg = json.load(f)
    if value:
        cfg["relay_url"] = value
    else:
        cfg.pop("relay_url", None)
    _save_cache_atomic(CONFIG_PATH, cfg)
    _relay_url_last_checked = None


def compute_subscribers(progress_cb=None):
    """Two scans, kept separate: kind 10050 (NIP-17 DM relay lists) and kind
    10002 (general relay lists) — a pubkey listing this relay for general
    use is a different relationship from one listing it for DMs. Neither
    carries a count limit any more; both are bounded only by
    AUTHOR_SCAN_DEADLINE, matched host-only against get_relay_url().

    An unconfigured relay.info.url is a FAILED run, not a result: raising
    here means the caller (_run_scan_job) preserves whatever cache existed
    before, stamps no new scanned_at, and attaches `error` rather than
    rendering an empty subscriber list as a fresh answer. This result feeds
    a destructive retention-purge exemption (Phase 5); a silently-empty
    list presented as current is indistinguishable from 'nobody subscribes'
    and must never be produced.

    SATURATION on this endpoint is unsafe in the direction that matters:
    a saturated subscriber list is a FLOOR, so missing subscribers means
    missing exemptions means MORE deletion, not less (the opposite of a
    saturated recipient scan, which only deletes less). `counted` runs an
    exact index count per kind alongside the tally read, so saturation is a
    fact rather than an inference, and callers (the exempt-purge command
    builder) must refuse to build an exemption list from a saturated scan.
    This asymmetry is exactly why this scan stayed a rare-but-real risk even
    after the count cap was removed elsewhere: AUTHOR_SCAN_DEADLINE hitting
    here is worse than it hitting the recipient scan, so `counted` exists
    specifically so a truncated tally is never mistaken for a complete one."""
    relay_url = get_relay_url()
    relay_host = _hostname_of(relay_url)
    if relay_host is None:
        raise RuntimeError(
            "relay_url is not set — set it from the admin page and re-run"
        )

    counted = {}

    def scan_kind(kind):
        total = run_strfry_count({"kinds": [kind]}, timeout=AUTHOR_SCAN_DEADLINE)
        counted[str(kind)] = total

        tally = {}  # pubkey -> latest created_at among matching events
        if progress_cb:
            progress_cb(0, total=total)

        def on_event(ev):
            if not isinstance(ev, dict):
                return
            pk = ev.get("pubkey")
            created_at = ev.get("created_at")
            tags = ev.get("tags")
            if not is_hex64(pk) or not isinstance(created_at, int) or not isinstance(tags, list):
                return
            matched = any(
                isinstance(tag, list) and len(tag) >= 2 and tag[0] == "relay"
                and _hostname_of(tag[1]) == relay_host
                for tag in tags
            )
            if not matched:
                return
            if pk not in tally or created_at > tally[pk]:
                tally[pk] = created_at

        events_read, timed_out = run_strfry_scan_streaming(
            {"kinds": [kind]}, on_event,
            timeout=AUTHOR_SCAN_DEADLINE, on_progress=progress_cb, timeout_ok=True,
        )
        return tally, timed_out, events_read

    dm_tally, dm_timed_out, dm_events_read = scan_kind(10050)
    general_tally, general_timed_out, general_events_read = scan_kind(10002)
    timed_out = dm_timed_out or general_timed_out

    # giftwrap_count cross-references the last COMPLETED recipients scan,
    # which may be older than this scan or (giftwrap_count: null) may never
    # have run at all — never presented as a fresh number.
    recipients_ever_scanned = _recipients_cache.get("scanned_at") is not None
    recipient_counts = {r["pubkey"]: r["count"] for r in _recipients_cache.get("recipients", [])}

    def build_rows(tally):
        rows = sorted(tally.items(), key=lambda kv: kv[1], reverse=True)
        to_resolve = [pk for pk, _ in rows[:get_name_resolve_max()]]
        try:
            profiles, _ = resolve_profiles(to_resolve)
        except Exception as e:
            log(f"server86: subscriber name resolution failed: {e}")
            profiles = {}
        out = []
        for pk, listed_at in rows:
            try:
                npub = bech32.npub_encode(pk)
            except (ValueError, TypeError):
                continue
            profile = profiles.get(pk) or {}
            out.append({
                "pubkey": pk, "npub": npub,
                "name": profile.get("name"), "nip05": profile.get("nip05"),
                "listed_at": listed_at,
                "giftwrap_count": recipient_counts.get(pk) if recipients_ever_scanned else None,
            })
        return out

    warning = None
    if timed_out:
        # Rare, same AUTHOR_SCAN_DEADLINE headroom as the other two scans —
        # but this is the one where an operator needs the exact shortfall,
        # not just a flag, because it gates whether the exempt-purge command
        # is even offered (see extraNote on /stats).
        parts = []
        if dm_timed_out:
            parts.append(f"DM relay list: read {dm_events_read:,} of {counted.get('10050', 0):,}")
        if general_timed_out:
            parts.append(f"general relay list: read {general_events_read:,} of {counted.get('10002', 0):,}")
        warning = f"ran out of time after {AUTHOR_SCAN_DEADLINE}s — " + "; ".join(parts)

    return {
        "scanned_at": int(time.time()),
        "relay_url": relay_url,
        "saturated": timed_out,
        "timed_out": timed_out,
        "counted": counted,
        "warning": warning,
        "error": None,
        "subscribers": build_rows(dm_tally),
        "general_subscribers": build_rows(general_tally),
    }


_subscribers_job = {"status": "idle", "started_at": None, "progress": None, "total": None, "rate": None, "eta": None}
_subscribers_cache = _load_cache_or(SUBSCRIBERS_CACHE_PATH, _empty_subscribers_result())
_JOB_REGISTRY["subscribers"] = _subscribers_job


def start_subscribers_scan():
    def run():
        _run_scan_job(
            "subscribers", _subscribers_job, _subscribers_cache,
            SUBSCRIBERS_CACHE_PATH, compute_subscribers,
        )
    return _start_scan_job("subscribers", _subscribers_job, run)


def get_subscribers_status():
    return _scan_status("subscribers", _subscribers_job, _subscribers_cache)


# --- relay report: exact totals + the one unlimited scan -------------------
# /api/report/totals answers "how big is the AUTHOR_SCAN_KINDS gap" with
# three index counts — seconds even on a large relay, no window, no
# `saturated`, because a `--count` is simply exact. /api/report/walk is the
# one scan in the project allowed to be genuinely unbounded (see CLAUDE.md's
# bounding-rule carve-out): it streams the whole database once for aggregate
# figures only — a distinct-author count and a per-kind histogram — never a
# list an operator could act on. Both records live in one report-cache.json,
# written wholesale per record, with independent `scanned_at` stamps.

def _empty_report_totals():
    return {
        "scanned_at": None, "duration": None, "total_events": None,
        "giftwrap_events": None, "giftwrap_share": None,
        "allowlist_events": None, "gap_events": None, "gap_share": None,
        "gap_level": None, "needs_walk": False,
        "gap_alarm_kind": None, "gap_alarm_events": None,
        "warning": None, "error": None,
    }


def _empty_report_walk():
    return {
        "scanned_at": None, "duration": None, "rate": None, "events_read": None,
        "distinct_authors": None, "distinct_authors_nongiftwrap": None,
        "distinct_authors_giftwrap": None, "kinds": {}, "unlisted_kinds": {},
        "unlisted_total": None, "unlisted_kind_count": None,
        "expired_events": None,
        "ephemeral_events": None,
        "warning": None, "error": None,
    }


def _compute_gap_level(gap_share, totals_scanned_at, walk_record):
    """See CLAUDE.md 'Auditing the allowlist — two questions, two
    thresholds'. Below GAP_NOTICE_SHARE the gap isn't worth a sentence.
    At or above it, only a walk's per-kind composition can tell size apart
    from actionability — a `--count` alone cannot, since Nostr filters have
    neither negation nor group-by — and only when that walk is at least as
    recent as the totals record being evaluated; a composition from a month
    ago paired with a size from a minute ago is not one measurement, so a
    totals-only refresh always reads back down to 'notice' until the walk
    is re-run alongside it."""
    if gap_share < GAP_NOTICE_SHARE:
        return {"gap_level": "ok", "needs_walk": False, "gap_alarm_kind": None, "gap_alarm_events": None}

    walk_scanned_at = walk_record.get("scanned_at") if walk_record else None
    if walk_scanned_at is None or walk_scanned_at < totals_scanned_at:
        return {"gap_level": "notice", "needs_walk": True, "gap_alarm_kind": None, "gap_alarm_events": None}

    events_read = walk_record.get("events_read") or 0
    giftwrap = walk_record.get("distinct_authors_giftwrap") or 0
    non_giftwrap = events_read - giftwrap
    unlisted = walk_record.get("unlisted_kinds") or {}
    if non_giftwrap > 0 and unlisted:
        worst_kind, worst_count = max(unlisted.items(), key=lambda kv: kv[1])
        if (worst_count / non_giftwrap) >= KIND_ALARM_SHARE:
            return {
                "gap_level": "stale", "needs_walk": False,
                "gap_alarm_kind": int(worst_kind), "gap_alarm_events": worst_count,
            }
    return {"gap_level": "notice", "needs_walk": False, "gap_alarm_kind": None, "gap_alarm_events": None}


def _load_report_cache():
    data = _load_cache_or(REPORT_CACHE_PATH, {})
    totals = data.get("totals")
    walk = data.get("walk")
    return {
        "totals": totals if isinstance(totals, dict) else _empty_report_totals(),
        "walk": walk if isinstance(walk, dict) else _empty_report_walk(),
    }


def compute_report_totals(progress_cb=None):
    """Three `scan --count` calls, no event bodies — exact, index-only, and
    seconds even on a large relay. The fourth figure (`gap_events`) is pure
    arithmetic on the other three; there is no fourth call. This is the
    AUTHOR_SCAN_KINDS staleness check from CLAUDE.md's "Auditing the
    allowlist", promoted from a test.sh-only assertion to a number an
    operator can press a button to see."""
    start = time.monotonic()
    total_events = run_strfry_count({}, timeout=AUTHOR_SCAN_DEADLINE)
    giftwrap_events = run_strfry_count({"kinds": [1059]}, timeout=AUTHOR_SCAN_DEADLINE)
    allowlist_events = run_strfry_count(
        {"kinds": list(get_effective_author_scan_kinds())}, timeout=AUTHOR_SCAN_DEADLINE,
    )
    duration = time.monotonic() - start

    non_giftwrap = total_events - giftwrap_events
    gap_events = total_events - allowlist_events - giftwrap_events
    scanned_at = int(time.time())
    gap_share = (gap_events / non_giftwrap) if non_giftwrap > 0 else 0.0
    result = {
        "scanned_at": scanned_at,
        "duration": duration,
        "total_events": total_events,
        "giftwrap_events": giftwrap_events,
        "giftwrap_share": (giftwrap_events / total_events) if total_events > 0 else 0.0,
        "allowlist_events": allowlist_events,
        "gap_events": gap_events,
        "gap_share": gap_share,
        "warning": None,
        "error": None,
    }
    result.update(_compute_gap_level(gap_share, scanned_at, _report_cache["walk"]))
    return result


def compute_report_walk(progress_cb=None):
    """The one genuinely unbounded scan in the project. Runs `--count '{}'`
    first to learn the denominator (and seed it into progress_cb as `total`
    before streaming starts, so a polling GET can show a percentage and an
    ETA from the first progress tick), then streams every event exactly
    once. All-or-nothing: on success it returns BOTH a totals record and a
    walk record (the `--count` this needed anyway, plus the kind tally the
    stream produces as a byproduct, refresh the totals record without a
    second full-database pass); on hitting REPORT_WALK_DEADLINE it raises,
    and the caller (_run_scan_job) discards everything read and preserves
    whatever was there before.

    Distinct authors are NOT stored as 64-char hex strings — on a
    DM-carrying relay the distinct-pubkey set approaches the event count,
    and a few million hex strings is several hundred MB inside the
    operator's live relay container. Two measures: kind 1059 (gift wraps)
    is skipped entirely, since NIP-17 gift wraps are signed by a fresh key
    per message by specification, so their distinct-author count IS their
    event count, already known exactly from the tally; every other author
    is folded into a set of REPORT_AUTHOR_KEY_BYTES-byte prefixes, whose
    collision probability stays far below the honesty threshold of every
    other number on this page even past a million distinct authors."""
    count_start = time.monotonic()
    total_events = run_strfry_count({}, timeout=REPORT_WALK_DEADLINE)
    if progress_cb:
        progress_cb(0, total=total_events)
    count_duration = time.monotonic() - count_start

    kind_counts = {}
    distinct_prefixes = set()
    giftwrap_count = 0
    expired_count = 0
    ephemeral_count = 0
    walk_now = int(time.time())

    def on_event(ev):
        nonlocal giftwrap_count, expired_count, ephemeral_count
        if not isinstance(ev, dict):
            return
        kind = ev.get("kind")
        if isinstance(kind, int):
            kind_counts[kind] = kind_counts.get(kind, 0) + 1
            if is_ephemeral_kind(kind):
                ephemeral_count += 1
        tags = ev.get("tags")
        if isinstance(tags, list):
            exp = event_expiration(tags)
            if exp is not None and exp < walk_now:
                expired_count += 1
        if kind == 1059:
            giftwrap_count += 1
            return
        pk = ev.get("pubkey")
        if isinstance(pk, str) and is_hex64(pk):
            distinct_prefixes.add(bytes.fromhex(pk)[:REPORT_AUTHOR_KEY_BYTES])

    stream_start = time.monotonic()
    events_read = run_strfry_scan_streaming(
        {}, on_event, timeout=REPORT_WALK_DEADLINE,
        on_progress=(lambda c: progress_cb(c)) if progress_cb else None,
    )
    duration = count_duration + (time.monotonic() - stream_start)
    rate = events_read / duration if duration > 0 else None

    allowlist_kinds_set = set(get_effective_author_scan_kinds())
    unlisted_kinds = {
        k: c for k, c in kind_counts.items()
        if k not in allowlist_kinds_set and k != 1059
    }

    giftwrap_events = kind_counts.get(1059, 0)
    allowlist_events = sum(c for k, c in kind_counts.items() if k in allowlist_kinds_set)
    non_giftwrap = total_events - giftwrap_events
    gap_events = total_events - allowlist_events - giftwrap_events

    gap_share = (gap_events / non_giftwrap) if non_giftwrap > 0 else 0.0
    totals_record = {
        "scanned_at": int(time.time()),
        "duration": count_duration,
        "total_events": total_events,
        "giftwrap_events": giftwrap_events,
        "giftwrap_share": (giftwrap_events / total_events) if total_events > 0 else 0.0,
        "allowlist_events": allowlist_events,
        "gap_events": gap_events,
        "gap_share": gap_share,
        "warning": None,
        "error": None,
    }
    walk_record = {
        "scanned_at": int(time.time()),
        "duration": duration,
        "rate": rate,
        "events_read": events_read,
        "distinct_authors": len(distinct_prefixes) + giftwrap_count,
        "distinct_authors_nongiftwrap": len(distinct_prefixes),
        "distinct_authors_giftwrap": giftwrap_count,
        "kinds": kind_counts,
        "unlisted_kinds": unlisted_kinds,
        "unlisted_total": sum(unlisted_kinds.values()),
        "unlisted_kind_count": len(unlisted_kinds),
        "expired_events": expired_count,
        "ephemeral_events": ephemeral_count,
        "warning": None,
        "error": None,
    }
    totals_record.update(_compute_gap_level(gap_share, totals_record["scanned_at"], walk_record))
    return {"totals": totals_record, "walk": walk_record}


_report_job = {
    "status": "idle", "job": None, "started_at": None,
    "progress": None, "total": None, "rate": None, "eta": None,
}
_report_cache = _load_report_cache()
# Both report job names resolve to the same _report_job dict: totals and
# walk share the report resource and therefore share the report entry in
# _JOB_REGISTRY — only one of the two can ever run at a time anyway, since
# both take the same global _scan_lock like every other scan here.
_JOB_REGISTRY["report-totals"] = _report_job
_JOB_REGISTRY["report-walk"] = _report_job


def _run_report_job(job_name, compute_fn):
    """Same shape as _run_scan_job, specialized for the two-record report
    cache: a totals-only run replaces just the totals record; a walk run
    replaces both (see compute_report_walk). A failure attaches `error`
    (never `scanned_at`) to the record THIS run was attempting and leaves
    the other completely untouched — a walk timeout must never even brush
    the totals record."""
    progress_cb = _make_progress_cb(_report_job)
    try:
        result = compute_fn(progress_cb)
    except Exception as e:
        error = f"report {job_name} failed: {type(e).__name__}: {e}"[:600]
        log(f"server86: {error}")
        with _scan_lock:
            key = "totals" if job_name == "totals" else "walk"
            _report_cache[key]["error"] = error
            _report_job["status"] = "idle"
            _report_job["job"] = None
            _report_job["progress"] = None
            _report_job["total"] = None
            _report_job["rate"] = None
            _report_job["eta"] = None
            _active_scan["name"] = None
        return

    if job_name == "totals":
        new_totals, new_walk = result, dict(_report_cache["walk"])
    else:
        new_totals, new_walk = result["totals"], result["walk"]

    try:
        _save_cache_atomic(REPORT_CACHE_PATH, {"totals": new_totals, "walk": new_walk})
    except OSError as e:
        log(f"server86: failed to persist report-cache.json: {e}")

    with _scan_lock:
        _report_cache["totals"] = new_totals
        _report_cache["walk"] = new_walk
        _report_job["status"] = "idle"
        _report_job["job"] = None
        _report_job["progress"] = None
        _report_job["total"] = None
        _report_job["rate"] = None
        _report_job["eta"] = None
        _active_scan["name"] = None


def start_report_totals_scan():
    def run():
        _run_report_job("totals", compute_report_totals)
    return _start_scan_job("report-totals", _report_job, run, extra_job_fields={"job": "totals"})


def start_report_walk_scan():
    def run():
        _run_report_job("walk", compute_report_walk)
    return _start_scan_job("report-walk", _report_job, run, extra_job_fields={"job": "walk"})


def get_report_status():
    """GET /api/report: never scans, never starts one. `totals`/`walk` are
    null only in the genuine 'never run' state — no result and no error
    yet — rather than a skeleton dict with every field null, so the client
    can tell 'no result yet' apart from 'a result with nulls in it' with
    one falsy check. A record that failed before ever succeeding (`error`
    set, `scanned_at` still null) is NOT collapsed back to null — the
    client still needs to see why it failed."""
    with _scan_lock:
        job = dict(_report_job)
        totals = dict(_report_cache["totals"])
        walk = dict(_report_cache["walk"])
        running = _active_scan["name"]
    blocked_by = running if running not in (None, "report-totals", "report-walk") else None
    return {
        "status": job["status"],
        "job": job["job"],
        "started_at": job["started_at"],
        "progress": job["progress"],
        "total": job["total"],
        "rate": job["rate"],
        "eta": job["eta"],
        "blocked_by": blocked_by,
        "totals": totals if (totals.get("scanned_at") is not None or totals.get("error") is not None) else None,
        "walk": walk if (walk.get("scanned_at") is not None or walk.get("error") is not None) else None,
    }


def validate_relay_url_input(body):
    """Return (value, error) for a POST /api/relay-url body. `value` is
    None to CLEAR relay_url (an absent field or a blank/whitespace-only
    string are both treated as 'clear', not as errors) or the trimmed
    string to store. A non-string relay_url, or one with no parseable
    hostname, is rejected outright rather than silently stored — a typo
    that /api/subscribers can't match against anything is worse than the
    'not set' state, since it reads as configured while quietly matching
    nothing."""
    raw = body.get("relay_url")
    if raw is not None and not isinstance(raw, str):
        return None, "relay_url must be a string"
    value = raw.strip() if isinstance(raw, str) else ""
    if not value:
        return None, None
    if not _hostname_of(value):
        return None, "could not parse a hostname out of that URL"
    return value, None


def validate_authors_scan_mode(body):
    """Return (mode, error) for a POST /api/authors/scan body. `mode`
    selects a named constant filter; the request may never supply a
    filter, a limit, or a kinds array directly — a name indexing a table
    readable in the source is auditable, a caller-supplied number or
    filter is not. On success `error` is None and `mode` is a key of
    AUTHOR_SCAN_MODES; on failure `mode` is None."""
    if "limit" in body or "kinds" in body:
        return None, "limit/kinds may not be supplied by the request"
    mode = body.get("mode")
    if mode not in AUTHOR_SCAN_MODES:
        return None, "unrecognized mode"
    return mode, None


def validate_reason_request(body):
    """Return (pubkeys, reason, mode, error) for a POST /api/reason body.
    On success `error` is None; on failure the first three are None. A
    reason over REASON_MAX_LEN is rejected outright, never truncated.
    Pubkeys are returned lowercase so they match blacklist keys."""
    pubkeys = body.get("pubkeys")
    reason = body.get("reason")
    mode = body.get("mode")
    if not isinstance(pubkeys, list) or not all(is_hex64(pk) for pk in pubkeys):
        return None, None, None, "malformed pubkeys list"
    if not isinstance(reason, str) or len(reason) > get_reason_max_len():
        return None, None, None, "reason missing or exceeds the configured reason length limit"
    if mode not in ("replace", "append"):
        return None, None, None, "mode must be 'replace' or 'append'"
    return [pk.lower() for pk in pubkeys], reason, mode, None


# --- single-pubkey profile -------------------------------------------------

def _report_type_for_target(tags, target_pubkey):
    """Same dual lookup plugin86.py's hot path uses when a report names
    multiple pubkeys: `target_pubkey`'s own `p` tag third element if
    present, else the first `e`/`a` tag's third element, else None.
    Duplicated here rather than shared via lib86 — plugin86.py's hot path
    is the most sensitive file in this project, and this is three lines,
    not worth the risk of touching it for a read-only admin page."""
    if not isinstance(tags, list):
        return None
    fallback = None
    for tag in tags:
        if isinstance(tag, list) and len(tag) >= 3 and tag[0] in ("e", "a") and isinstance(tag[2], str):
            fallback = tag[2]
            break
    for tag in tags:
        if isinstance(tag, list) and len(tag) >= 2 and tag[0] == "p" and tag[1] == target_pubkey:
            if len(tag) >= 3 and isinstance(tag[2], str):
                return tag[2]
            return fallback
    return fallback


def _build_event_preview(ev):
    """One event summarized for a profile's events list — shared by
    compute_profile's recent-events read and compute_profile_day's
    windowed one, so the two previews lists are the exact same shape.
    `reply` is only ever true/false for kind 1 (a NIP-10 reply/quote has
    at least one `e` tag; a top-level note has none) and None for every
    other kind, since 'reply vs note' is a kind-1-only distinction — the
    client falls back to its own kind-name table otherwise. `note` is the
    event's id as a note1... bech32 string so the client can link straight
    to njump without decoding anything itself; None if the id is missing
    or malformed."""
    kind = ev.get("kind")
    reply = None
    if kind == 1:
        tags = ev.get("tags")
        reply = isinstance(tags, list) and any(
            isinstance(tag, list) and len(tag) >= 1 and tag[0] == "e" for tag in tags
        )
    event_id = ev.get("id")
    note = None
    if isinstance(event_id, str) and is_hex64(event_id):
        try:
            note = bech32.note_encode(event_id)
        except (ValueError, TypeError):
            note = None
    content = ev.get("content")
    return {
        "kind": kind,
        "reply": reply,
        "created_at": ev.get("created_at"),
        "content": (content if isinstance(content, str) else "")[:280],
        "note": note,
    }


def _parse_relay_list_event(ev):
    """Extract NIP-65 kind-10002 `r` tags into a stable response shape.
    Returns None when the event has no usable relay URLs. Markers are
    optional per the NIP (read / write / omitted = both)."""
    if not isinstance(ev, dict):
        return None
    relays = []
    seen = set()
    tags = ev.get("tags") or []
    if not isinstance(tags, list):
        tags = []
    for tag in tags:
        if not isinstance(tag, list) or len(tag) < 2:
            continue
        if tag[0] != "r":
            continue
        url = tag[1]
        if not isinstance(url, str) or not url.strip():
            continue
        url = url.strip()
        marker = None
        if len(tag) >= 3 and isinstance(tag[2], str) and tag[2] in ("read", "write"):
            marker = tag[2]
        key = (url, marker)
        if key in seen:
            continue
        seen.add(key)
        entry = {"url": url}
        if marker:
            entry["marker"] = marker
        relays.append(entry)
    if not relays:
        return None
    return {
        "relays": relays,
        "created_at": ev.get("created_at") if isinstance(ev.get("created_at"), int) else None,
        "id": ev.get("id") if isinstance(ev.get("id"), str) else None,
    }


def compute_profile(pubkey_hex):
    """Everything server86 can say about ONE pubkey from the local
    database: bounded subprocesses per author or constant. Admin-only
    because it scans; needs no button, because opening /profile?npub=...
    IS the deliberate act. A failure in any one subscan is reported in
    `warning` rather than failing the whole response — the other scans
    are still worth showing."""
    warnings = []

    try:
        total_events = run_strfry_count({"authors": [pubkey_hex]}, timeout=SCAN_TIMEOUT)
    except Exception as e:
        log(f"server86: profile lifetime count failed for {pubkey_hex}: {e}")
        total_events = None
        warnings.append("lifetime event count failed")

    kinds = {}
    kinds_saturated = False
    previews = []
    profile_fields = None
    profile_event_limit = get_profile_event_limit()
    try:
        events = run_strfry_scan({"authors": [pubkey_hex], "limit": profile_event_limit}, timeout=SCAN_TIMEOUT)
        # `limit` returns the newest matching events first (verified —
        # see CLAUDE.md's "strfry scan execution rules"), but sort
        # explicitly anyway so this doesn't depend on strfry's own
        # ordering staying newest-first within one response.
        events.sort(key=lambda ev: ev.get("created_at") or 0, reverse=True)
        kinds_saturated = len(events) >= profile_event_limit
        for ev in events:
            kind = ev.get("kind")
            if not isinstance(kind, int):
                continue
            kinds[kind] = kinds.get(kind, 0) + 1
            if kind == 0 and profile_fields is None:
                try:
                    content = json.loads(ev.get("content", "{}"))
                except ValueError:
                    content = {}
                if not isinstance(content, dict):
                    content = {}
                profile_fields = {
                    "about": _clean_profile_field(content.get("about")),
                    "picture": _clean_profile_field(content.get("picture")),
                    "website": _clean_profile_field(content.get("website")),
                    "lud16": _clean_profile_field(content.get("lud16")),
                }
        for ev in events[:PROFILE_PREVIEW_MAX]:
            previews.append(_build_event_preview(ev))
    except Exception as e:
        log(f"server86: profile event scan failed for {pubkey_hex}: {e}")
        warnings.append("recent event scan failed")

    reports = []
    reports_saturated = False
    profile_report_limit = get_profile_report_limit()
    try:
        report_events = run_strfry_scan(
            {"kinds": [1984], "#p": [pubkey_hex], "limit": profile_report_limit}, timeout=SCAN_TIMEOUT
        )
        report_events.sort(key=lambda ev: ev.get("created_at") or 0, reverse=True)
        reports_saturated = len(report_events) >= profile_report_limit
        for ev in report_events:
            reporter = ev.get("pubkey")
            if not isinstance(reporter, str):
                continue
            try:
                reporter_npub = bech32.npub_encode(reporter)
            except (ValueError, TypeError):
                continue
            content = ev.get("content")
            reports.append({
                "reporter": reporter,
                "reporter_npub": reporter_npub,
                "report_type": _report_type_for_target(ev.get("tags"), pubkey_hex),
                "content": content if isinstance(content, str) else "",
                "created_at": ev.get("created_at"),
                "name": None,
                "nip05": None,
            })
    except Exception as e:
        log(f"server86: profile reports-against scan failed for {pubkey_hex}: {e}")
        warnings.append("reports-against scan failed")

    # Local-only name/nip05 per distinct reporter — the same batched kind-0
    # lookup (resolve_profiles) every other page uses, bounded by the
    # reporters actually on this page (<= PROFILE_REPORT_LIMIT, well under
    # NAME_RESOLVE_MAX). No outbound network access here; a reporter this
    # leaves unresolved stays eligible for the client's button-triggered
    # s86ResolveNamesExternally pass, same as authors.html's unresolved rows.
    distinct_reporters = list(dict.fromkeys(r["reporter"] for r in reports))
    if distinct_reporters:
        try:
            resolved_reporters, _ = resolve_profiles(distinct_reporters)
        except Exception as e:
            log(f"server86: reporter name resolution failed for {pubkey_hex}: {e}")
            resolved_reporters = {}
        for r in reports:
            info = resolved_reporters.get(r["reporter"]) or {}
            r["name"] = info.get("name")
            r["nip05"] = info.get("nip05")

    # Newest kind-10002 (NIP-65 relay list) for this author only. Limit 1 —
    # one more subprocess, still bounded; failure never kills the profile.
    relay_list = None
    try:
        relay_events = run_strfry_scan(
            {"authors": [pubkey_hex], "kinds": [10002], "limit": 1},
            timeout=SCAN_TIMEOUT,
        )
        if relay_events:
            relay_events.sort(key=lambda ev: ev.get("created_at") or 0, reverse=True)
            relay_list = _parse_relay_list_event(relay_events[0])
    except Exception as e:
        log(f"server86: profile relay-list scan failed for {pubkey_hex}: {e}")
        warnings.append("relay list scan failed")

    return {
        "total_events": total_events,
        "kinds": kinds,
        "kinds_window": profile_event_limit,
        "kinds_saturated": kinds_saturated,
        "profile": profile_fields,
        "previews": previews,
        "reports": reports,
        "reports_saturated": reports_saturated,
        "relay_list": relay_list,
        "warning": "; ".join(warnings) if warnings else None,
    }


def build_profile_response(pubkey_hex):
    """Assemble the full POST /api/profile response: the three bounded
    scans from compute_profile() plus everything server86 already holds
    in memory with no scan at all — ban status, name/nip05, and this
    pubkey's rank in the last author-scan cache, if it appears there."""
    blacklist_data = blacklist.load()
    ban_entry = blacklist_data.get(pubkey_hex)
    banned = ban_entry is not None

    try:
        npub = bech32.npub_encode(pubkey_hex)
    except (ValueError, TypeError):
        npub = None

    try:
        resolved_profiles, _ = resolve_profiles([pubkey_hex])
        resolved = resolved_profiles.get(pubkey_hex) or {}
    except Exception as e:
        log(f"server86: profile name resolution failed for {pubkey_hex}: {e}")
        resolved = {}

    scan_rank = None
    scan_count = None
    with _scan_lock:
        cached_authors = list(_authors_cache.get("authors", []))
    for i, a in enumerate(cached_authors):
        if a.get("pubkey") == pubkey_hex:
            scan_rank = i + 1
            scan_count = a.get("count")
            break

    # What the ban has actually stopped. Costs no scan — plugin86's decision
    # log is already read for the feed — and it is the only figure on this
    # page that describes events which never reached the database at all.
    tally = get_blocked_tally()

    result = compute_profile(pubkey_hex)
    result.update({
        "pubkey": pubkey_hex,
        "npub": npub,
        "name": resolved.get("name"),
        "nip05": resolved.get("nip05"),
        "banned": banned,
        "ban": dict(ban_entry) if ban_entry else None,
        "scan_rank": scan_rank,
        "scan_count": scan_count,
        "blocked": tally["counts"].get(pubkey_hex, 0) if tally["present"] else None,
        "last_blocked_at": tally["last_at"].get(pubkey_hex),
        "blocked_window": blocked_window_meta(tally),
    })
    return result


def validate_profile_day_request(body):
    """Return (pubkey_hex, since, until, error) for a POST /api/profile/day
    body. The client sends a calendar date, never a raw time window — the
    [since, until) bounds are computed HERE, server-side, as one UTC day, so
    the client can never hand this endpoint an arbitrarily large span. Every
    other timestamp on this page (s86FormatDate) is already rendered in UTC,
    so the picked date has to mean the same calendar day the server scans,
    not whatever the browser's local timezone would offset it to."""
    pubkey_hex = body.get("pubkey")
    date_str = body.get("date")
    pubkey_hex = as_hex64(pubkey_hex)
    if pubkey_hex is None:
        return None, None, None, "malformed pubkey"
    if not isinstance(date_str, str) or not re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
        return None, None, None, "malformed date (expected YYYY-MM-DD)"
    try:
        parsed = time.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        return None, None, None, "invalid date"
    since = calendar.timegm(parsed)
    until = since + 86400
    return pubkey_hex, since, until, None


def compute_profile_day(pubkey_hex, since, until):
    """One pubkey's events within [since, until) — a single UTC calendar day,
    already validated and computed by validate_profile_day_request(). Same
    shape and same PROFILE_DAY_EVENTS_MAX bound as compute_profile()'s own
    recent-events previews, just windowed by date instead of by recency;
    `truncated` says so explicitly rather than letting a full day of events
    look like a complete one. Admin-only because it scans; needs no button
    beyond picking the date, same reasoning as opening /profile itself."""
    profile_day_events_max = get_profile_day_events_max()
    events = run_strfry_scan(
        {"authors": [pubkey_hex], "since": since, "until": until, "limit": profile_day_events_max},
        timeout=SCAN_TIMEOUT,
    )
    events.sort(key=lambda ev: ev.get("created_at") or 0, reverse=True)
    truncated = len(events) >= profile_day_events_max
    previews = [_build_event_preview(ev) for ev in events]
    return {"previews": previews, "truncated": truncated}


def validate_profile_new_request(body):
    """Return (pubkey_hex, since, error) for a POST /api/profile/new body.
    `since` is the caller's own newest-known created_at PLUS ONE — an
    exclusive lower bound the client computes so the boundary event it
    already has is never double-counted — never a raw relative offset the
    server would have to interpret."""
    pubkey_hex = as_hex64(body.get("pubkey"))
    since = body.get("since")
    if pubkey_hex is None:
        return None, None, "malformed pubkey"
    if not isinstance(since, int) or isinstance(since, bool) or since < 0:
        return None, None, "malformed since (expected a non-negative integer)"
    return pubkey_hex, since, None


def compute_profile_new_events(pubkey_hex, since):
    """Events with created_at >= `since`, bounded by PROFILE_EVENT_LIMIT —
    the cheap alternative to a full compute_profile() recompute when the
    profile page's '>' button is pressed at the latest day. Reuses
    PROFILE_EVENT_LIMIT (the same bound compute_profile's own kind-tally
    scan uses) as the definition of "one page": `truncated` is True when
    that many new events exist, meaning the true count is unknown — there
    could be more past the bound — and the caller must not treat
    `kinds_delta`/`len(previews)` as exact in that case. When truncated is
    False, every new event was actually read, so total_events and each
    kinds[] entry can be incremented by an EXACT delta instead of
    re-scanning the whole pubkey."""
    profile_event_limit = get_profile_event_limit()
    events = run_strfry_scan(
        {"authors": [pubkey_hex], "since": since, "limit": profile_event_limit}, timeout=SCAN_TIMEOUT,
    )
    events.sort(key=lambda ev: ev.get("created_at") or 0, reverse=True)
    truncated = len(events) >= profile_event_limit
    kinds_delta = {}
    for ev in events:
        kind = ev.get("kind")
        if isinstance(kind, int):
            kinds_delta[kind] = kinds_delta.get(kind, 0) + 1
    previews = [_build_event_preview(ev) for ev in events]
    return {"previews": previews, "truncated": truncated, "kinds_delta": kinds_delta}


# --- domain roster lookup ---------------------------------------------------

def validate_pubkeys_lookup_request(body):
    """Return (pubkeys, domain, error) for a POST /api/pubkeys/lookup
    body. A body over DOMAIN_LOOKUP_MAX is rejected outright — never
    silently truncated, since the admin is about to bulk-act on this
    list. Any malformed pubkey is rejected the same way rather than
    skipped: a roster row that vanished between fetch and render is worse
    than an error."""
    pubkeys = body.get("pubkeys")
    domain = body.get("domain")
    if not isinstance(pubkeys, list) or len(pubkeys) == 0:
        return None, None, "malformed pubkeys list"
    domain_lookup_max = get_domain_lookup_max()
    if len(pubkeys) > domain_lookup_max:
        return None, None, f"too many pubkeys (max {domain_lookup_max})"
    if not all(is_hex64(pk) for pk in pubkeys):
        return None, None, "malformed pubkey in list"
    if not isinstance(domain, str) or not domain.strip():
        return None, None, "malformed domain"
    return [pk.lower() for pk in pubkeys], domain.strip(), None


def compute_pubkeys_lookup(pubkeys, domain):
    """Answers 'what do you know about these pubkeys' for a domain roster
    the browser already fetched. The posted list IS the authors bound:
    one batched local kind-0 scan (via the shared resolve_profiles(), so
    a banned pubkey's stored name still wins over a fresh scan) capped at
    NAME_RESOLVE_MAX, everything else a dict lookup against the
    blacklist and the author-scan cache. No scan beyond that one batch."""
    blacklist_data = blacklist.load()
    with _scan_lock:
        scan_counts = {a["pubkey"]: a.get("count") for a in _authors_cache.get("authors", [])}

    try:
        profiles, _ = resolve_profiles(pubkeys[:get_name_resolve_max()])
    except Exception as e:
        log(f"server86: pubkeys/lookup name resolution failed: {e}")
        profiles = {}

    domain_suffix = "@" + domain.lower()
    results = []
    for pk in pubkeys:
        try:
            npub = bech32.npub_encode(pk)
        except (ValueError, TypeError):
            continue
        entry = blacklist_data.get(pk)
        profile = profiles.get(pk) or {}
        nip05 = profile.get("nip05")
        results.append({
            "pubkey": pk, "npub": npub,
            "name": profile.get("name"), "nip05": nip05,
            "banned": entry is not None,
            "ban_reason": entry.get("reason") if entry else None,
            "scan_count": scan_counts.get(pk),
            # A comparison of two unverified claims, never proof of
            # anything: true when this pubkey's OWN kind-0 nip05 ends in
            # @<domain>, the cross-check that flags a stale roster entry
            # (listed but doesn't claim it back) versus an impersonator
            # (claims it but the roster doesn't list them — invisible
            # here by construction; see the author list's nip05 filter).
            "claims_domain": bool(nip05) and nip05.lower().endswith(domain_suffix),
        })
    return {"domain": domain, "results": results}


# NIP-98 used-event ids: reject the same signed auth event twice within
# NIP98_REPLAY_TTL. Keyed by event id (lowercase hex); value is unix expiry.
_nip98_used_ids = {}
_nip98_used_lock = threading.Lock()


def _nip98_prune_used(now):
    expired = [eid for eid, exp in _nip98_used_ids.items() if exp <= now]
    for eid in expired:
        del _nip98_used_ids[eid]


def nip98_mark_used(event_id, now):
    """Record a successfully verified auth event id. Return False if it was
    already used and has not yet expired (replay)."""
    if not isinstance(event_id, str) or not event_id:
        return False
    eid = event_id.lower()
    with _nip98_used_lock:
        _nip98_prune_used(now)
        exp = _nip98_used_ids.get(eid)
        if exp is not None and exp > now:
            return False
        _nip98_used_ids[eid] = now + NIP98_REPLAY_TTL
        return True


def nip98_origin_of_u(u):
    """scheme://netloc from a NIP-98 `u` tag, or None if unusable."""
    if not isinstance(u, str) or not u:
        return None
    parsed = urlparse(u)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    return f"{parsed.scheme}://{parsed.netloc}".lower()


def normalize_public_origin(value):
    """Return scheme://host[:port] lowercase, or None if blank/invalid."""
    if not isinstance(value, str):
        return None
    text = value.strip().rstrip("/")
    if not text:
        return None
    if "://" not in text:
        text = "https://" + text
    parsed = urlparse(text)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    return f"{parsed.scheme}://{parsed.netloc}".lower()


def get_public_origin():
    """Optional config.json public_origin — the UI URL as browsers see it."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        if isinstance(cfg, dict):
            return normalize_public_origin(cfg.get("public_origin"))
    except (OSError, ValueError):
        pass
    return None


def request_expected_origin(handler):
    """Origin this request must be NIP-98-bound to.

    Prefer configured `public_origin` (correct behind TLS-terminating
    proxies). Otherwise derive from Host + X-Forwarded-Proto (or http)."""
    configured = get_public_origin()
    if configured:
        return configured
    host = (handler.headers.get("Host") or "").strip()
    if not host or "/" in host or " " in host or "\\" in host:
        return None
    proto = (handler.headers.get("X-Forwarded-Proto") or "").split(",")[0].strip().lower()
    if proto not in ("http", "https"):
        proto = "http"
    return f"{proto}://{host}".lower()


def payload_body_hash(body):
    """SHA-256 hex of the canonical JSON of `body` without the `auth` key.

    Auth is inside the JSON body in this project (not an Authorization
    header), so the signed payload cannot be the raw wire body. Client and
    server both hash the non-auth object with sorted keys so key order never
    drifts between JS and Python."""
    if not isinstance(body, dict):
        body = {}
    data = {k: v for k, v in body.items() if k != "auth"}
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def verify_nip98(auth, admin_pubkey_hex, expected_path, now=None,
                 expected_origin=None, payload_sha256=None, consume_id=False):
    """Return (ok, error_message). `now` defaults to the real current time;
    a test harness may inject a fixed value to isolate the freshness check
    against a pre-signed fixture.

    `expected_origin` is scheme://host[:port]; when provided, the `u` tag
    must match both that origin and `expected_path` (phishing defence).
    `payload_sha256` is the hex digest of the non-auth body; when provided,
    a matching `payload` tag is required (body-substitution defence).
    `consume_id` marks the event id used so the same signature cannot be
    replayed within NIP98_REPLAY_TTL (live handlers pass True; pure unit
    tests of the fixture pass False so the fixture can be reused)."""
    if not isinstance(auth, dict):
        return False, "malformed auth event"

    pubkey = auth.get("pubkey")
    sig = auth.get("sig")
    event_id = auth.get("id")
    kind = auth.get("kind")
    created_at = auth.get("created_at")
    tags = auth.get("tags")
    content = auth.get("content", "")

    if not is_hex64(pubkey) or not is_hex64(event_id) or not isinstance(sig, str) or len(sig) != 128:
        return False, "malformed auth fields"
    if not isinstance(tags, list) or not isinstance(created_at, int) or not isinstance(kind, int):
        return False, "malformed auth fields"

    try:
        int(sig, 16)
    except ValueError:
        return False, "malformed signature"

    # Event id and BIP-340 verify use the bytes as signed; pubkey hex in
    # the event is almost always lowercase. Compare admin as lowercase so
    # a mixed-case config.json still authorises the same key.
    pubkey_l = pubkey.lower()
    event_id_l = event_id.lower()
    admin_l = admin_pubkey_hex.lower() if isinstance(admin_pubkey_hex, str) else ""

    expected_id = compute_event_id(pubkey, created_at, kind, tags, content)
    if expected_id != event_id_l and expected_id != event_id:
        return False, "event id mismatch"

    try:
        sig_ok = bip340.schnorr_verify(
            bytes.fromhex(event_id_l), bytes.fromhex(pubkey_l), bytes.fromhex(sig)
        )
    except ValueError:
        return False, "malformed signature"
    if not sig_ok:
        return False, "invalid signature"

    if pubkey_l != admin_l:
        return False, "not the admin"

    if kind != NIP98_KIND:
        return False, "wrong kind"

    method = get_tag(tags, "method")
    if method != "POST":
        return False, "wrong method tag"

    u = get_tag(tags, "u")
    if not isinstance(u, str):
        return False, "wrong u tag"
    parsed_u = urlparse(u)
    if parsed_u.path != expected_path:
        return False, "wrong u tag"
    if expected_origin is not None:
        origin = nip98_origin_of_u(u)
        want = normalize_public_origin(expected_origin)
        if origin is None or want is None or origin != want:
            return False, "wrong u origin"

    if payload_sha256 is not None:
        if not isinstance(payload_sha256, str) or not is_hex64(payload_sha256):
            return False, "payload hash missing"
        tag_payload = get_tag(tags, "payload")
        if not isinstance(tag_payload, str) or tag_payload.lower() != payload_sha256.lower():
            return False, "payload hash mismatch"

    if now is None:
        now = int(time.time())
    if abs(created_at - now) > NIP98_MAX_SKEW:
        return False, "stale auth event"

    if consume_id:
        if not nip98_mark_used(event_id_l, now):
            return False, "auth event already used"

    return True, None


def verify_kind0_event(event, queried, banned_pubkeys):
    """Verify one raw kind-0 event POSTed to /api/names. Returns
    (pubkey, created_at, name, nip05) if the event is validly signed,
    kind 0, and its pubkey is in both `queried` and `banned_pubkeys` — or
    None on ANY failure. Never raises: a hostile relay's malformed or
    forged event must be silently dropped, not a 500."""
    try:
        if not isinstance(event, dict):
            return None
        pubkey = event.get("pubkey")
        sig = event.get("sig")
        event_id = event.get("id")
        kind = event.get("kind")
        created_at = event.get("created_at")
        tags = event.get("tags")
        content = event.get("content", "")

        if not is_hex64(pubkey) or not is_hex64(event_id):
            return None
        if not isinstance(sig, str) or len(sig) != 128:
            return None
        if not isinstance(tags, list) or not isinstance(created_at, int):
            return None
        if kind != 0:
            return None
        if pubkey not in queried:
            return None
        if pubkey not in banned_pubkeys:
            return None

        expected_id = compute_event_id(pubkey, created_at, kind, tags, content)
        if expected_id != event_id:
            return None

        try:
            sig_ok = bip340.schnorr_verify(
                bytes.fromhex(event_id), bytes.fromhex(pubkey), bytes.fromhex(sig)
            )
        except ValueError:
            return None
        if not sig_ok:
            return None

        try:
            content_obj = json.loads(content)
        except ValueError:
            content_obj = {}
        name = _clean_profile_field(content_obj.get("display_name") or content_obj.get("name"))
        nip05 = _clean_profile_field(content_obj.get("nip05"))
        return (pubkey, created_at, name, nip05)
    except Exception:
        return None


class Handler(BaseHTTPRequestHandler):
    server_version = "strfry86/1.0"

    def log_message(self, fmt, *args):
        log("server86: " + (fmt % args))

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        encoding = None
        if len(body) >= GZIP_MIN_BYTES:
            accept = self.headers.get("Accept-Encoding", "")
            if "gzip" in [e.strip() for e in accept.split(",")]:
                body = gzip.compress(body, compresslevel=GZIP_LEVEL)
                encoding = "gzip"
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        if encoding:
            self.send_header("Content-Encoding", encoding)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_sse(self, msg):
        self.wfile.write(("event: live\ndata: " + json.dumps(msg) + "\n\n").encode("utf-8"))
        self.wfile.flush()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path in LEGACY_REDIRECTS:
            self.send_response(302)
            self.send_header("Location", LEGACY_REDIRECTS[path])
            self.end_headers()
            return

        if path in STATIC_ROUTES:
            filename, content_type = STATIC_ROUTES[path]
            try:
                with open(os.path.join(SCRIPT_DIR, filename), "rb") as f:
                    body = f.read()
            except OSError:
                self.send_response(500)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if path == "/api/live":
            # One shared poll loop, fanned out: this connection just
            # registers a queue and relays whatever _live_poll_loop
            # broadcasts, plus a heartbeat comment when nothing has arrived
            # in a while so an idle proxy doesn't time the connection out.
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            q, initial = live_subscribe()
            try:
                self._send_sse(initial)
                while True:
                    try:
                        msg = q.get(timeout=LIVE_POLL_INTERVAL * 3)
                    except queue.Empty:
                        self.wfile.write(b": keep-alive\n\n")
                        self.wfile.flush()
                        continue
                    self._send_sse(msg)
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            finally:
                live_unsubscribe(q)
            return

        if path == "/api/stats":
            self._send_json(200, get_stats_snapshot())
            return

        if path == "/api/userlist":
            self._send_json(200, get_userlist_snapshot())
            return

        if path == "/api/reports":
            self._send_json(200, get_reports_status())
            return

        if path == "/api/metrics":
            self._send_json(200, get_relay_metrics())
            return

        if path == "/api/giftwrap-retention/purge":
            # Public so the Settings page can poll progress without asking the
            # signing extension to re-sign every three seconds. Redacted for
            # exactly that reason — the failure text goes out only through the
            # authenticated POST /api/settings read.
            self._send_json(200, get_giftwrap_purge_status())
            return

        if path == "/api/ephemeral/purge":
            # Same public-poll / redacted-error shape as gift-wrap purge.
            self._send_json(200, get_ephemeral_purge_status())
            return

        if path == "/api/db-compact":
            # Same public-poll / redacted-error shape as gift-wrap purge.
            self._send_json(200, get_db_compact_status())
            return

        if path == "/api/console":
            # Lock-holder read only — no subprocess, nothing to redact.
            # Lets the Stats page poll "is anything blocking the console"
            # without re-signing/re-running a command every few seconds.
            self._send_json(200, get_console_status())
            return

        if path == "/api/domain-bans":
            self._send_json(200, {"domains": get_domain_bans()})
            return

        if path == "/api/audit":
            # Admin action history is not public intelligence — reasons,
            # settings deltas, and actor pubkeys used to ship unauthenticated.
            self._send_json(401, {"error": "auth required — POST /api/audit with NIP-98"})
            return

        if path == "/api/banned":
            cfg = self.server.strfry86_config
            data = blacklist.load()
            pubkeys = list(data.keys())
            name_resolution_error = None
            try:
                profiles, name_resolution_error = resolve_profiles(pubkeys)
            except Exception as e:
                log(f"server86: name resolution failed: {e}")
                profiles = {}
                name_resolution_error = str(e)
            # A ban is a rule; the blocked count is that rule being enforced.
            # It is the only figure on the page that says the ban is doing
            # anything, so it travels with the row rather than living behind
            # another scan.
            tally = get_blocked_tally()
            banned = []
            for pubkey, info in data.items():
                profile = profiles.get(pubkey) or {}
                banned.append(
                    {
                        "pubkey": pubkey,
                        "banned_at": info.get("banned_at"),
                        "reason": info.get("reason", ""),
                        "report_type": info.get("report_type"),
                        "report_event_id": info.get("report_event_id"),
                        "name": profile.get("name"),
                        "nip05": profile.get("nip05"),
                        "name_checked_at": info.get("name_checked_at"),
                        "blocked": tally["counts"].get(pubkey, 0) if tally["present"] else None,
                        "last_blocked_at": tally["last_at"].get(pubkey),
                    }
                )
            banned.sort(key=lambda b: (b["banned_at"] is None, b["banned_at"]), reverse=True)
            self._send_json(200, {
                "admin": cfg["admin_pubkey_hex"],
                "contact_appeal": get_contact_appeal(),
                "banned": banned,
                "blocked_window": blocked_window_meta(tally),
                "name_resolution_error": name_resolution_error,
            })
            return

        if path == "/api/authors":
            self._send_json(200, _authors_status_for_http(get_authors_status()))
            return

        if path == "/api/recipients":
            self._send_json(200, get_recipients_status())
            return

        if path == "/api/subscribers":
            self._send_json(200, get_subscribers_status())
            return

        if path == "/api/relay-url":
            self._send_json(200, {"relay_url": get_relay_url()})
            return

        if path == "/api/report":
            self._send_json(200, get_report_status())
            return

        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        if path not in (
            "/api/unban", "/api/ban", "/api/authors/scan", "/api/names",
            "/api/recipients", "/api/subscribers", "/api/reason", "/api/profile",
            "/api/profile/day", "/api/profile/new", "/api/pubkeys/lookup", "/api/report/totals",
            "/api/report/walk", "/api/relay-url", "/api/reports",
            "/api/console", "/api/undo", "/api/audit",
            "/api/settings", "/api/settings/save", "/api/domain-unban",
            "/api/strfry-conf-path",
            "/api/giftwrap-retention/estimate", "/api/giftwrap-retention/purge",
            "/api/ephemeral/estimate", "/api/ephemeral/purge",
            "/api/db-compact",
        ):
            self._send_json(404, {"error": "not found"})
            return

        cfg = self.server.strfry86_config
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length < 0:
            length = 0
        if length > POST_BODY_MAX:
            self._send_json(413, {
                "error": f"request body too large (max {POST_BODY_MAX // (1024 * 1024)}MB)",
            })
            return
        try:
            raw = self.rfile.read(length) if length > 0 else b""
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            self._send_json(400, {"error": "malformed request body"})
            return

        if not isinstance(body, dict):
            self._send_json(400, {"error": "malformed request body"})
            return

        auth = body.get("auth")

        expected_origin = request_expected_origin(self)
        if expected_origin is None:
            self._send_json(401, {
                "error": "cannot determine request origin — set public_origin in config.json",
            })
            return
        ok, err = verify_nip98(
            auth, cfg["admin_pubkey_hex"], path,
            expected_origin=expected_origin,
            payload_sha256=payload_body_hash(body),
            consume_id=True,
        )
        if not ok:
            self._send_json(401, {"error": err})
            return

        if path == "/api/authors/scan":
            mode, err = validate_authors_scan_mode(body)
            if err:
                self._send_json(400, {"error": err})
                return
            status = start_authors_scan(mode)
            self._send_json(202, status)
            return

        if path == "/api/recipients":
            status = start_recipients_scan()
            self._send_json(202, status)
            return

        if path == "/api/subscribers":
            status = start_subscribers_scan()
            self._send_json(202, status)
            return

        if path == "/api/relay-url":
            value, err = validate_relay_url_input(body)
            if err:
                self._send_json(400, {"error": err})
                return
            set_relay_url(value)
            self._send_json(200, {"ok": True, "relay_url": get_relay_url()})
            return

        if path == "/api/report/totals":
            status = start_report_totals_scan()
            self._send_json(202, status)
            return

        if path == "/api/report/walk":
            status = start_report_walk_scan()
            self._send_json(202, status)
            return

        if path == "/api/reports":
            status = start_reports_scan()
            self._send_json(202, status)
            return

        if path == "/api/console":
            raw_cmd = body.get("command")
            # Global job lock: console scan/export contends with walk/purge
            # on the same LMDB. Hold the lock for the whole command so a
            # scan cannot start under a long export either (CLAUDE.md).
            refusal = acquire_console_slot()
            if refusal is not None:
                self._send_json(409, refusal)
                return
            try:
                result = run_console_command(
                    raw_cmd if isinstance(raw_cmd, str) else ""
                )
            finally:
                release_console_slot()
            code = 200 if result.get("ok") else 400
            self._send_json(code, result)
            return

        if path == "/api/audit":
            q = body.get("q") if isinstance(body.get("q"), str) else ""
            try:
                offset = max(0, int(body.get("offset") or 0))
            except (TypeError, ValueError):
                offset = 0
            records = get_audit_records(q)
            page = records[offset:offset + RENDER_PAGE_MAX]
            self._send_json(200, {
                "records": page, "total": len(records),
                "offset": offset, "limit": RENDER_PAGE_MAX,
            })
            return

        if path == "/api/undo":
            record_id = body.get("id")
            if not isinstance(record_id, str) or not record_id:
                self._send_json(400, {"error": "missing audit record id"})
                return
            with _audit_lock:
                found = None
                for r in _audit_log.get("records") or []:
                    if r.get("id") == record_id:
                        found = dict(r)
                        break
            if found is None:
                self._send_json(404, {"error": "audit record not found"})
                return
            if found.get("undone"):
                self._send_json(400, {"error": "already undone"})
                return
            rtype = found.get("type")
            pubkeys = found.get("pubkeys") or []
            if rtype == "ban":
                removed = blacklist.remove(pubkeys)
                audit_mark_undone(record_id)
                audit_append({
                    "type": "unban", "actor": auth.get("pubkey"),
                    "pubkeys": removed, "via": "audit-undo", "undo_of": record_id,
                })
                self._send_json(200, {"ok": True, "removed": removed})
                return
            if rtype == "unban":
                now = int(time.time())
                added = []
                for pk in pubkeys:
                    if not is_hex64(pk):
                        continue
                    reason = ""
                    for e in (found.get("entries") or []):
                        if e.get("pubkey") == pk:
                            reason = e.get("reason") or ""
                            break
                    if blacklist.add(
                        pk, banned_at=now, report_event_id=None, reason=reason,
                        report_type="manual", admin_pubkey_hex=cfg["admin_pubkey_hex"],
                    ):
                        added.append(pk)
                audit_mark_undone(record_id)
                audit_append({
                    "type": "ban", "actor": auth.get("pubkey"),
                    "pubkeys": added, "via": "audit-undo", "undo_of": record_id,
                })
                self._send_json(200, {"ok": True, "added": added})
                return
            if rtype == "reason":
                # Restore prior reasons from the snapshot when present.
                entries = found.get("entries") or []
                if not entries:
                    self._send_json(400, {"error": "undo unavailable for this reason record"})
                    return
                restored = 0
                for e in entries:
                    pk = e.get("pubkey")
                    old = e.get("old_reason")
                    if not is_hex64(pk):
                        continue
                    blacklist.set_reasons([pk], old or "", "replace", now=int(time.time()))
                    restored += 1
                audit_mark_undone(record_id)
                self._send_json(200, {"ok": True, "restored": restored})
                return
            self._send_json(400, {"error": f"cannot undo type {rtype!r}"})
            return

        if path == "/api/settings":
            self._send_json(200, get_settings_payload())
            return

        if path == "/api/strfry-conf-path":
            # The command-generator's copy-paste `--config` flag needs the
            # SAME resolution get_settings_payload() already does, without
            # paying for a full strfry.conf read/parse and purge-status
            # computation on every Users/Bans/Stats page load just to learn
            # one path. Admin-gated like everything else here — GET
            # /api/metrics deliberately withholds filesystem paths from the
            # public, and this is the same path by another door.
            status = strfry_conf_status()
            self._send_json(200, {
                "path": status.get("path"),
                "exists": bool(status.get("exists")),
            })
            return

        if path == "/api/giftwrap-retention/estimate":
            try:
                est = estimate_giftwrap_retention(body.get("days"))
            except Exception as e:
                self._send_json(500, {"error": f"{type(e).__name__}: {e}"})
                return
            self._send_json(200, est)
            return

        if path == "/api/giftwrap-retention/purge":
            days = clamp_giftwrap_retention_days(body.get("days"))
            # The audit record is written by start_giftwrap_purge itself, and
            # only if THIS call launched the purge — the handler never has to
            # infer that from the lock, which is what let a refused press be
            # audited and an accepted one go unrecorded.
            status = start_giftwrap_purge(
                days=days,
                on_started=lambda: audit_append({
                    "type": "giftwrap_purge", "actor": auth.get("pubkey"),
                    "days": days, "via": "settings purge now",
                }),
            )
            # 202 while this job (or a blocker) is running so the client
            # knows to poll; 200 when nothing is in flight.
            code = 202 if status.get("status") == "running" or status.get("blocked_by") else 200
            self._send_json(code, status)
            return

        if path == "/api/ephemeral/estimate":
            try:
                est = estimate_ephemeral_storage()
            except Exception as e:
                self._send_json(500, {"error": f"{type(e).__name__}: {e}"})
                return
            self._send_json(200, est)
            return

        if path == "/api/ephemeral/purge":
            status = start_ephemeral_purge(
                on_started=lambda: audit_append({
                    "type": "ephemeral_purge", "actor": auth.get("pubkey"),
                    "via": "settings purge ephemeral",
                }),
            )
            code = 202 if status.get("status") == "running" or status.get("blocked_by") else 200
            self._send_json(code, status)
            return

        if path == "/api/db-compact":
            status = start_db_compact(
                on_started=lambda: audit_append({
                    "type": "db_compact", "actor": auth.get("pubkey"),
                    "via": "settings compact",
                }),
            )
            code = 202 if status.get("status") == "running" or status.get("blocked_by") else 200
            self._send_json(code, status)
            return

        if path == "/api/settings/save":
            target = body.get("target")
            raw = body.get("raw")
            edits = body.get("edits")
            if target not in ("relay", "app"):
                self._send_json(400, {"error": "target must be 'relay' or 'app'"})
                return
            if raw is not None and not isinstance(raw, str):
                self._send_json(400, {"error": "raw must be a string"})
                return
            if edits is not None and not isinstance(edits, dict):
                self._send_json(400, {"error": "edits must be an object"})
                return
            if raw is None and not edits:
                self._send_json(400, {"error": "nothing to save"})
                return

            if target == "relay":
                current, err = read_strfry_conf()
                if err:
                    self._send_json(500, {"error": f"cannot read strfry.conf: {err}"})
                    return
                if raw is not None:
                    new_text, changed = raw, ["<raw>"]
                else:
                    new_text, changed = apply_strfry_conf_edits(current, edits)
                    if not changed:
                        self._send_json(200, {"ok": True, "changed": [], "note": "no field differed"})
                        return
                ok_write, werr = write_strfry_conf(new_text)
                if not ok_write:
                    self._send_json(400, {"error": werr})
                    return
            else:
                ok_write, werr = write_app_config(edits=edits, raw=raw)
                if not ok_write:
                    self._send_json(400, {"error": werr})
                    return
                changed = ["<raw>"] if raw is not None else sorted(edits.keys())

            audit_append({
                "type": "settings", "actor": auth.get("pubkey"),
                "target": target, "changed": changed,
                "via": "raw editor" if raw is not None else "structured fields",
            })
            self._send_json(200, {"ok": True, "changed": changed})
            return

        if path == "/api/domain-unban":
            domain = body.get("domain")
            if not isinstance(domain, str) or not domain.strip():
                self._send_json(400, {"error": "domain required"})
                return
            domain = domain.strip().lower()
            pubkeys = domain_ban_remove(domain)
            if pubkeys is None:
                self._send_json(404, {"error": "no record for that domain"})
                return
            removed = blacklist.remove(pubkeys)
            audit_append({
                "type": "unban", "actor": auth.get("pubkey"), "pubkeys": removed,
                "via": f"domain {domain}",
            })
            self._send_json(200, {"ok": True, "domain": domain, "removed": removed})
            return

        if path == "/api/reason":
            pubkeys, reason, mode, err = validate_reason_request(body)
            if err:
                self._send_json(400, {"error": err})
                return
            updated, skipped = blacklist.set_reasons(pubkeys, reason, mode, now=int(time.time()))
            if updated:
                reason_undo_max = get_reason_undo_max()
                audit_append({
                    "type": "reason",
                    "actor": auth.get("pubkey"),
                    "pubkeys": [u["pubkey"] for u in updated],
                    "reason": reason,
                    "mode": mode,
                    "entries": [
                        {"pubkey": u["pubkey"], "old_reason": u.get("old_reason")}
                        for u in updated[:reason_undo_max]
                    ] if len(updated) <= reason_undo_max else None,
                    "count": len(updated),
                })
            self._send_json(200, {"ok": True, "updated": updated, "skipped": skipped})
            return

        if path == "/api/profile":
            raw_pk = body.get("pubkey")
            pubkey_hex = None
            if is_hex64(raw_pk):
                pubkey_hex = raw_pk.lower()
            elif isinstance(raw_pk, str):
                try:
                    pubkey_hex = bech32.npub_decode(raw_pk)
                except (ValueError, TypeError):
                    pubkey_hex = None
            pubkey_hex = as_hex64(pubkey_hex)
            if pubkey_hex is None:
                self._send_json(400, {"error": "malformed pubkey"})
                return
            self._send_json(200, build_profile_response(pubkey_hex))
            return

        if path == "/api/profile/day":
            pubkey_hex, since, until, err = validate_profile_day_request(body)
            if err:
                self._send_json(400, {"error": err})
                return
            try:
                self._send_json(200, compute_profile_day(pubkey_hex, since, until))
            except Exception as e:
                log(f"server86: profile day-events scan failed for {pubkey_hex}: {e}")
                self._send_json(502, {"error": "day-events scan failed"})
            return

        if path == "/api/profile/new":
            pubkey_hex, since, err = validate_profile_new_request(body)
            if err:
                self._send_json(400, {"error": err})
                return
            try:
                self._send_json(200, compute_profile_new_events(pubkey_hex, since))
            except Exception as e:
                log(f"server86: profile new-events scan failed for {pubkey_hex}: {e}")
                self._send_json(502, {"error": "new-events scan failed"})
            return

        if path == "/api/pubkeys/lookup":
            pubkeys, domain, err = validate_pubkeys_lookup_request(body)
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, compute_pubkeys_lookup(pubkeys, domain))
            return

        if path == "/api/names":
            queried_raw = body.get("queried")
            events_raw = body.get("events")
            if not isinstance(queried_raw, list) or not isinstance(events_raw, list):
                self._send_json(400, {"error": "malformed request body"})
                return

            queried = [pk.lower() for pk in queried_raw if is_hex64(pk)]
            queried_set = set(queried)
            # The accept-bound is "banned OR present in the current
            # author-scan cache" — still a bound assembled from server-held
            # state, never an arbitrary client-supplied pubkey.
            acceptable_pubkeys = set(blacklist.load().keys()) | authors_scan_pubkeys()

            hits = {}
            newest_created_at = {}
            for ev in events_raw:
                verified = verify_kind0_event(ev, queried_set, acceptable_pubkeys)
                if verified is None:
                    continue
                pubkey, created_at, name, nip05 = verified
                if pubkey in newest_created_at and newest_created_at[pubkey] >= created_at:
                    continue
                newest_created_at[pubkey] = created_at
                hits[pubkey] = {"name": name, "nip05": nip05}

            # Storage routes by ban status, never by request: re-check
            # fresh, right before writing — the lookup took seconds and
            # the admin may have banned or unbanned someone meanwhile.
            now = int(time.time())
            fresh_banned = set(blacklist.load().keys())
            banned_queried = [pk for pk in queried if pk in fresh_banned]
            cache_queried = [pk for pk in queried if pk not in fresh_banned]
            banned_hits = {pk: h for pk, h in hits.items() if pk in fresh_banned}
            cache_hits = {pk: h for pk, h in hits.items() if pk not in fresh_banned}

            stamped = blacklist.set_names(banned_hits, banned_queried, now=now)
            stamped += namecache.set_external(cache_hits, cache_queried, now=now, max_entries=get_name_cache_max())

            stamped_set = set(stamped)
            named = sorted(pk for pk in hits if pk in stamped_set)
            self._send_json(200, {"ok": True, "named": named, "stamped": len(stamped)})
            return

        if path == "/api/unban":
            pubkeys_raw = body.get("pubkeys")
            if not isinstance(pubkeys_raw, list) or not all(is_hex64(pk) for pk in pubkeys_raw):
                self._send_json(400, {"error": "malformed pubkeys list"})
                return
            pubkeys = [pk.lower() for pk in pubkeys_raw]

            # Snapshot ban rows before removal so audit undo can re-ban.
            data = blacklist.load()
            entries_snap = []
            for pk in pubkeys:
                info = data.get(pk) or {}
                entries_snap.append({
                    "pubkey": pk,
                    "reason": info.get("reason") or "",
                })
            removed = blacklist.remove(pubkeys)
            if removed:
                audit_append({
                    "type": "unban",
                    "actor": auth.get("pubkey"),
                    "pubkeys": removed,
                    "entries": [e for e in entries_snap if e["pubkey"] in set(removed)],
                })
            self._send_json(200, {"ok": True, "removed": removed})
            return

        # /api/ban
        entries = body.get("entries")
        if not isinstance(entries, list):
            self._send_json(400, {"error": "malformed entries list"})
            return

        added = []
        skipped = []
        now = int(time.time())
        reasons_by_pk = {}
        reason_max_len = get_reason_max_len()
        for entry in entries:
            if not isinstance(entry, dict):
                skipped.append(entry)
                continue
            raw_pk = entry.get("pubkey")
            reason = entry.get("reason") or ""
            if not isinstance(reason, str) or len(reason) > reason_max_len:
                skipped.append(raw_pk)
                continue
            pubkey = None
            if is_hex64(raw_pk):
                pubkey = raw_pk.lower()
            elif isinstance(raw_pk, str):
                try:
                    pubkey = bech32.npub_decode(raw_pk)
                except (ValueError, TypeError):
                    pubkey = None
            pubkey = as_hex64(pubkey)
            if pubkey is None:
                skipped.append(raw_pk)
                continue
            ok_added = blacklist.add(
                pubkey,
                banned_at=now,
                report_event_id=None,
                reason=reason,
                report_type="manual",
                admin_pubkey_hex=cfg["admin_pubkey_hex"],
            )
            if ok_added:
                added.append(pubkey)
                reasons_by_pk[pubkey] = reason
            else:
                skipped.append(raw_pk)

        # An optional `domain` says these pubkeys were banned AS a domain's
        # roster, on the Domain page. It changes nothing about enforcement —
        # the pubkeys are what enforce — but it is what lets the Banlist name
        # the domain and undo the whole set in one press.
        domain = body.get("domain")
        domain = domain.strip().lower() if isinstance(domain, str) and domain.strip() else None

        if added:
            if domain:
                domain_ban_record(domain, added, body.get("reason") or "", auth.get("pubkey"))
            audit_append({
                "type": "ban",
                "actor": auth.get("pubkey"),
                "pubkeys": added,
                "domain": domain,
                "via": f"domain {domain}" if domain else None,
                "entries": [{"pubkey": pk, "reason": reasons_by_pk.get(pk, "")} for pk in added],
            })
        self._send_json(200, {"ok": True, "added": added, "skipped": skipped, "domain": domain})


def main():
    try:
        cfg = load_config()
    except Exception as e:
        log(f"server86: cannot start, config.json missing/invalid: {e}")
        sys.exit(1)

    try:
        httpd = ThreadingHTTPServer((cfg["bind"], cfg["port"]), Handler)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            sys.exit(0)
        log(f"server86: failed to bind {cfg['bind']}:{cfg['port']}: {e}")
        sys.exit(0)

    httpd.strfry86_config = cfg
    # Seed the live feed BEFORE accepting connections so a tab opened the
    # moment the port is up already has the newest LIVE_FEED_SEED rows
    # instead of waiting out the first poll interval (or forever, if the
    # relay is quiet). Failure is non-fatal — the poll loop still starts.
    try:
        _live_seed_recent()
    except Exception as e:
        log(f"server86: live feed seed crashed: {type(e).__name__}: {e}")
    threading.Thread(target=_live_poll_loop, daemon=True).start()
    threading.Thread(target=_giftwrap_retention_loop, daemon=True).start()
    rss = _process_rss_bytes()
    rss_note = f", rss={rss // (1024 * 1024)}MB" if rss is not None else ""
    log(f"server86: listening on {cfg['bind']}:{cfg['port']}"
        f" (gift-wrap retention {get_giftwrap_retention_days()}d"
        f", soft={MEMORY_SOFT_BYTES // (1024 * 1024)}MB{rss_note})")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
